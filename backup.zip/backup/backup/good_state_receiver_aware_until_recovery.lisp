;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Book import
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(include-book "model_1")

;; TODO:
;; 1.   Add an invariant stating that any recovery message on
;;      channel j -> i must carry a sid that receiver i already knows,
;;      i.e., the sid must be a member of i's snapshot-ids.
;;
;; 2.   Add an invariant/lemma stating that if there is a  marker message at the
;;      head of channel j -> i, then the sid of the msg must be known to be some
;;      process
;; 3.   


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Structural predicates
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Defines the well-formedness invariant for processes, snapshots, messages,
;; channels, and the top-level implementation state.



;start definitions: status-and-snapshot-id-predicates
;; Basic recognizers for allowed process statuses, snapshot statuses, and
;; snapshot identifiers.  These are the leaf predicates used later by
;; good-proc-p and good-snapshot-ids-list-p.

(defun good-proc-status-p (x)
  (or (equal x :normal)
      (equal x :crashed)
      (equal x :recovering)))

(defun good-snapshot-status-p (x)
  (or (equal x :checkpointing)
      (equal x :done)))

(defun good-snapshot-id-p (sid ids)
  (or (equal sid :init)
      (and (consp sid)
           (consp (cdr sid))
           (endp (cddr sid))
           (memberp (car sid) ids)
           (natp (cadr sid)))))

(defun good-snapshot-ids-p (snapshot-ids ids)
  (if (endp snapshot-ids)
      t
    (and (good-snapshot-id-p (first snapshot-ids) ids)
         (good-snapshot-ids-p (rest snapshot-ids) ids))))

(defun good-snapshot-ids-list-p (snapshot-ids ids)
  (and (true-listp snapshot-ids)
       (uniquep snapshot-ids)
       (memberp :init snapshot-ids)
       (good-snapshot-ids-p snapshot-ids ids)))

;end definitions: status-and-snapshot-id-predicates


;start definitions: message-well-formedness
;; Message well-formedness is channel-aware.
;;
;; Normal messages do not carry snapshot ids.
;;
;; Marker messages carry a snapshot id that must already be known somewhere
;; in the system.  The receiver may not know the sid yet, because receiving the
;; first marker is exactly how the receiver learns and installs that snapshot.
;;
;; Recovery messages are stronger: a recovery message on channel src -> dst
;; must carry a sid that the receiver dst already knows.  This is the invariant
;; needed by handle-recovery-msg in the first-recovery case.

(defun some-proc-has-snapshot-id-p (sid ids procs)
  (if (endp ids)
      nil
    (let* ((i (first ids))
           (p (g i procs)))
      (or (memberp sid (snapshot-ids p))
          (some-proc-has-snapshot-id-p sid (rest ids) procs)))))

(defun good-msg-p (msg dst ids procs)
  (let ((tp (msg-type msg)))
    (cond
     ;; Application/compute messages are always structurally valid.
     ((equal tp :normal)
      t)

     ;; A marker sid only needs to be known somewhere.  The receiver may be
     ;; seeing this sid for the first time.
     ((equal tp :marker)
      (some-proc-has-snapshot-id-p (sid msg) ids procs))

     ;; A recovery sid must already be known by the receiver of this channel.
     ((equal tp :recovery)
      (memberp (sid msg)
               (snapshot-ids (g dst procs))))

     ;; Unknown message type is not well-formed.
     (t nil))))

(defun good-msg-list-p (msgs dst ids procs)
  (if (endp msgs)
      t
    (and (good-msg-p (first msgs) dst ids procs)
         (good-msg-list-p (rest msgs) dst ids procs))))

(defun good-msg-for-dsts-p (msg dsts ids procs)
  (if (endp dsts)
      t
    (and (good-msg-p msg (first dsts) ids procs)
         (good-msg-for-dsts-p msg (rest dsts) ids procs))))

(defun sid-known-by-procs-p (sid dsts procs)
  (if (endp dsts)
      t
    (and (memberp sid
                  (snapshot-ids (g (first dsts) procs)))
         (sid-known-by-procs-p sid (rest dsts) procs))))

(defthm good-msg-p-of-create-marker-message
  (implies (some-proc-has-snapshot-id-p sid ids procs)
           (good-msg-p (create-marker-message local-state sid)
                       dst
                       ids
                       procs)))

(defthm good-msg-p-of-create-recovery-message
  (implies (memberp sid
                    (snapshot-ids (g dst procs)))
           (good-msg-p (create-recovery-message local-state sid)
                       dst
                       ids
                       procs)))

(defthm good-msg-for-dsts-p-of-create-recovery-message
  (implies (sid-known-by-procs-p sid dsts procs)
           (good-msg-for-dsts-p (create-recovery-message local-state sid)
                                dsts
                                ids
                                procs)))

(defthm good-msg-p-when-memberp-good-msg-for-dsts-p
  (implies (and (good-msg-for-dsts-p msg dsts ids procs)
                (memberp dst dsts))
           (good-msg-p msg dst ids procs)))

(defthm good-msg-for-dsts-p-of-create-marker-message
  (implies (some-proc-has-snapshot-id-p sid ids procs)
           (good-msg-for-dsts-p (create-marker-message local-state sid)
                                dsts
                                ids
                                procs)))

;end definitions: message-well-formedness


;start definitions: snapshot-entry-well-formedness
;; Channel snapshots contain only normal messages, and each snapshot entry keeps
;; its waiting-marker list inside the process's incoming-neighbor list.

(defun good-normal-msg-p (msg)
  (equal (msg-type msg) :normal))

(defthm good-normal-msg-p-of-create-compute-message
  (good-normal-msg-p (create-compute-message local-state nbr)))

(defun good-normal-msg-list-p (msgs)
  (if (endp msgs)
      t
    (and (good-normal-msg-p (first msgs))
         (good-normal-msg-list-p (rest msgs)))))

(defun good-channel-snapshot-record-p (nbrs-from-i cs)
  (if (endp nbrs-from-i)
      t
    (and (good-normal-msg-list-p (g (first nbrs-from-i) cs))
         (good-channel-snapshot-record-p (rest nbrs-from-i) cs))))

(defun good-snapshot-entry-p (entry nbrs-from-i)
  (and (good-snapshot-status-p (snapshot-status entry))
       (true-listp (snapshot-waiting-marker-from entry))
       (subset (snapshot-waiting-marker-from entry) nbrs-from-i)
       (good-channel-snapshot-record-p nbrs-from-i
                                       (snapshot-channel-snapshots entry))))

(defun good-snapshots-p (snapshot-ids p nbrs-from-i ids)
  (declare (irrelevant ids))
  (if (endp snapshot-ids)
      t
    (let* ((sid   (first snapshot-ids))
           (entry (snapshot-entry sid p)))
      (and
           ;(good-snapshot-id-p sid ids)
           (good-snapshot-entry-p entry nbrs-from-i)
           (good-snapshots-p (rest snapshot-ids)
                             p
                             nbrs-from-i
                             ids)))))

;end definitions: snapshot-entry-well-formedness


;start definitions: process-channel-state-well-formedness
;; Lift the local predicates to processes, process tables, channel rows,
;; full channel tables, and finally the top-level implementation state.

(defun good-proc-p ( p ids)
  (let* ((nbrs-in  (nbrs-from p))
         (nbrs-out (nbrs-to p)))
    (and (true-listp nbrs-in)
         (true-listp nbrs-out)
         (subset nbrs-in ids)
         (subset nbrs-out ids)
         (good-proc-status-p (proc-status p))
         (natp (counter p))
         (true-listp (waiting-recovery-from p))
         (subset (waiting-recovery-from p) nbrs-in)
	 (good-snapshot-ids-list-p (snapshot-ids p) ids)
         (good-snapshots-p (snapshot-ids p) p nbrs-in ids))))

(defun good-procs-p (ids procs all-ids)
  (if (endp ids)
      t
    (let* ((i (first ids))
           (p (g i procs)))
      (and (good-proc-p  p  all-ids)
           (good-procs-p (rest ids) procs all-ids)))))

(defun good-channel-p (src dst channels ids procs)
  (let ((p (g src procs)))
    (if (memberp dst (nbrs-to p))
        (good-msg-list-p (channel-state src dst channels)
                         dst
                         ids
                         procs)
      (equal (channel-state src dst channels) nil))))

(defun good-channel-row-p (src dsts channels ids procs)
  (if (endp dsts)
      t
    (and (good-channel-p src (first dsts) channels ids procs)
         (good-channel-row-p src (rest dsts) channels ids procs))))

(defun good-channels-p (srcs dsts channels ids procs)
  (if (endp srcs)
      t
    (and (good-channel-row-p (first srcs) dsts channels ids procs)
         (good-channels-p (rest srcs) dsts channels ids procs))))

(defun good-state-p (st)
  (let* ((ids      (proc-ids st))
         (procs    (procs st))
         (channels (channels st)))
    (and (true-listp ids)
         (uniquep ids)
         (good-procs-p ids procs ids)
         (good-channels-p ids ids channels ids procs))))


;end definitions: process-channel-state-well-formedness


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Small reusable helpers
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; General process-table/list lemmas used by several preservation proofs.


;start support: generic-process-and-list-helpers
;; Small rewrite/helper facts used across many preservation proofs.  These keep
;; membership/subset obligations from being reproved in every major case.

(defthm good-proc-p-of-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (g i procs)
                        all-ids)))

(defthm not-memberp-when-subset-and-not-memberp
  (implies (and (subset xs ys)
                (not (memberp a ys)))
           (not (memberp a xs))))

(defthm memberp-of-cons-right
  (implies (memberp e xs)
           (memberp e (cons a xs))))

(defthm subset-of-cons
  (implies (subset xs ys)
           (subset xs (cons a ys))))

(defthm subset-reflexive
    (subset x x))


;end support: generic-process-and-list-helpers


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Initial-state preservation support
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Shows that the initial process table and channel table satisfy good-state-p.


;start support: initial-empty-message-and-snapshot-records
;; Empty channels and empty channel-snapshot records are well-formed.  The
;; initial snapshot entry is also structurally good for any incoming-neighbor list.

(defthm good-normal-msg-list-p-of-nil
  (good-normal-msg-list-p nil))

(defthm good-msg-list-p-of-nil
  (good-msg-list-p nil dst ids procs))

(defthm good-channel-snapshot-record-p-of-nil
  (good-channel-snapshot-record-p nbrs-from-i nil))

(defthm good-snapshot-entry-p-of-make-init-snapshot-entry
  (good-snapshot-entry-p (make-init-snapshot-entry init-local-state)
                         nbrs-from-i))

(defthm good-proc-p-of-install-initial-snapshot-on-make-one-proc
  (good-proc-p
   (install-initial-snapshot (make-one-proc i all-ids))
   all-ids))

;end support: initial-empty-message-and-snapshot-records


;start support: initial-process-table-construction
;; Show that make-procs-aux installs the expected process at every valid id, and
;; that installing the initial snapshot produces a good process table.

(defthm g-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i (make-procs-aux ids all-ids))
                  (make-one-proc i all-ids))))

(defthm g-of-s-diff
  (implies (not (equal k1 k2))
           (equal (g k1 (s k2 v r))
                  (g k1 r))))

(defthm g-of-install-initial-snapshots-when-not-member
  (implies (not (memberp k ids))
           (equal (g k (install-initial-snapshots ids procs))
                  (g k procs))))

(defthm g-of-install-initial-snapshots
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i (install-initial-snapshots ids procs))
                  (install-initial-snapshot (g i procs)))))

(defthm g-of-install-initial-snapshots-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i
                     (install-initial-snapshots ids
                                                (make-procs-aux ids all-ids)))
                  (install-initial-snapshot
                   (make-one-proc i all-ids)))))

(defthm good-proc-p-of-g-of-install-initial-snapshots-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (good-proc-p
            (g i
               (install-initial-snapshots ids
                                          (make-procs-aux ids all-ids)))
            all-ids)))

(defthm good-procs-p-of-install-initial-snapshots-of-make-procs-aux
  (implies (uniquep ids)
           (good-procs-p ids
                         (install-initial-snapshots ids
                                                    (make-procs-aux ids all-ids))
                         all-ids)))

;end support: initial-process-table-construction


;start support: initial-channel-table-construction
;; Build the initial channel table one destination column at a time.  Freshness
;; and uniqueness keep old rows from being disturbed by the new destination.

(defthm good-channel-row-p-preserved-by-adding-fresh-dst
  (implies (and (good-channel-row-p src dsts channels ids procs)
                (not (memberp new-dst dsts)))
           (good-channel-row-p src dsts
                               (s new-dst row channels)
                               ids procs)))

(defthm good-channels-p-of-cons-new-dst
  (implies (and (good-channels-p srcs dsts channels ids procs)
                (not (memberp dst dsts))
		(uniquep dsts)
		(uniquep srcs))
           (good-channels-p srcs
                            (cons dst dsts)
                            (s dst (make-channel-row srcs) channels)
                            ids
                            procs)))

(defthm good-channels-p-of-make-channels-aux
    (implies (and (uniquep dsts)
		  (uniquep srcs))
           (good-channels-p srcs
                            dsts
                            (make-channels-aux srcs dsts)
                            ids
                            procs)))

(defthm good-channels-p-of-make-channels
    (implies (uniquep ids)
	     (good-channels-p ids ids (make-channels ids) ids procs)))

;end support: initial-channel-table-construction


;start target: initial-state-is-good-state
;; Main target for initialization: the state produced by make-initial-state
;; satisfies the global structural invariant good-state-p.

(defthm initial-state-is-good-state
    (good-state-p (make-initial-state)))


;end target: initial-state-is-good-state


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; NOP preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A nop input leaves the state structurally unchanged.


;start target: good-state-p-preserved-by-nop
;; Main target for :nop inputs.  Since system-step does not change the state in
;; the nop case, good-state-p is preserved directly.

(defthm good-state-p-preserved-by-nop
  (implies (and (good-state-p st)
                (equal (ttype input) :nop))
           (good-state-p (system-step st input))))


;end target: good-state-p-preserved-by-nop


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Crash preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A crash only changes :proc-status to an allowed value.  Channels are
;; unchanged because message well-formedness does not depend on proc-status.


;start support: crash-process-update-preservation
;; A crash changes only :proc-status.  Since :crashed is an allowed status and
;; snapshot data is untouched, the updated process remains good.

(defthm good-snapshots-p-of-set-proc-status-crashed
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :proc-status :crashed p)
                             nbrs-from
                             ids)))

(defthm good-proc-p-of-set-proc-status-crashed
  (implies (good-proc-p p ids)
           (good-proc-p (s :proc-status :crashed p)
                        ids)))

(defthm good-proc-p-of-crashed-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (s :proc-status
                           :crashed
                           (g i procs))
                        all-ids)))

(defthm g-of-crash-updated-procs
  (equal (g k
            (s i
               (s :proc-status :crashed (g i procs))
               procs))
         (if (equal k i)
             (s :proc-status :crashed (g i procs))
           (g k procs))))

(defthm good-procs-p-of-crash-update
  (implies (and (true-listp ids)
                (uniquep ids)
                (true-listp all-ids)
                (uniquep all-ids)
                (good-procs-p ids procs all-ids))
           (good-procs-p ids
                         (s i
                            (s :proc-status
                               :crashed
                               (g i procs))
                            procs)
                         all-ids)))

;end support: crash-process-update-preservation


;start support: crash-channel-preservation
;; Channels are unchanged by a crash, and message goodness is independent of the
;; crashed process's status.  Lift this fact from message lists to all channels.

(defthm good-msg-list-p-of-crash-update
  (implies (good-msg-list-p msgs dst ids procs)
           (good-msg-list-p msgs dst ids
                            (s i
                               (s :proc-status :crashed (g i procs))
                               procs))))

(defthm good-channel-p-of-crash-update
  (implies (good-channel-p src dst channels ids procs)
           (good-channel-p src dst channels ids
                           (s i
                              (s :proc-status :crashed (g i procs))
                              procs))))

(defthm good-channel-row-p-of-crash-update
  (implies (good-channel-row-p src dsts channels ids procs)
           (good-channel-row-p src dsts channels ids
                               (s i
                                  (s :proc-status :crashed (g i procs))
                                  procs))))

(defthm good-channels-p-of-crash-update
  (implies (good-channels-p srcs dsts channels ids procs)
           (good-channels-p srcs dsts channels ids
                            (s i
                               (s :proc-status :crashed (g i procs))
                               procs))))

;end support: crash-channel-preservation


;start target: good-state-p-of-system-step-crash
;; Main target for :crash inputs: combine the process-table update proof with
;; the channel-table preservation proof.

(defthm good-state-p-of-system-step-crash
  (implies (and (good-state-p st)
                (equal (ttype input) :crash))
           (good-state-p (system-step st input))))


;end target: good-state-p-of-system-step-crash


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Normal-step process update preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Local-state updates preserve process and channel well-formedness.


;start support: normal-process-local-state-update
;; A normal computation step may update only :local-state.  This does not change
;; status, neighbor lists, snapshot ids, counters, or snapshot entries.

(defthm good-snapshots-p-of-set-proc-update-normal
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :local-state val p)
                             nbrs-from
                             ids)))

(defthm good-proc-p-of-set-proc-update-normal
  (implies (good-proc-p p ids)
           (good-proc-p (s :local-state val p)
                        ids)))

(defthm good-proc-p-of-update-normal-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (s :local-state val
                           (g i procs))
                        all-ids)))

(defthm good-proc-p-of-g-when-good-procs-p-update-normal
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (g i procs)
                        all-ids)))

(defthm g-of-update-normal-updated-procs
  (equal (g k
            (s i
               (s :local-state val (g i procs))
               procs))
         (if (equal k i)
             (s :local-state val (g i procs))
           (g k procs))))

(defthm good-procs-p-of-normal-update
  (implies (and (true-listp ids)
                (uniquep ids)
                (true-listp all-ids)
                (uniquep all-ids)
                (good-procs-p ids procs all-ids))
           (good-procs-p ids
                         (s i
                            (s :local-state
                               val
                               (g i procs))
                            procs)
                         all-ids)))

;end support: normal-process-local-state-update


;start support: normal-channel-preservation-under-proc-update
;; The channel contents do not change when only a process local state changes.
;; Lift preservation from message lists to rows and then to the whole channel table.

(defthm good-msg-list-p-of-normal-update
  (implies (good-msg-list-p msgs dst ids procs)
           (good-msg-list-p msgs dst ids
                            (s i
                               (s :local-state val (g i procs))
                               procs))))

(defthm good-channel-p-of-normal-update
  (implies (good-channel-p src dst channels ids procs)
           (good-channel-p src dst channels ids
                           (s i
                              (s :local-state val (g i procs))
                              procs))))

(defthm good-channel-row-p-of-normal-update
  (implies (good-channel-row-p src dsts channels ids procs)
           (good-channel-row-p src dsts channels ids
                               (s i
                                  (s  :local-state val (g i procs))
                                  procs))))

(defthm good-channels-p-of-normal-update
  (implies (good-channels-p srcs dsts channels ids procs)
           (good-channels-p srcs dsts channels ids
                            (s i
                               (s :local-state val (g i procs))
                               procs))))


;end support: normal-channel-preservation-under-proc-update


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Compute-message channel preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Compute sends append normal messages to outgoing channels.  The lemmas first
;; handle one channel update, then lift to rows and the whole channel table.


;start support: compute-message-goodness
;; Compute messages are normal messages, so appending a freshly created compute
;; message preserves good-msg-list-p.

(defthm good-msg-p-of-create-compute-message
  (good-msg-p (create-compute-message local-state nbr) dst
              ids
              procs))

(defthm good-msg-list-p-of-snoc-create-compute-message
  (implies (good-msg-list-p msgs dst ids procs)
           (good-msg-list-p
            (snoc msgs (create-compute-message local-state nbr)) dst
            ids
            procs)))

;end support: compute-message-goodness


;start support: one-compute-channel-update
;; These lemmas reason about a single channel-table update.  They separate the
;; same-channel case from different-source/different-destination cases.

(defthm channel-lookup-after-send-compute-message-when-dst-not-in-nbrs
  (implies (not (memberp dst nbrs))
           (equal (g src
                     (g dst
                        (send-compute-message local-state i nbrs channels)))
                  (g src
                     (g dst channels)))))

(defthm good-msg-list-p-preserved-by-setting-different-dst
    (implies (and (memberp dst dsts)
		  (not (memberp dst2 dsts))
                (good-msg-list-p (g src (g dst channels)) dst
                                 ids procs))
           (good-msg-list-p
            (g src
               (g dst
                  (s dst2 row channels))) dst
            ids procs)))

(defthm good-msg-list-p-preserved-by-setting-different-src
  (implies (and (not (equal src src2))
                (good-msg-list-p (g src (g dst channels)) dst
                                 ids procs))
           (good-msg-list-p
            (g src
               (g dst
                  (s dst
                     (s src2 val (g dst channels))
                     channels))) dst
            ids procs)))

(defthm good-msg-list-p-of-setting-channel-src-entry-val
  (implies
   (and (good-msg-list-p (g src (g dst channels)) dst
                         ids procs)
        (good-msg-list-p val dst ids procs))
   (good-msg-list-p
    (g src
       (s i
          val
          (g dst channels))) dst
    ids procs))
  :hints (("Goal"
           :cases ((equal i src)))))

(defthm good-msg-list-p-of-setting-channel-dst-entry-val
  (implies
   (and (good-msg-list-p (g src (g dst channels)) dst
                         ids procs)

        (good-msg-list-p val dst ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels))) dst
    ids procs))
  :hints (("Goal"
           :cases ((equal dst j)))))

(defthm g-of-s-different-src
  (implies (not (equal src i))
           (equal (g src (s i val row))
                  (g src row))))

(defthm g-g-of-s-different-dst
  (implies (not (equal dst j))
           (equal (g src
                     (g dst
                        (s j row channels)))
                  (g src
                     (g dst channels)))))

(defthm channel-lookup-of-setting-different-channel
  (implies (or (not (equal dst j))
               (not (equal src i)))
           (equal
            (g src
               (g dst
                  (s j
                     (s i val (g j channels))
                     channels)))
            (g src
               (g dst channels))))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :cases ((equal dst j)))))

(defthm good-msg-list-p-of-setting-different-channel
  (implies
   (and (good-msg-list-p (g src (g dst channels)) dst
                         ids procs)
        (or (not (equal dst j))
            (not (equal src i))))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels))) dst
    ids procs)))

(defthm good-msg-list-p-of-setting-channel-combined
  (implies
   (and (good-msg-list-p (g src (g dst channels)) dst
                         ids procs)
        (or (not (equal dst j))
            (not (equal src i))
            (good-msg-list-p val dst ids procs)))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels))) dst
    ids procs))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :cases ((equal dst j)
                   (equal src i)))))

(defthm good-msg-list-p-of-snoc-create-compute-message-same-channel
  (implies
   (and (equal src i)
        (equal dst j)
        (good-msg-list-p (g src (g dst channels)) dst
                         ids procs))
   (good-msg-list-p
    (snoc (g i (g j channels))
          (create-compute-message local-state j)) dst
    ids procs)))

(defthm one-compute-send-update-disjunct
  (implies
   (good-msg-list-p (g src (g dst channels)) dst
                    ids procs)
   (or (not (equal dst j))
       (not (equal src i))
       (good-msg-list-p
        (snoc (g i (g j channels))
              (create-compute-message local-state j)) dst
        ids procs))))

(defthm good-msg-list-p-of-one-compute-send-update
  (implies
   (good-msg-list-p (g src (g dst channels)) dst
                    ids procs)
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i
                (snoc (g i (g j channels))
                      (create-compute-message local-state j))
                (g j channels))
             channels))) dst
    ids procs))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :use ((:instance good-msg-list-p-of-setting-channel-combined
                            (src src)
                            (dst dst)
                            (i i)
                            (j j)
                            (channels channels)
                            (ids ids)
                            (procs procs)
                            (val (snoc (g i (g j channels))
                                       (create-compute-message local-state j))))
                 (:instance one-compute-send-update-disjunct
                            (src src)
                            (dst dst)
                            (i i)
                            (j j)
                            (channels channels)
                            (ids ids)
                            (procs procs)
                            (local-state local-state))))))

;end support: one-compute-channel-update


;start support: send-compute-message-channel-lookup
;; After send-compute-message, either the target channel receives a good normal
;; message or unrelated/nil channels stay unchanged.

(defthm good-msg-list-p-of-channel-after-send-compute-message
  (implies
   (good-msg-list-p (g src (g dst channels)) dst ids procs)
   (good-msg-list-p
    (g src
       (g dst
          (send-compute-message local-state i nbrs channels))) dst
    ids procs)))

(defthm channel-nil-after-send-compute-message-when-dst-not-in-nbrs-2
    (implies (and (not (memberp dst  nbrs-to))
		  (subset nbrs nbrs-to )
                (not (g src (g dst channels))))
           (not (g src
                   (g dst
                      (send-compute-message local-state i nbrs channels))))))

(defthm channel-lookup-after-send-compute-message-when-src-not-i
  (implies (not (equal src i))
           (equal (g src
                     (g dst
                        (send-compute-message local-state i nbrs channels)))
                  (g src
                     (g dst channels)))))

(defthm channel-nil-after-send-compute-message-when-src-not-i
  (implies (and (not (equal src i))
                (not (g src (g dst channels))))
           (not
            (g src
               (g dst
                  (send-compute-message local-state i nbrs channels))))))

;end support: send-compute-message-channel-lookup


;start support: lift-send-compute-message-to-channel-table
;; Lift the compute-send preservation theorem from one channel to one row and
;; then to the full channel table.

(defthm good-channel-p-of-send-compute-message
  (implies (and (good-channel-p src dst channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channel-p
            src
            dst
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
  :hints (("Goal'"
           :cases ((equal src i)))))

(defthm good-channel-row-p-of-send-compute-message
  (implies (and (good-channel-row-p src dsts channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channel-row-p
            src
            dsts
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
    :hints (("Goal"
           :induct (good-channel-row-p src dsts channels ids procs))))

(defthm good-channels-p-of-send-compute-message
  (implies (and (good-channels-p srcs dsts channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channels-p
            srcs
            dsts
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
      :hints (("Goal"
           :induct (good-channels-p srcs dsts channels ids procs))))


;end support: lift-send-compute-message-to-channel-table


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Normal system-step preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Combines the local-state update and compute-send preservation lemmas.


;start target: good-state-p-of-system-step-normal
;; Main target for :normal inputs: combine the local-state process update with
;; the preservation of outgoing compute-message sends.

(defthm good-state-p-of-system-step-normal
  (implies (and (good-state-p st)
                (equal (ttype input) :normal))
           (good-state-p (system-step st input))))


;end target: good-state-p-of-system-step-normal


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Checkpoint-entry/process-table support
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Snapshot-entry construction and process-table update lemmas used when starting
;; a checkpoint.


;start support: checkpoint-snapshot-entry-construction
;; Starting a checkpoint creates a new snapshot entry.  These lemmas show that
;; the new entry and the modified snapshot table preserve good-snapshots-p.

(defthm g-of-s-nil-nil
  (equal (g k (s j nil nil))
         nil)
  :hints (("Goal"
           :cases ((equal k j)))))

(defthm good-normal-msg-list-p-of-g-of-s-nil-nil
  (good-normal-msg-list-p (g k (s j nil nil))))

(defthm good-snapshot-entry-p-of-make-snapshot-entry
  (implies (and (true-listp waiting-marker-from)
                (subset waiting-marker-from nbrs-from-i))
           (good-snapshot-entry-p
            (make-snapshot-entry local-snap-shot
                                 waiting-marker-from
                                 j)
            nbrs-from-i)))

(defthm good-snapshots-p-of-set-snapshot-entry-general
  (implies
   (and (good-snapshots-p snapshot-ids
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    snapshot-ids
    (s :snapshots
       (s sid entry (snapshots p))
       p)
    nbrs-from-i
    ids))
  :hints (("Goal"

           :in-theory (disable good-snapshot-entry-p))

          ("Subgoal *1/4''"
           :cases ((equal sid (car snapshot-ids))))))

(defthm good-snapshots-p-of-set-snapshot-ids-field
  (implies
   (good-snapshots-p snapshot-ids
                     p
                     nbrs-from-i
                     ids)
   (good-snapshots-p snapshot-ids
                     (s :snapshot-ids new-snapshot-ids p)
                     nbrs-from-i
                     ids)))

(defthm good-snapshots-p-of-set-snapshot-entry-after-set-snapshot-ids
  (implies
   (and (good-snapshots-p snapshot-ids
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    snapshot-ids
    (s :snapshots
       (s sid entry (g :snapshots p))
       (s :snapshot-ids new-snapshot-ids p))
    nbrs-from-i
    ids))
  :hints
  (("Goal"
    :use ((:instance good-snapshots-p-of-set-snapshot-ids-field
                     (snapshot-ids snapshot-ids)
                     (p p)
                     (new-snapshot-ids new-snapshot-ids)
                     (nbrs-from-i nbrs-from-i)
                     (ids ids))

          (:instance good-snapshots-p-of-set-snapshot-entry-general
                     (snapshot-ids snapshot-ids)
                     (p (s :snapshot-ids new-snapshot-ids p))
                     (sid sid)
                     (entry entry)
                     (nbrs-from-i nbrs-from-i)
                     (ids ids)))
    :in-theory (disable good-snapshot-entry-p))))

(defthm good-snapshots-p-of-install-snapshot-entry
  (implies
   (and (good-snapshots-p (snapshot-ids p)
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    (snapshot-ids (install-snapshot-entry sid entry p))
    (install-snapshot-entry sid entry p)
    nbrs-from-i
    ids))
  :hints (("Goal"
	   :in-theory (disable good-snapshot-entry-p))))

;end support: checkpoint-snapshot-entry-construction


;start support: checkpoint-updated-process-goodness
;; start-checkpoint-helper increments the counter and installs a snapshot entry.
;; These lemmas show the selected process remains good after that update.

(defthm good-snapshots-p-of-set-counter
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from-i
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :counter val p)
                             nbrs-from-i
                             ids)))

(defthm good-proc-p-of-increment-counter
  (implies (good-proc-p p ids)
           (good-proc-p
            (s :counter
               (+ 1 (counter p))
               p)
            ids)))

(defthm good-proc-p-of-start-checkpoint-helper-updated-proc
  (implies
   (and (good-proc-p (g i procs) ids)
	(memberp i ids))
   (good-proc-p
    (g i (start-checkpoint-helper procs i))
    ids)))

;end support: checkpoint-updated-process-goodness


;start support: checkpoint-process-table-lift
;; Lift the updated-process proof to the whole process table.  The key split is
;; whether the current id in the induction is the process that started checkpointing.

(defthm good-procs-p-of-set-good-proc
  (implies (and (good-procs-p ids procs all-ids)
                (good-proc-p new-p all-ids))
           (good-procs-p ids
                         (s i new-p procs)
                         all-ids))
  :hints (("Goal"
           :induct (good-procs-p ids procs all-ids))
          ("Subgoal *1/2"
           :cases ((equal i (car ids))))))

(defthm g-of-start-checkpoint-helper-diff
  (implies
   (not (equal k i))
   (equal (g k (start-checkpoint-helper procs i))
          (g k procs))))

(defthm good-procs-p-of-start-checkpoint-helper-when-not-member
  (implies
   (not (memberp i ids))
   (equal (good-procs-p ids
                        (start-checkpoint-helper procs i)
                        all-ids)
          (good-procs-p ids procs all-ids))))

(defthm good-procs-p-of-start-checkpoint-helper
  (implies
   (and (good-procs-p ids procs all-ids)
        (memberp i ids)
	(subset ids all-ids)
        (true-listp ids)
        (uniquep ids))
   (good-procs-p
    ids
    (start-checkpoint-helper procs i)
    all-ids))
  :hints
  (("Goal"
    :in-theory (disable start-checkpoint-helper good-proc-p)
    :induct (good-procs-p ids procs all-ids))
      ("Subgoal *1/2"
    :cases ((equal i (car ids))))))


;end support: checkpoint-process-table-lift


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Generic outgoing-message send preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Generalizes compute-send preservation to any good message.  The two-procs
;; version supports proofs where process metadata is updated before sending.


;start definitions: process-table-compatibility-predicates
;; Compatibility predicates for comparing an old process table with an updated
;; one.  They are used when channels are preserved across process-table changes.

(defun snapshot-ids-subset-procs-p (ids procs1 procs2)
  (if (endp ids)
      t
    (and (subset (snapshot-ids (g (car ids) procs1))
                 (snapshot-ids (g (car ids) procs2)))
         (snapshot-ids-subset-procs-p (cdr ids) procs1 procs2))))

(defun same-nbrs-to-p (srcs procs1 procs2)
  (if (endp srcs)
      t
    (and (equal (nbrs-to (g (car srcs) procs1))
                (nbrs-to (g (car srcs) procs2)))
         (same-nbrs-to-p (cdr srcs) procs1 procs2))))

;end definitions: process-table-compatibility-predicates


;start support: change-procs-preserves-message-and-channel-goodness
;; If the updated process table keeps enough snapshot ids and the same outgoing
;; neighbors, then existing good messages/channels remain good under the new table.
;;
;; Because recovery-message well-formedness is now receiver-aware, the monotonicity
;; lemmas also require that the receiver/destination being checked is one of the
;; process ids covered by snapshot-ids-subset-procs-p.

(defthm some-proc-has-snapshot-id-p-monotone
  (implies
   (and (snapshot-ids-subset-procs-p ids procs1 procs2)
        (some-proc-has-snapshot-id-p sid ids procs1))
   (some-proc-has-snapshot-id-p sid ids procs2)))

(defthm good-msg-p-change-procs
  (implies
   (and (good-msg-p msg dst ids procs1)
        (memberp dst ids)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-msg-p msg dst ids procs2)))

(defthm good-msg-list-p-change-procs
  (implies
   (and (good-msg-list-p msgs dst ids procs1)
        (memberp dst ids)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-msg-list-p msgs dst ids procs2)))

(defthm good-channel-p-change-procs
  (implies
   (and (good-channel-p src dst channels ids procs1)
        (memberp dst ids)
        (equal (nbrs-to (g src procs1))
               (nbrs-to (g src procs2)))
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channel-p src dst channels ids procs2)))

(defthm good-channel-row-p-change-procs
  (implies
   (and (good-channel-row-p src dsts channels ids procs1)
        (subset dsts ids)
        (equal (nbrs-to (g src procs1))
               (nbrs-to (g src procs2)))
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channel-row-p src dsts channels ids procs2)))

(defthm good-channels-p-change-procs
  (implies
   (and (good-channels-p srcs dsts channels ids procs1)
        (subset dsts ids)
        (same-nbrs-to-p srcs procs1 procs2)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channels-p srcs dsts channels ids procs2)))

;end support: change-procs-preserves-message-and-channel-goodness


;start support: one-generic-channel-send
;; General one-channel send lemma for any message that is good for the channel's
;; destination.  This reuses the same combined channel-update reasoning developed
;; for compute messages.

(defthm good-msg-list-p-of-snoc-good-msg
  (implies (and (good-msg-list-p msgs dst ids procs)
                (good-msg-p msg dst ids procs))
           (good-msg-list-p (snoc msgs msg)
                            dst
                            ids
                            procs))
  :hints (("Goal"
           :induct (snoc msgs msg))))

(defthm one-generic-send-update-disjunct
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         dst
                         ids
                         procs)
        ;; The new message is appended only to channel i -> j.  Therefore it
        ;; only needs to be good for destination j.
        (good-msg-p msg j ids procs))
   (or (not (equal dst j))
       (not (equal src i))
       (good-msg-list-p
        (snoc (g i (g j channels)) msg)
        dst
        ids
        procs))))

(defthm good-msg-list-p-of-one-generic-send-update
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         dst
                         ids
                         procs)
        (good-msg-p msg j ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i
                (snoc (g i (g j channels)) msg)
                (g j channels))
             channels)))
    dst
    ids
    procs))
  :hints
  (("Goal"
    :do-not '(generalize fertilize)
    :use ((:instance good-msg-list-p-of-setting-channel-combined
                     (src src)
                     (dst dst)
                     (i i)
                     (j j)
                     (channels channels)
                     (ids ids)
                     (procs procs)
                     (val (snoc (g i (g j channels)) msg)))

          (:instance one-generic-send-update-disjunct
                     (src src)
                     (dst dst)
                     (i i)
                     (j j)
                     (channels channels)
                     (ids ids)
                     (procs procs)
                     (msg msg))))))

;end support: one-generic-channel-send


;start support: lift-generic-send-to-channel-table
;; Lift send-msg-all-outgoing-channels from message lists to channel rows and
;; the full channel table.
;;
;; Since good-msg-p is now destination-aware, the message must be good for every
;; destination in the outgoing send list Nbrs.  That is captured by
;; good-msg-for-dsts-p.

(defthm good-msg-list-p-of-channel-after-send-msg-all-outgoing-channels
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         dst
                         ids
                         procs)
        (good-msg-for-dsts-p msg nbrs ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    dst
    ids
    procs))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-lookup-after-send-msg-all-outgoing-channels-when-src-not-i
  (implies
   (not (equal src i))
   (equal
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    (g src
       (g dst channels))))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-lookup-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs
  (implies
   (not (memberp dst nbrs))
   (equal
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    (g src
       (g dst channels))))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-nil-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs-to
  (implies
   (and (not (memberp dst nbrs-to))
        (subset nbrs nbrs-to)
        (not (g src (g dst channels))))
   (not
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))))
  :hints
  (("Goal"
    :use ((:instance not-memberp-when-subset-and-not-memberp
                     (xs nbrs)
                     (ys nbrs-to)
                     (a dst))

          (:instance channel-lookup-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs
                     (src src)
                     (dst dst)
                     (msg msg)
                     (i i)
                     (nbrs nbrs)
                     (channels channels))))))

(defthm good-channel-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channel-p src dst channels ids procs)
        (good-msg-for-dsts-p msg nbrs ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channel-p
    src
    dst
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :cases ((equal src i)))))

(defthm good-channel-row-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channel-row-p src dsts channels ids procs)
        (good-msg-for-dsts-p msg nbrs ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channel-row-p
    src
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :induct (good-channel-row-p src dsts channels ids procs))))

(defthm good-channels-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channels-p srcs dsts channels ids procs)
        (good-msg-for-dsts-p msg nbrs ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channels-p
    srcs
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :induct (good-channels-p srcs dsts channels ids procs))))

(defthm good-channels-p-of-send-msg-all-outgoing-channels-two-procs
  (implies
   (and (good-channels-p srcs dsts channels ids procs1)

        ;; the new message must be good for every destination that receives it
        ;; under the final process table
        (good-msg-for-dsts-p msg nbrs ids procs2)

        ;; procs2 keeps same outgoing-neighbor structure
        (same-nbrs-to-p srcs procs1 procs2)

        ;; procs2 contains at least all snapshot ids from procs1
        (snapshot-ids-subset-procs-p ids procs1 procs2)

        ;; the channel table is checked only over valid process ids
        (subset dsts ids)

        ;; sends only go to legal outgoing neighbors under procs2
        (subset nbrs (nbrs-to (g i procs2))))

   (good-channels-p
    srcs
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs2)))

;end support: lift-generic-send-to-channel-table


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Start-checkpoint preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; start-checkpoint-helper preserves neighbor structure, monotonically adds the
;; new snapshot id, and sends a good marker message.


;start support: marker-message-goodness-after-start-checkpoint
;; After start-checkpoint-helper installs the new sid at process i, the marker
;; message carrying that sid is good under the updated process table.

(defthm good-msg-p-of-create-marker-message-after-start-checkpoint-helper
  (implies (memberp i ids)
           (good-msg-p
            (create-marker-message
             local-state
             (list i (counter (g i procs))))
            dst
            ids
            (start-checkpoint-helper procs i))))

(defthm good-msg-for-dsts-p-of-create-marker-message-after-start-checkpoint-helper
  (implies (memberp i ids)
           (good-msg-for-dsts-p
            (create-marker-message
             local-state
             (list i (counter (g i procs))))
            dsts
            ids
            (start-checkpoint-helper procs i))))

;end support: marker-message-goodness-after-start-checkpoint


;start support: start-checkpoint-neighbor-preservation
;; Installing snapshot data and incrementing the counter do not change outgoing
;; neighbors.  This discharges the same-nbrs-to-p requirement for channel sends.

(defthm nbrs-to-of-install-snapshot-entry
  (equal (nbrs-to (install-snapshot-entry sid entry p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-counter
  (equal (nbrs-to (s :counter val p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-snapshots
  (equal (nbrs-to (s :snapshots val p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-snapshot-ids
  (equal (nbrs-to (s :snapshot-ids val p))
         (nbrs-to p)))

(defthm nbrs-to-of-g-of-start-checkpoint-helper
  (equal (nbrs-to (g src (start-checkpoint-helper procs i)))
         (nbrs-to (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm same-nbrs-to-p-of-start-checkpoint-helper
  (same-nbrs-to-p srcs procs
        (start-checkpoint-helper procs i))
  :hints
  (("Goal"
    :induct (same-nbrs-to-p srcs procs
                            (start-checkpoint-helper procs i))
    :in-theory (disable start-checkpoint-helper))))

;end support: start-checkpoint-neighbor-preservation


;start support: start-checkpoint-snapshot-id-monotonicity
;; start-checkpoint-helper only adds the new snapshot id; it does not remove old
;; ids.  This provides the snapshot-id monotonicity needed by the two-procs lemma.

(defthm subset-snapshot-ids-of-g-of-start-checkpoint-helper
  (subset (snapshot-ids (g k procs))
          (snapshot-ids (g k (start-checkpoint-helper procs i))))
  :hints
  (("Goal"
    :cases ((equal k i)))))

(defthm snapshot-ids-subset-procs-p-of-start-checkpoint-helper
  (snapshot-ids-subset-procs-p
   ids
   procs
   (start-checkpoint-helper procs i))
  :hints
  (("Goal"
    :induct (snapshot-ids-subset-procs-p
             ids
             procs
             (start-checkpoint-helper procs i))
    :in-theory (disable start-checkpoint-helper))))

;end support: start-checkpoint-snapshot-id-monotonicity


;start target: good-state-p-of-system-step-start-checkpoint
;; Main target for :start-checkpoint inputs: update the initiating process, prove
;; the marker message is good, and preserve the outgoing marker sends.

(defthm good-state-p-of-system-step-start-checkpoint
  (implies (and (good-state-p st)
                (equal (ttype input) :start-checkpoint)
		(memberp (pid input) (proc-ids st)))
           (good-state-p (system-step st input)))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p
			start-checkpoint-helper
                        make-snapshot-entry
                        install-snapshot-entry
			create-marker-message))))


;end target: good-state-p-of-system-step-start-checkpoint


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Start-recovery preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; start-recovery-helper changes only recovery-related fields, preserves neighbor
;; and snapshot-id structure, and sends a good recovery message.


;start support: start-recovery-field-preservation
;; start-recovery-helper changes only recovery-control fields.  Snapshot tables,
;; neighbor lists, snapshot ids, and counters remain unchanged.

(defthm snapshots-of-g-of-start-recovery-helper
  (equal
   (snapshots (g src (start-recovery-helper procs i)))
   (snapshots (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm good-snapshots-p-of-g-of-start-recovery-helper-general
  (implies
   (good-snapshots-p snapshot-ids
                     (g src procs)
                     nbrs-from
                     ids)
   (good-snapshots-p snapshot-ids
                     (g src (start-recovery-helper procs i))
                     nbrs-from
                     ids))
  :hints
  (("Goal"
    :in-theory (disable start-recovery-helper)
    :cases ((equal src i)))))

(defthm nbrs-from-of-g-of-start-recovery-helper
  (equal
   (nbrs-from (g src (start-recovery-helper procs i)))
   (nbrs-from (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i))
    :in-theory (enable start-recovery-helper))))

(defthm nbrs-to-of-g-of-start-recovery-helper
  (equal
   (nbrs-to (g src (start-recovery-helper procs i)))
   (nbrs-to (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i))
    :in-theory (enable start-recovery-helper))))

(defthm snapshot-ids-of-g-of-start-recovery-helper
  (equal
   (snapshot-ids (g src (start-recovery-helper procs i)))
   (snapshot-ids (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm subset-waiting-recovery-from-of-g-i-of-start-recovery-helper
  (subset
   (waiting-recovery-from
    (g i (start-recovery-helper procs i)))
   (nbrs-from (g i procs))))

(defthm counter-of-g-of-start-recovery-helper
  (equal
   (counter (g src (start-recovery-helper procs i)))
   (counter (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm proc-status-of-g-i-of-start-recovery-helper
  (equal
   (proc-status
    (g i (start-recovery-helper procs i)))
   :recovering))

(defthm waiting-recovery-from-of-g-i-of-start-recovery-helper
  (equal
   (waiting-recovery-from
    (g i (start-recovery-helper procs i)))
   (nbrs-from (g i procs))))

;end support: start-recovery-field-preservation


;start support: start-recovery-process-table-lift
;; The recovering process remains good, and all other processes are unchanged.
;; Lift this to good-procs-p for the whole process table.

(defthm good-proc-p-of-start-recover-helper-updated-proc
  (implies
   (and (good-proc-p (g i procs) ids)
	(memberp i ids))
   (good-proc-p
    (g i (start-recovery-helper procs i))
    ids))
    :hints
  (("Goal"
    :in-theory (disable start-recovery-helper))))

(defthm g-of-start-recovery-helper-when-not-equal
  (implies
   (not (equal k i))
   (equal
    (g k (start-recovery-helper procs i))
    (g k procs))))

(defthm good-procs-p-of-start-recovery-helper
  (implies
   (and (good-procs-p ids procs all-ids)
        (true-listp ids)
	(subset ids all-ids)
        (uniquep ids)
        (memberp i ids))
   (good-procs-p
    ids
    (start-recovery-helper procs i)
    all-ids))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p start-recovery-helper)
    :induct (good-procs-p ids procs all-ids))
   ("Subgoal *1/2"
    :cases ((equal i (car ids))))))

;end support: start-recovery-process-table-lift


;start support: start-recovery-neighbor-and-snapshot-compatibility
;; Prove the compatibility facts required when recovery messages are sent under
;; the updated process table: same outgoing neighbors and preserved snapshot ids.

(defthm same-nbrs-to-p-of-start-recovery-helper
  (same-nbrs-to-p srcs procs
        (start-recovery-helper procs i))
  :hints
  (("Goal"
    :induct (same-nbrs-to-p srcs procs
                            (start-recovery-helper procs i))
    :in-theory (disable start-recovery-helper))))

(defthm subset-snapshot-ids-of-g-of-start-recovery-helper
  (subset (snapshot-ids (g k procs))
          (snapshot-ids (g k (start-recovery-helper procs i))))
  :hints
  (("Goal"
    :cases ((equal k i)))))

(defthm snapshot-ids-subset-procs-p-of-start-recovery-helper
  (snapshot-ids-subset-procs-p
   ids
   procs
   (start-recovery-helper procs i))
  :hints
  (("Goal"
    :induct (snapshot-ids-subset-procs-p
             ids
             procs
             (start-recovery-helper procs i))
    :in-theory (disable start-recovery-helper))))

(defthm sid-known-by-procs-p-of-start-recovery-helper
  (equal (sid-known-by-procs-p sid dsts
                               (start-recovery-helper procs i))
         (sid-known-by-procs-p sid dsts procs))
  :hints
  (("Goal"
    :induct (sid-known-by-procs-p sid dsts procs)
    :in-theory (disable start-recovery-helper))))

;end support: start-recovery-neighbor-and-snapshot-compatibility


;start support: recovery-message-goodness-after-start-recovery
;; A recovery message uses an existing snapshot id from the recovering process.
;; These lemmas establish that the sid exists before and after the helper update.

(defthm memberp-snapshot-ids-of-start-recovery-helper
  (equal
   (memberp sid
            (snapshot-ids
             (g src (start-recovery-helper procs i))))
   (memberp sid
            (snapshot-ids
             (g src procs)))))

(defthm some-proc-has-snapshot-id-p-of-start-recovery-helper
  (implies
   (and (memberp i ids)
        (some-proc-has-snapshot-id-p sid ids procs))
   (some-proc-has-snapshot-id-p
    sid
    ids
    (start-recovery-helper procs i)))
  :hints
  (("Goal"
    :in-theory (disable start-recovery-helper))))

(defthm some-proc-has-car-snapshot-id-before-recovery
  (implies
   (and (memberp i ids)
        (consp (snapshot-ids (g i procs))))
   (some-proc-has-snapshot-id-p
    (car (snapshot-ids (g i procs)))
    ids
    procs))
  :hints
  (("Goal"
    :induct (some-proc-has-snapshot-id-p
             (car (snapshot-ids (g i procs)))
             ids
             procs))
   ("Subgoal *1/2"
    :cases ((equal i (car ids))))))

(defthm some-proc-has-car-snapshot-id-after-recovery
  (implies
   (and (memberp i ids)
        (consp (snapshot-ids (g i procs))))
   (some-proc-has-snapshot-id-p
    (car (snapshot-ids (g i procs)))
    ids
     (start-recovery-helper procs i))))

(defthm good-msg-for-dsts-p-of-create-recovery-message-after-start-recovery-helper
  (implies
   (sid-known-by-procs-p sid dsts procs)
   (good-msg-for-dsts-p
    (create-recovery-message local-state sid)
    dsts
    ids
    (start-recovery-helper procs i)))
  :hints
  (("Goal"
    :in-theory (disable start-recovery-helper
                        create-recovery-message))))

;end support: recovery-message-goodness-after-start-recovery


;start support: nonempty-snapshot-ids-for-recovery
;; good-proc-p requires :init to be present in the snapshot-id list, so any good
;; process has a nonempty snapshot-id list for choosing a recovery sid.

(defthm consp-snapshot-ids-of-g-when-good-procs-p
  (implies
   (and (good-procs-p ids procs all-ids)
        (memberp i ids))
   (consp (snapshot-ids (g i procs)))))

;end support: nonempty-snapshot-ids-for-recovery


;start target: good-state-p-of-system-step-recover
;; Main target for :recover inputs: update the initiating process to recovering,
;; create a good recovery message, and preserve all outgoing recovery sends.

(defthm good-state-p-of-system-step-recover
  (implies (and (good-state-p st)
                (equal (ttype input) :recover)
		(memberp (pid input) (proc-ids st))
                ;; Because recovery messages are now receiver-aware, every
                ;; outgoing neighbor that receives the recovery message must
                ;; already know the selected recovery sid.
                (sid-known-by-procs-p
                 (car (snapshot-ids (g (pid input) (procs st))))
                 (nbrs-to (g (pid input) (procs st)))
                 (procs st)))
           (good-state-p (system-step st input)))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p
			start-recovery-helper
			create-recovery-message))))

;end target: good-state-p-of-system-step-recover


