(in-package "ACL2")

;;   distributed-checkpointingh.lisp
;;   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

;; Author: Sandip Ray
;; Date: Tue May  6 09:10:58 2025

;; In this book, we formalize a version of the Chandy-Lamport distributed snapshot
;; protocol using ACL2.  The goal is to have a formalization of correctness in a
;; generic form applicable to *any* reasonable snapshot algorithm.  In order to be
;; able to show that the protocol is correct using this correctness criterion we
;; need to augment the protocol in certain ways which might be thought of as
;; "completion" of the protocol.

;; Effort Breakdown:

;; - I spent two hour on May 8, creating an abstract
;;   structure for the distribued protocol.  The key reason
;;   for the time it took was an initial simplification I
;;   was trying to make, which was to associate incoming
;;   channel with each process.  However, that seemed wrong
;;   eventually, since a process as to have incoming
;;   channels corresponding to multiple processes, which
;;   ultimately made me change the channel into a 2-D array
;;   indexed by process indices i and j (indicating a
;;   channel from i to j).


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 1: Generic functions and their properties                    
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; I define memberp and subset below, merely because I hate the fact that the
;; Lisp member function does not return a Boolean.  

(defun memberp (e l)
  (cond ((endp l) nil)
        ((equal e (first l)) t)
        (t (memberp e (rest l)))))


(defun subset (x y) 
  (cond ((endp x) t)
        (t (and (memberp (first x) y)
                (subset (rest x) y)))))


(defun uniquep (x)
  (if (endp x) t
    (and (not (memberp (first x) (rest x)))
         (uniquep (rest x)))))


(defun rev1 (x)
  (if (endp x)
      nil
    (append (rev1 (rest x))
            (list (first x)))))


(defun add-to-set-equal1 (x xs)
  (if (memberp x xs)
      xs
    (cons x xs)))

;; The function snoc adds an element at the "end" of a list.  The reason for
;; the name should be rather obvious.

(defun snoc (x e) 
  (if (endp x) (list e)
    (cons (first x) (snoc (rest x) e))))


;;the following function removes all occurences of item e from a list x

(defun remove-from-list (x e)
  (if (endp x)
      nil
    (if (equal e (first x))
        (remove-from-list (rest x) e)
      (cons (first x)
            (remove-from-list (rest x) e)))))
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 2: Auxiliary macros and functions for access and updates
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


;; I use the records book, principally so that I don't have to deal with
;; hypothesis on "well-formedness" of the state structure.  I hate to write
;; such hypothesis and carry along with the invariants that such structure is
;; preserved.  In this section I also build the macros I'm going to use for
;; access and updates to the different state components.

(include-book "misc/records" :dir :system)

;; The system state is given by (1) the state of all the processes, (2) the
;; state of the stable storage corresponding to all the processes, and (3) the
;; state of the communication channels.  For this level of formalization I don't
;; care that much whether the channel is a message passing interface or shared
;; memory.  I'll just call everything the channel.

;; I may add more components to the state.  If I do, I will
;; add them here.

(defmacro procs     (s) `(g :procs ,s))
(defmacro channels  (s) `(g :channels ,s))
(defmacro proc-ids  (s) `(g :proc-ids ,s)) ;list of process-ids

;; A process will have a local state, some outgoing
;; channels, and some incoming channels.  I feel that when
;; we start modeling the protocol we will need to put more
;; stuff, like a place for its stable snapshot.  But for
;; now, this is sufficient.  The way I am modeling channels
;; is as a 2D array (or record).  chans[i][j] (which I model
;; as (g i (g j chans)) gives me th channel from index i to
;; index j.

(defmacro local-state           (p) `(g :local-state ,p))
(defmacro channel-state (i j chans) `(g ,i (g ,j ,chans)))

;; Neighbor lists are STORED in each process record.
(defmacro nbrs-to               (p) `(g :nbrs-to ,p))
(defmacro nbrs-from             (p) `(g :nbrs-from ,p))

;; For a distributed system with checkpointing, the input
;; will need to specify which transition etc.

(defmacro pid   (input) `(g :pid ,input))
(defmacro ttype (input) `(g :ttype ,input))
(defmacro sender (input) `(g :sender ,input))

;; We also need to write an "update" macro.  That will be really important in
;; order for us to succinctly model the protocol.

(defun update-macro (upds result)
  (declare (xargs :guard (keyword-value-listp upds)))
  (if (endp upds) result
    (update-macro (cddr upds)
                  (list 's (car upds) (cadr upds) result))))

(defmacro update (old &rest updates)
  (declare (xargs :guard (keyword-value-listp updates)))
  (update-macro updates old))

(defmacro >st (&rest upds) `(update st ,@upds))
(defmacro >p  (&rest upds) `(update p  ,@upds))
(defmacro >_ (&rest upds) `(update nil ,@upds))

;; (defmacro >channel (i j val channels) `(s ,i (s ,j ,val ,channels) ,channels))

(defmacro >channel (i j val channels)
  `(s ,j
      (s ,i ,val (g ,j ,channels))
      ,channels))

(defmacro append-to-record-list (key val record)
  `(let* ((existing (g ,key ,record))
          (updated (append existing (list ,val))))
     (s ,key updated ,record)))

;; Each process can be in :normal, :crashed or :recovering state. We keep checkpointing 
;; separate from process status. Checkpointing status is kept in the snapshot records

(defmacro proc-status           (p) `(g :proc-status ,p))
(defmacro waiting-recovery-from (p) `(g :waiting-recovery-from ,p))
(defmacro counter               (p) `(g :counter ,p))

;; ------------------------------------------------------------------
;; Snapshot bookkeeping: accessors, entry structure, and update helpers
;;
;; This block defines the basic interface for managing per-process
;; snapshot state.  Each process keeps:
;;   (1) a list of snapshot ids currently known to it, and
;;   (2) a table mapping each snapshot id to its corresponding
;;       snapshot entry.
;;
;; A snapshot entry stores all information associated with one
;; checkpoint instance:
;;   - :status               = current progress of the snapshot
;;                             (e.g., :checkpointing or :done)
;;   - :local-snap-shot      = saved local state of the process
;;   - :channel-snapshots    = recorded in-transit messages for
;;                             incoming channels
;;   - :waiting-marker-from  = incoming neighbors from which a
;;                             marker is still expected
;;
;; The macros below provide convenient access to snapshot-related
;; fields in process records, message records, and snapshot entries.
;; The functions then build and maintain this snapshot structure:
;;   - make-snapshot-entry      creates a fresh entry for a new snapshot
;;   - add-snapshot-id          adds a snapshot id if not already present
;;   - set-snapshot-entry       stores an entry under a given snapshot id
;;   - install-snapshot-entry   updates both the id list and snapshot table
;;   - update-snapshot-entry    edits an existing snapshot entry in place
;;
;; In short, this block organizes how snapshot metadata is represented,
;; created, looked up, and updated during checkpointing and recovery.
;; ------------------------------------------------------------------

;; Get the list of snapshot ids currently tracked by a process.
(defmacro snapshot-ids          (p) `(g :snapshot-ids ,p))

;; Get the snapshot table/map from a process record.
(defmacro snapshots             (p) `(g :snapshots ,p))

;; Look up the snapshot entry for snapshot id sid in process p.
(defmacro snapshot-entry    (sid p) `(g ,sid (snapshots ,p)))


;; Extract snapshot id from a message record. applicable for marker & recovery msgs
(defmacro sid (msg) `(g :sid ,msg))

;;msg type, :normal, :marker, :recovery
(defmacro msg-type (msg) `(g :msg-type ,msg))


;; Read the status field from a snapshot entry.
(defmacro snapshot-status (entry)
  `(g :status ,entry))

;; Read the saved local snapshot from a snapshot entry.
(defmacro snapshot-local-snap-shot (entry)
  `(g :local-snap-shot ,entry))

;; Read the per-channel snapshot record from a snapshot entry.
(defmacro snapshot-channel-snapshots (entry)
  `(g :channel-snapshots ,entry))


;; Read the list of incoming channels still waiting for a marker.
(defmacro snapshot-waiting-marker-from (entry)
  `(g :waiting-marker-from ,entry))

;; Convenience macro to update fields of a local variable named entry.
(defmacro >entry (&rest upds)
  `(update entry ,@upds))


;; Create a fresh snapshot entry.
;; local-snap-shot      = saved local state
;; waiting-marker-from  = incoming channels still waiting for marker arrival
;; j                    = channel that delivered the first marker;
;;                        if j is nil, initialize with no channel entry yet
;;                        which is applicable for the process who started checkpointing
(defun make-snapshot-entry (local-snap-shot waiting-marker-from j)
  (let ((cs (if j
                (s j nil nil)   ;; explicit empty snapshot for channel j
              nil)))
    (>_ :status :checkpointing
        :local-snap-shot local-snap-shot
        :channel-snapshots cs
        :waiting-marker-from waiting-marker-from)))

;; Add sid to the snapshot-id list if it is not already present.
(defun add-snapshot-id (sid ids)
  (if (memberp sid ids)
      ids
    (cons  sid ids)))

;; Store a snapshot entry under sid in process p.
(defun set-snapshot-entry (sid entry p)
  (let* ((snaps (snapshots p))
         (snaps (s sid entry snaps)))
    (s :snapshots snaps p)))

;; Install a new snapshot entry and register its sid in the process.
(defun install-snapshot-entry (sid entry p)
  (let* ((snapshot-ids   (add-snapshot-id sid (snapshot-ids p)))
         (snapshots (snapshots p))
         (snapshots (s sid entry snapshots)))
    (update p
            :snapshot-ids snapshot-ids
            :snapshots snapshots)))

;; Update selected fields of the snapshot entry for sid in process p.
(defmacro update-snapshot-entry (sid p &rest upds)
  `(let* ((entry (snapshot-entry ,sid ,p))
          (entry (update entry ,@upds)))
     (set-snapshot-entry ,sid entry ,p)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 3: Stubbed Functions and other constraints
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; I am defining the neighbors of the process of index i in
;; procs.  I will likely need to have some conditions, like
;; the neighbors graph is connected.  And I will add that to
;; the constraints in the function.  The idea of the
;; neighbors is to think about which processes I can send
;; the message to. If some process is in the nbrs list for
;; me then I will send a message to it, and append it to its
;; incoming channel.  By modeling this way I avoid having
;; the deal with outgoing and incoming channels separately. 

;; (encapsulate
;;  (((make-nbrs-to * *) => *)
;;   ((make-nbrs-from * *) => *))
 
;;   (local (defun make-nbrs-to (i proc-ids) (declare (ignore i proc-ids)) nil))
;;   (local (defun make-nbrs-from (i proc-ids) (declare (ignore i proc-ids)) nil)))


;; The following protocol-dependent operations could have been introduced
;; with defstub, but we use encapsulate instead so that their argument
;; structure is explicit and easy to inspect.
;;
;; These functions represent the abstract application behavior that is
;; layered underneath the checkpointing/recovery protocol.  During normal
;; execution, a process evolves in two conceptually different ways:
;;
;;   1. Local computation without receiving a message.
;;   2. State update caused by receiving a message from a neighbor.
;;
;; For that reason we keep two separate local-state update functions:
;;
;;   - update-local-state-normal:
;;       models an internal/local transition of the process during an
;;       ordinary step when no message is being received. But a process
;;       may send a send a msg.
;;
;;   - update-local-state-rcv:
;;       models the state transition caused by consuming a message from
;;       neighbor nbr.
;;
;; In addition, a process may choose to send messages to only some of its
;; outgoing neighbors during a normal step.  The predicate
;; message-to-send? determines whether a message should be sent on a given
;; outgoing channel, and create-compute-message constructs that ordinary
;; application-level message.
;;
;; The checkpointing protocol itself also introduces two special control
;; messages:
;;
;;   - create-marker-message:
;;       constructs the marker used to propagate snapshot initiation.
;;
;;   - create-recovery-message:
;;       constructs the recovery message used to coordinate rollback.
;;

(encapsulate
 (((update-local-state-rcv * * *) => *)
  ((update-local-state-normal *) => *)
  ((message-to-send? * *) => *)
  ((create-compute-message * *) => *))

 (local
  (defun update-local-state-rcv (local-state msg nbr)
    (declare (ignore local-state msg nbr))
    nil))

 (local
  (defun update-local-state-normal (local-state)
    (declare (ignore local-state))
    nil))

 (local
  (defun message-to-send? (local-state nbr)
    (declare (ignore local-state nbr))
    nil))

 (local
  (defun create-compute-message (local-state nbr)
    (declare (ignore local-state nbr))
    (>_ :msg-type :normal)))

 (defthm msg-type-of-create-compute-message
   (equal (msg-type (create-compute-message local-state nbr))
          :normal)))


(defun create-marker-message (local-state sid)
  (declare (ignore local-state))
  (>_ :msg-type :marker
      :sid sid))

(defun create-recovery-message (local-state sid)
  (declare (ignore local-state))
  (>_ :msg-type :recovery
      :sid sid))

(defthm msg-type-of-create-marker-message
  (equal (msg-type (create-marker-message local-state sid))
         :marker))

(defthm sid-of-create-marker-message
  (equal (sid (create-marker-message local-state sid))
         sid))

(defthm msg-type-of-create-recovery-message
  (equal (msg-type (create-recovery-message local-state sid))
         :recovery))

(defthm sid-of-create-recovery-message
  (equal (sid (create-recovery-message local-state sid))
         sid))

;; ------------------------------------------------------------------
;; Channel update and marker-handling logic
;;
;; This block contains the core operations used to propagate and process
;; snapshot marker messages.
;;
;; First, we define basic channel manipulation utilities:
;;   - remove-message-from-channel removes the head message from an
;;     incoming channel after that message has been consumed.
;;   - send-msg-all-outgoing-channels appends the same message to all
;;     outgoing channels in a given neighbor list.
;;
;; Next, we define the handling of marker messages for the checkpoint
;; protocol.  A marker message for snapshot id sid can arrive at a
;; process either as the first marker seen for that snapshot, or as a
;; later marker on another incoming channel.
;;
;;   - handle-first-marker-msg:
;;       This is the case where process i sees sid for the first time.
;;       The process records its current local state as the snapshot,
;;       initializes the set of incoming channels still waiting for a
;;       marker, removes j from that set because j has already delivered
;;       the first marker, installs the new snapshot entry, forwards the
;;       marker on all outgoing channels, and removes the received marker
;;       from channel j -> i.
;;
;;   - handle-non-first-marker-msg:
;;       This handles later marker arrivals for an already known snapshot.
;;       The process simply marks channel j as having delivered its marker,
;;       updates the waiting-marker-from set, and changes the snapshot
;;       status to :done once markers have been received on all incoming
;;       channels.  It also removes the marker message from channel j -> i.
;;
;;   - handle-marker-msg:
;;       This dispatcher checks whether sid is already present in the
;;       process's snapshot-id list.  If not, the marker is treated as
;;       the first one for that snapshot; otherwise it is treated as a
;;       subsequent marker.
;;
;; So the organization is:
;;   channel utilities -> first-marker handling -> later-marker handling
;;   -> dispatch based on whether the snapshot id is already known.
;; ------------------------------------------------------------------

;; Remove the first msg from a incoming channel and return channels
(defun remove-message-from-channel (nbr i channels)
    (let* ((channel (channel-state nbr i channels))
           (channel (if channel (cdr channel) nil))
           (channels (>channel nbr i  channel channels)))
      channels))


; Send msg along all outgoing channels in nbrs.
(defun send-msg-all-outgoing-channels (msg i nbrs channels)
  (cond ((endp nbrs) channels)
        (t
         (let* ((nbr      (first nbrs))
                (channels (send-msg-all-outgoing-channels msg i (rest nbrs) channels))
                (channel  (channel-state i nbr channels))
                (channel  (snoc channel msg))
                (channels (>channel i nbr channel channels)))
           channels))))

(defun handle-first-marker-msg (st i j msg)
  (let* ((procs               (procs st))
         (p                   (g i procs))
         (nbrs-from           (nbrs-from p))
         (nbrs-to             (nbrs-to p))
         (local-state         (local-state p))
         (channels            (channels st))
         (sid                 (sid msg))
         (channels            (remove-message-from-channel j i channels))
         ;; for this snapshot-id, wait for markers from all incoming channels except j
         (waiting-marker-from (remove-from-list nbrs-from j))
         ;; create and install fresh snapshot entry for sid
         (entry               (make-snapshot-entry local-state waiting-marker-from j))
         (p                   (install-snapshot-entry sid entry p))
         ;; send marker for this sid on all outgoing channels
         (channels            (send-msg-all-outgoing-channels msg i nbrs-to channels))
         (procs               (s i p procs))
         (st                  (>st :procs procs
                                   :channels channels)))
    st))


(defun handle-non-first-marker-msg (st i j msg)
  (let* ((sid                 (sid msg))
         (procs               (procs st))
         (p                   (g i procs))
         (entry               (snapshot-entry sid p))

         ;; marker for channel j -> i has arrived, so stop waiting for j
         (waiting-marker-from (snapshot-waiting-marker-from entry))
         (waiting-marker-from (remove-from-list waiting-marker-from j))

         ;; snapshot is complete if no incoming markers remain
         (status              (if (endp waiting-marker-from)
                                  :done
                                (snapshot-status entry)))

         (entry               (update entry
                                      :waiting-marker-from waiting-marker-from
                                      :status status))
         (p                   (set-snapshot-entry sid entry p))

         ;; remove marker message itself from incoming channel j -> i
         (channels            (channels st))
         (channels            (remove-message-from-channel j i channels))
         (procs               (s i p procs))
         (st                  (>st :procs procs
                                   :channels channels)))
    st))



(defun handle-marker-msg (st i j msg)
  (let* ((sid (sid msg))
         (procs (procs st))
         (p (g i procs))
         (snapshot-ids (snapshot-ids p)))
    (if (memberp sid snapshot-ids)
        (handle-non-first-marker-msg st i j msg)
      (handle-first-marker-msg st i j msg))))


;; ------------------------------------------------------------------
;; Recovery replay and recovery-message handling
;;
;; This block defines how a process restores its state during recovery
;; and how recovery messages are propagated through the system.
;;
;; The first two functions implement replay of the recorded snapshot
;; history.  When a process rolls back to a saved local snapshot, it
;; must also re-apply the in-transit messages that were recorded for
;; that snapshot.
;;
;;   - replay-msgs-on-channel:
;;       replays the saved messages of one incoming channel, in their
;;       original order, by repeatedly applying update-local-state-rcv.
;;
;;   - replay-channel-snapshots:
;;       extends this replay across all incoming neighbors by fetching
;;       each channel's recorded message list from the snapshot entry
;;       and replaying them one channel at a time.
;;
;; The next functions handle recovery control messages.
;;
;;   - handle-first-recovery-msg:
;;       this is the first recovery message seen by process i.  The
;;       process restores its saved local snapshot for sid, replays the
;;       recorded incoming-channel messages, forwards the recovery
;;       message to all outgoing neighbors, removes the received message
;;       from channel j -> i, and enters :recovering mode.  It then
;;       waits for recovery messages from all other incoming neighbors.
;;
;;   - handle-non-first-recovery-msg:
;;       this handles later recovery messages while the process is
;;       already recovering.  In this case, no further rollback or
;;       replay is needed.  The process simply records that neighbor j
;;       has responded, removes the received message, and returns to
;;       :normal once all expected recovery messages have arrived.
;;
;;   - handle-recovery-msg:
;;       dispatches between the two cases above.  If the process is in
;;       :normal state, this must be the first recovery message;
;;       otherwise it is treated as a later one.
;;
;; So the organization is:
;;   replay saved snapshot traffic -> handle first recovery message ->
;;   handle later recovery messages -> dispatch by recovery status.
;; ---------------------------------------------------------------
(defun replay-msgs-on-channel (local-state msgs j)
  (cond ((endp msgs)
         local-state)
        (t
         (replay-msgs-on-channel
          (update-local-state-rcv local-state (first msgs) j)
          (rest msgs)
          j))))

(defun replay-channel-snapshots (local-state channel-snaps nbrs-from)
  (cond ((endp nbrs-from)
         local-state)
        (t
         (let* ((ch          (first nbrs-from))
                (msgs        (g ch channel-snaps))
                (local-state (replay-msgs-on-channel local-state msgs ch)))
           (replay-channel-snapshots local-state
                                     channel-snaps
                                     (rest nbrs-from))))))

(defun handle-first-recovery-msg (st i j msg)
  (let* ((sid           (sid msg))
         (procs         (procs st))
         (channels      (channels st))
         (p             (g i procs))
         (nbrs-from     (nbrs-from p))
         (nbrs-to       (nbrs-to p))
         (entry         (snapshot-entry sid p))
         (local-state   (snapshot-local-snap-shot entry))
         (channel-snaps (snapshot-channel-snapshots entry))
         (local-state   (replay-channel-snapshots local-state
                                                  channel-snaps
                                                  nbrs-from))
         (waiting       (remove-from-list nbrs-from j))
         (channels      (remove-message-from-channel j i channels))
         (channels      (send-msg-all-outgoing-channels msg i nbrs-to channels))
         (p             (update p
                                :local-state local-state
                                :proc-status :recovering
                                :waiting-recovery-from waiting))
         (procs         (s i p procs)))
    (>st :procs procs
         :channels channels)))

(defun handle-non-first-recovery-msg (st i j msg)
  (declare (ignore msg))
  (let* ((procs         (procs st))
         (channels      (channels st))
         (p             (g i procs))
         (waiting       (waiting-recovery-from p))
         (waiting       (remove-from-list waiting j))
         (proc-status   (if (endp waiting)
                            :normal
                          :recovering))
         (channels      (remove-message-from-channel j i channels))
         (p             (update p
                                :proc-status proc-status
                                :waiting-recovery-from waiting))
         (procs         (s i p procs)))
    (>st :procs procs
         :channels channels)))


(defun handle-recovery-msg (st i j msg)
  (let* ((procs       (procs st))
         (p           (g i procs))
         (proc-status (proc-status p)))
    (if (equal proc-status :normal)
        (handle-first-recovery-msg st i j msg)
	(handle-non-first-recovery-msg st i j msg))))

;; ------------------------------------------------------------------
;; Normal-message processing and snapshot recording
;;
;; This block defines how ordinary application messages are handled,
;; especially when checkpointing is in progress.
;;
;; The key issue is that, while a snapshot is still open, some incoming
;; messages may need to be recorded as part of the channel snapshot.
;; In particular, if a snapshot is currently :checkpointing and process i
;; is still waiting for the marker from channel j, then a normal message
;; arriving on j is considered in-transit for that snapshot and must be
;; appended to the saved message list for channel j.
;;
;;   - record-msg-in-snapshots:
;;       scans all snapshot ids currently tracked by the process and,
;;       for each active snapshot that is still waiting for marker j,
;;       records msg in that snapshot's per-channel message history.
;;
;; Once this recording rule is defined, ordinary message handling splits
;; into two cases.
;;
;;   - handle-normal-msg-core:
;;       this is the standard case.  The process consumes the message,
;;       updates its local state, records the message in any still-open
;;       snapshots where it counts as in-transit, removes the message
;;       from the incoming channel, and writes the updated process state
;;       back into the system state.
;;
;;   - ignore-normal-msg:
;;       this is used during recovery when process i is still waiting for
;;       a recovery message from sender j.  In that case, ordinary
;;       application messages from j are ignored and simply removed from
;;       the channel.
;;
;;   - handle-normal-msg:
;;       dispatches between the two behaviors above.  If the receiver is
;;       recovering and still waiting for j, the message is ignored;
;;       otherwise it is handled normally.
;; ------------------------------------------------------------------

(defun record-msg-in-snapshots (snapshots snapshot-ids j msg)
  (cond ((endp snapshot-ids)
         snapshots)
        (t
         (let* ((sid       (first snapshot-ids))
                (rest-ids  (rest snapshot-ids))
                (snapshots (record-msg-in-snapshots snapshots rest-ids j msg))
                (entry     (g sid snapshots))
                (status    (snapshot-status entry))
                (waiting   (snapshot-waiting-marker-from entry)))
           (if (and (equal status :checkpointing)
                    (memberp j waiting))
               (let* ((cs        (snapshot-channel-snapshots entry))
                      (cs        (append-to-record-list j msg cs))
                      (entry     (update entry :channel-snapshots cs))
                      (snapshots (s sid entry snapshots)))
                 snapshots)
               snapshots)))))

(defun handle-normal-msg-core (st i j msg)
  (let* ((procs        (procs st))
         (p            (g i procs))
         (local-state  (local-state p))
         (local-state  (update-local-state-rcv local-state msg j))
         (snapshot-ids (snapshot-ids p))
         (snapshots    (snapshots p))
         (snapshots    (record-msg-in-snapshots snapshots snapshot-ids j msg))
         (p            (update p
                               :local-state local-state
                               :snapshots snapshots))
         (channels     (channels st))
         (channels     (remove-message-from-channel j i channels))
         (procs        (s i p procs)))
    (>st :procs procs
         :channels channels)))

(defun ignore-normal-msg (st i j msg)
  (declare (ignore msg))
  (let* ((channels (channels st))
         (channels (remove-message-from-channel j i channels)))
    (>st :procs (procs st)
         :channels channels)))

(defun handle-normal-msg (st i j msg)
  (let* ((procs   (procs st))
         (p       (g i procs))
         (status  (proc-status p))
         (waiting (waiting-recovery-from p)))
    (if (and (equal status :recovering)
             (memberp j waiting))
        (ignore-normal-msg st i j msg)
	(handle-normal-msg-core st i j msg))))


;; ------------------------------------------------------------------
;; Receiving one message from an incoming channel
;;
;; This block provides the entry point for a receive step.
;;
;;   - get-msg-from-channel:
;;       reads the head message from the incoming channel nbr -> i
;;       without yet modifying the channel state.
;;
;;   - step-rcv:
;;       performs one receive transition for process i from sender j.
;;       It first fetches the message at the head of channel j -> i,
;;       examines its type, and then dispatches to the corresponding
;;       handler:
;;         :normal    -> ordinary application-message handling
;;         :marker    -> checkpoint marker handling
;;         :recovery  -> recovery-message handling
;;
;; Thus, this section separates message inspection from message-specific
;; processing, and serves as the main dispatcher for all receive events.
;; ------------------------------------------------------------------

(defun get-msg-from-channel (nbr i channels)
  (let ((channel (channel-state nbr i channels)))
    (if (consp channel)
        (first channel)
      nil)))

(defun step-rcv (st i j)
  (let* (
         (channels (channels st))
	 (msg (get-msg-from-channel j i channels))
	 (msg-type (msg-type msg)))
	 (case msg-type
	   (:normal   (handle-normal-msg st i j msg))
	   (:marker   (handle-marker-msg st i j msg))
	   (:recovery (handle-recovery-msg st i j msg))
	   )))


;; ------------------------------------------------------------------
;; Normal computation step and application-level message sending
;;
;; This block models ordinary process behavior outside the special
;; checkpointing and recovery control flow.
;;
;; A normal step has two parts:
;;   (1) the process may send ordinary application messages to some of
;;       its outgoing neighbors, and
;;   (2) it updates its own local state by taking an internal step.
;;
;; The messages sent here are "compute messages," meaning ordinary
;; application messages, as opposed to the marker and recovery messages
;; introduced by the checkpointing protocol itself.
;; ------------------------------------------------------------------


(defun send-compute-message (local-state i nbrs channels)
  (cond
   ((endp nbrs)
    channels)

   ((message-to-send? local-state (first nbrs))
    (let* ((nbr      (first nbrs))
           (channel  (channel-state i nbr channels))
           (msg      (create-compute-message local-state nbr))
           (channel  (snoc channel msg))
           (channels (>channel i nbr channel channels)))
      (send-compute-message local-state
                            i
                            (rest nbrs)
                            channels)))

   (t
    (send-compute-message local-state
                          i
                          (rest nbrs)
                          channels))))

(defun step-normal (st i)
(let* ((procs (procs st))
       (channels (channels st))
       (p (g i procs))
       (nbrs-to (nbrs-to p))
       (local (local-state p))
       (channels (send-compute-message local i nbrs-to channels))
       (local (update-local-state-normal local))
       (p     (>p  :local-state local))
       (procs (s i p procs))
       (st (>st :procs procs
         	:channels channels)))
       st))
 
;; ------------------------------------------------------------------
;; Start a new checkpoint at process i.
;;
;; A fresh snapshot id is created from the process id and its local
;; counter.  The current local state is saved as the local snapshot,
;; and the new snapshot entry is initialized to wait for marker
;; messages from all incoming neighbors.  The snapshot entry is then
;; installed in the process state, the counter is incremented for
;; future checkpoints, and a marker message for this snapshot is sent
;; on all outgoing channels.
;; ------------------------------------------------------------------

(defun f2 (procs input)
  (let* ((i     (pid input))
         (p     (g i procs))
         (sid   (list i (counter p)))
         (entry (make-snapshot-entry
                 (local-state p)
                 (nbrs-from p)
                 nil))
         (p-new (s :counter
                   (+ 1 (counter p))
                   (install-snapshot-entry sid entry p))))
    (s i p-new procs)))

(defun step-checkpoint (st i)
  (let* ((procs               (procs st))
         (channels            (channels st))
         (p                   (g i procs))
         (nbrs-to             (nbrs-to p))
         (nbrs-from           (nbrs-from p))
         (local-state         (local-state p))
         (ctr                 (counter p))

         ;; snapshot id = (process-id counter)
         (sid                 (list i ctr))

         ;; initiator waits for markers from all incoming channels
         (waiting-marker-from nbrs-from)

         ;; install snapshot entry for this sid
         (entry               (make-snapshot-entry local-state waiting-marker-from nil))
         (p                   (install-snapshot-entry sid entry p))

         ;; increment counter for future snapshots
         (p                   (update p :counter (+ 1 ctr)))

         ;; send marker on all outgoing channels
         (msg                 (create-marker-message local-state sid))
         (channels            (send-msg-all-outgoing-channels msg i nbrs-to channels))

         (procs               (s i p procs))
         (st                  (>st :procs procs
                                   :channels channels)))
    st))



; Crash process i by setting its process status to :crashed.
(defun step-crash (st i)
  (let* ((procs (procs st))
         (p     (g i procs))
         (p     (update p :proc-status :crashed))
         (procs (s i p procs)))
    (>st :procs procs
         :channels (channels st))))

;; ------------------------------------------------------------------
;; Recover process i from its most recent completed snapshot.
;;
;; The process selects its latest saved snapshot id, restores the saved
;; local state from that snapshot, and replays the recorded in-transit
;; messages from all incoming channels.  It then creates a recovery
;; message for that snapshot and sends it on all outgoing channels.
;; Finally, the process enters :recovering mode and records that it is
;; waiting for recovery messages from all incoming neighbors.
;; ------------------------------------------------------------------

(defun step-recover (st i)
  (let* ((procs         (procs st))
         (channels      (channels st))
         (p             (g i procs))
         (nbrs-from     (nbrs-from p))
         (nbrs-to       (nbrs-to p))

         ;; choose the most recent snapshot id
         (sid           (car (snapshot-ids p)))

         ;; restore saved snapshot state
         (entry         (snapshot-entry sid p))
         (local-state   (snapshot-local-snap-shot entry))
         (channel-snaps (snapshot-channel-snapshots entry))

         ;; replay recorded in-transit messages
         (local-state   (replay-channel-snapshots local-state
                                                  channel-snaps
                                                  nbrs-from))

         ;; create and send recovery message on all outgoing channels
         (msg           (create-recovery-message local-state sid))
         (channels      (send-msg-all-outgoing-channels msg i nbrs-to channels))

         ;; enter recovering mode and wait for recovery from all incoming channels
         (p             (update p
                                :local-state local-state
                                :proc-status :recovering
                                :waiting-recovery-from nbrs-from))
         (procs         (s i p procs)))
    (>st :procs procs
         :channels channels)))

(defstub complete-this () => *)

(defun system-step (st input)
  (let* (
	 (i (pid input))
         (j (sender input))
         (ttype (ttype input)))
    (case ttype
      (:receive          (step-rcv st i j))
      (:normal           (step-normal st i))
      (:start-checkpoint (step-checkpoint st i))
      (:crash            (step-crash st i))
      (:recover          (step-recover st i))
      (:nop               st)
      (t st))))

;; ------------------------------------------------------------------
;; Predicates for global checkpointing/recovery status and input legality.
;;
;; This block defines a small hierarchy of predicates that inspect the
;; distributed system state at different levels.
;;
;; First, it checks whether a single process has any snapshot whose
;; status is still :checkpointing. It then lifts that check to the
;; whole system by scanning all process ids and asking whether any
;; process still has an unfinished snapshot. In parallel, it also
;; defines predicates that scan the process table to determine whether
;; any process is currently in :recovering status.
;;
;; These system-level predicates are then used to define legal-inputp,
;; which enforces simple protocol restrictions on the allowed next input.
;;
;; In particular:
;;   - a :crash input is illegal while the system is checkpointing
;;     or recovering,
;;   - a :start-checkpoint input is illegal while any process is
;;     recovering, and
;;   - a :recover input is illegal while any snapshot is still
;;     checkpointing.
;;
;; These restrictions rule out overlapping protocol phases that would
;; interfere with the intended checkpoint/recovery behavior.
;; ------------------------------------------------------------------

(defun any-checkpointing-snapshot-in-ids-p (snapshot-ids p)
  (cond ((endp snapshot-ids)
         nil)
        (t
         (let* ((sid   (first snapshot-ids))
                (entry (snapshot-entry sid p)))
           (or (equal (snapshot-status entry) :checkpointing)
               (any-checkpointing-snapshot-in-ids-p (rest snapshot-ids) p))))))

(defun proc-has-checkpointing-snapshot-p (p)
  (any-checkpointing-snapshot-in-ids-p (snapshot-ids p) p))

(defun any-proc-checkpointing-p (proc-ids procs)
  (cond ((endp proc-ids)
         nil)
        (t
         (let* ((pid (first proc-ids))
                (p   (g pid procs)))
           (or (proc-has-checkpointing-snapshot-p p)
               (any-proc-checkpointing-p (rest proc-ids) procs))))))

(defun any-snapshot-checkpointing-p (st)
  (let* ((ids   (proc-ids st))
         (procs (procs st)))
    (any-proc-checkpointing-p ids procs)))

(defun any-proc-recovering-p (proc-ids procs)
  (cond ((endp proc-ids)
         nil)
        (t
         (let* ((pid (first proc-ids))
                (p   (g pid procs)))
           (or (equal (proc-status p) :recovering)
               (any-proc-recovering-p (rest proc-ids) procs))))))

(defun any-process-recovering-p (st)
  (let* ((ids   (proc-ids st))
         (procs (procs st)))
    (any-proc-recovering-p ids procs)))

(defun legal-inputp (st input)
  (let ((ttype (ttype input)))
    (cond
      ;; no crash during recovery or checkpointing
      ((and (or (any-process-recovering-p st)
                (any-snapshot-checkpointing-p st))
            (equal ttype :crash))
       nil)

      ;; no new recovery during recovery
      ;; no recovery during a checkpointing
      ((and (or (any-process-recovering-p st)
		(any-snapshot-checkpointing-p st))
            (equal ttype :recover))
       nil)
      
      ;; no start-checkpoint during recovery
      ((and (any-process-recovering-p st)
            (equal ttype :start-checkpoint))
       nil)

      (t
       t))))



;; (defun legal-input-sequencep (st inputs)
;;   (if (endp inputs)
;;       t
;;     (and (legal-inputp st (first inputs))
;;          (legal-input-sequencep
;;           (system-step st (first inputs))
;;           (rest inputs)))))


;; ------------------------------------------------------------------
;; Specification-level step functions.
;;
;; These functions define the simpler specification semantics used for
;; comparison with the full checkpointing system. 
;;
;; - spec-step-rcv processes one received message by updating the local
;;   state of process i and removing the message from channel j -> i.
;;
;; - spec-step-normal performs one normal process step by sending any
;;   compute messages on outgoing channels and then updating the local
;;   state of process i.
;; ------------------------------------------------------------------

(defun spec-step-rcv (st i j)
  (let* ((channels    (channels st))
         (msg         (get-msg-from-channel j i channels))
         (procs       (procs st))
         (p           (g i procs))
         (local-state (local-state p))
         (local-state (update-local-state-rcv local-state msg j))
         (p           (update p :local-state local-state))
         (channels    (remove-message-from-channel j i channels))
         (procs       (s i p procs)))
    (>st :procs procs
         :channels channels)))

(defun spec-step-normal (st i)
(let* ((procs (procs st))
       (channels (channels st))
       (p (g i procs))
       (nbrs-to (nbrs-to p))
       (local (local-state p))
       (channels (send-compute-message local i nbrs-to channels)) 
       (local (update-local-state-normal local))
       (p     (>p  :local-state local))
       (procs (s i p procs))
       (st (>st :procs procs
         	:channels channels)))
       st))

(defun spec-step (st input)
  (let* ((i     (pid input))
         (j     (sender input))
         (ttype (ttype input)))
    (case ttype
      (:receive   (spec-step-rcv st i j))
      (:normal    (spec-step-normal st i))
      (t st))))



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;  run function
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(defun run-imp (st inputs)
  (if (endp inputs)
      st
    (run-imp
     (system-step st (first inputs))
     (rest inputs))))

(defun run-imp-trace (st inputs)
  (if (endp inputs)
      (list st)
    (cons st
          (run-imp-trace
           (system-step st (first inputs))
           (rest inputs)))))

(defun run-spec (st inputs)
  (if (endp inputs)
      st
    (run-spec
     (spec-step st (first inputs))
     (rest inputs))))

(defun run-spec-trace (st inputs)
  (if (endp inputs)
      (list st)
    (cons st
          (run-spec-trace
           (spec-step st (first inputs))
           (rest inputs)))))



(defun legal-input-sequencep (st inputs)
  (declare (xargs :measure (acl2-count inputs)))
  (if (endp inputs)
      t
    (and (legal-inputp st (first inputs))
         (legal-input-sequencep
          (system-step st (first inputs))
          (rest inputs)))))



;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 3: Initial State Formation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; Abstract process-id constructor

(encapsulate
 (((make-proc-ids) => *))

 (local
  (defun make-proc-ids ()
    '(0 1 2)))

 (defthm make-proc-ids-true-listp
   (true-listp (make-proc-ids)))

 (defthm make-proc-ids-uniquep
   (uniquep (make-proc-ids))))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Abstract neighbor constructors
;;
;; These construct the initial incoming/outgoing neighbor lists from a
;; process id and the full global process-id list.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(encapsulate
 (((make-nbrs-to * *) => *)
  ((make-nbrs-from * *) => *))

 (local
  (defun make-nbrs-to (i proc-ids)
    (declare (ignore i proc-ids))
    nil))

 (local
  (defun make-nbrs-from (i proc-ids)
    (declare (ignore i proc-ids))
    nil))

 (defthm make-nbrs-to-true-listp
   (true-listp (make-nbrs-to i proc-ids)))

 (defthm make-nbrs-from-true-listp
   (true-listp (make-nbrs-from i proc-ids)))

 (defthm make-nbrs-to-subset-of-proc-ids
   (subset (make-nbrs-to i proc-ids) proc-ids))

 (defthm make-nbrs-from-sset-of-proc-ids
     (subset (make-nbrs-from i  proc-ids) proc-ids))
 )


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Abstract initial local-state constructor
;;
;; The application-specific local state remains abstract.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(encapsulate
 (((make-init-local-state *) => *))

 (local
  (defun make-init-local-state (i)
    (declare (ignore i))
    nil)))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Concrete construction of the initial process table
;;
;; Each process record stores:
;;   :local-state
;;   :nbrs-to
;;   :nbrs-from
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun make-one-proc (i all-ids)
  (>_ :local-state (make-init-local-state i)
      :nbrs-to     (make-nbrs-to i all-ids)
      :nbrs-from   (make-nbrs-from i all-ids)))

(defun make-procs-aux (ids all-ids)
  (if (endp ids)
      nil
    (let* ((i     (first ids))
           (p     (make-one-proc i all-ids))
           (procs (make-procs-aux (rest ids) all-ids)))
      (s i p procs))))

(defun make-procs (ids)
  (make-procs-aux ids ids))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Concrete construction of the initial channel table
;;
;; Channel table is a 2-D record:
;;   channel-state src dst channels
;;
;; Initially, every channel is empty (nil).
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun make-channel-row (srcs)
  (if (endp srcs)
      nil
    (s (first srcs)
       nil
       (make-channel-row (rest srcs)))))

(defun make-channels-aux ( srcs dsts)
  (if (endp dsts)
      nil
    (s (first dsts)
       (make-channel-row srcs)
       (make-channels-aux srcs (rest dsts)))))

(defun make-channels (ids)
  (make-channels-aux ids ids))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Initial snapshot installation
;;
;; Snapshot id for the initial snapshot is :init.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun make-init-snapshot-entry (init-local-state)
  (>_ :status :done
      :local-snap-shot init-local-state
      :channel-snapshots nil
      :waiting-marker-from nil))

(defun install-initial-snapshot (p)
  (let* ((init-local   (local-state p))
         (entry        (make-init-snapshot-entry init-local))
         (snapshot-ids (add-snapshot-id :init nil))
         (snaps        (s :init entry nil)))
    (update p
            :proc-status :normal
            :waiting-recovery-from nil
            :counter 0
            :snapshot-ids snapshot-ids
            :snapshots snaps)))

(defun install-initial-snapshots (ids procs)
  (if (endp ids)
      procs
    (let* ((i     (first ids))
           (p     (g i procs))
           (p     (install-initial-snapshot p))
           (procs (s i p procs)))
      (install-initial-snapshots (rest ids) procs))))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Initial implementation state
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun make-initial-state ()
  (let* ((ids      (make-proc-ids))
         (procs    (make-procs ids))
         (channels (make-channels ids))
         (procs    (install-initial-snapshots ids procs)))
    (>_ :proc-ids ids
        :procs procs
        :channels channels)))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Initial spec state
;;
;; Spec processes need only local-state / nbrs fields, so make-procs is
;; already sufficient here.  No initial snapshot installation is needed.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun make-initial-spec-state ()
  (let* ((ids      (make-proc-ids))
         (procs    (make-procs ids))
         (channels (make-channels ids)))
    (>_ :proc-ids ids
        :procs procs
        :channels channels)))


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 3: Compressed Input Generation 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; ------------------------------------------------------------------
;; High-level algorithm for compressed input generation
;;
;; Goal:
;;   Transform an implementation-level input sequence containing
;;   checkpointing and recovery protocol actions into a spec-level
;;   input sequence that preserves only the behavior relevant to the
;;   abstract computation.
;;
;; Overall pipeline:
;;
;;   1. Run the implementation from the initial state to obtain the
;;      full execution trace.
;;
;;   2. Scan the input sequence to locate each recovery input.  For
;;      each recovery input, identify:
;;        - the checkpoint-start index of the snapshot that will be
;;          used for that recovery,
;;        - the recovery-start index itself, and
;;        - the snapshot id (sid) being recovered.
;;
;;   3. For each (checkpoint-start, recovery-start, sid) segment:
;;        a. Scan forward from checkpoint-start until checkpointing
;;           for sid is complete, building cut metadata:
;;             - inputs-before-cut
;;             - buffered inputs-after-cut
;;        b. Scan forward from recovery-start until recovery is done,
;;           building recovery metadata:
;;             - inputs-during-recovery
;;        c. Build one compressed segment input by concatenating:
;;             - inputs-before-cut
;;             - replayed buffered inputs-after-cut in recovery replay order
;;             - preserved inputs-during-recovery
;;
;;   4. Replace each original checkpoint-to-recovery region by its
;;      compressed segment.  This stitching is done from right to left,
;;      so later recoveries naturally overwrite earlier recoveries that
;;      depend on the same checkpoint.
;;
;;   5. For untouched regions copied directly from the original input
;;      sequence, convert implementation-only inputs into spec no-ops
;;      (:nop).  In particular, receives of marker or recovery messages
;;      must not remain as spec receives.
;;
;; Result:
;;   A spec-compliant input sequence containing only meaningful normal
;;   actions and normal receives, with checkpoint/recovery protocol
;;   traffic removed or turned into no-ops.
;; ------------------------------------------------------------------


;; ------------------------------------------------------------------
;; Subsection A: Recovery-segment discovery
;;
;; This block identifies the recovery episodes in the implementation
;; run.  For each recovery input, it determines which checkpoint that
;; recovery rolls back to and packages the information into a recovery-
;; segment record.
;;
;; Main idea:
;;   - look at the pre-state of a recovery input,
;;   - extract the most recent snapshot id used by that process,
;;   - find the matching start-checkpoint input that created that sid,
;;   - return a record describing the segment.
;;
;; These records are later used to drive the cut scan, the recovery
;; scan, and the final compressed-segment generation.
;; ------------------------------------------------------------------

(defmacro rs-checkpoint-start (r)
  `(g :checkpoint-start ,r))

(defmacro rs-recovery-start (r)
  `(g :recovery-start ,r))

(defmacro rs-sid (r)
  `(g :sid ,r))


(defun latest-snapshot-id-for-proc (st i)
  ;; Return the most recent snapshot-id stored for process i.
  ;; This is the snapshot that recovery will use.
  (let* ((procs (procs st))
         (p     (g i procs)))
    (car (snapshot-ids p))))

(defun snapshot-count-for-proc (st i)
  ;; Return how many snapshot-ids process i currently has.
  ;; If this is 1, we treat it as the initial snapshot only.
  (let* ((procs (procs st))
         (p     (g i procs)))
    (len (snapshot-ids p))))

(defun recover-input-p (input)
  ;; Check whether INPUT is a recovery input.
  (equal (ttype input) :recover))

(defun checkpoint-start-match-p (input st sid)
  ;; Check whether this input/state position corresponds to the
  ;; start-checkpoint step that created SID.
  ;;
  ;; We match:
  ;;   1. input type is :start-checkpoint
  ;;   2. pid of the input matches the pid inside SID
  ;;   3. (pid, counter-at-that-state) = SID
  ;;
  ;; This works because snapshot ids are created as (list pid counter).
  (let* ((i     (pid input))
         (procs (procs st))
         (p     (g i procs)))
    (and (equal (ttype input) :start-checkpoint)
         (equal i (car sid))
         (equal sid
                (list i
                      (counter p))))))

(defun find-checkpoint-start-left (inputs trace idx sid)
  ;; Scan left from input/trace index IDX down to 0 to find the
  ;; checkpoint-start position whose created snapshot-id matches SID.
  ;;
  ;; INPUTS[k] is checked together with TRACE[k], where TRACE[k]
  ;; is the pre-state for INPUTS[k].
  (let ((input (nth idx inputs))
        (st    (nth idx trace)))
    (if (checkpoint-start-match-p input st sid)
        idx
      (if (zp idx)
          0
        (find-checkpoint-start-left
         inputs trace (- idx 1) sid)))))

(defun recovery-segment-for-index (inputs trace x)
  ;; Assume INPUTS[x] is a :recover input.
  ;;
  ;; Build a record with fields:
  ;;   :checkpoint-start
  ;;   :recovery-start
  ;;   :sid
  ;;
  ;; where:
  ;;   checkpoint-start = input index of the matching start-checkpoint
  ;;                    = 0 if recovery before a checkpoint input
  ;;                    meaning recovers back to initial state
  ;;   recovery-start   = input index x of the recover input
  ;;   sid              = snapshot id used by that recovery
  (let* ((input            (nth x inputs))
         (i                (pid input))
         (pre-state        (nth x trace))
         (sid              (latest-snapshot-id-for-proc pre-state i))
         (snap-count       (snapshot-count-for-proc pre-state i))
         (checkpoint-start
          (if (equal snap-count 1)
              0
            (find-checkpoint-start-left inputs trace (- x 1) sid))))
    (>_ :checkpoint-start checkpoint-start
        :recovery-start x
        :sid sid)))

(defun collect-recovery-segments-aux (full-inputs trace inputs idx)
  ;; Scan INPUTS from left to right.
  ;;
  ;; For every recover input encountered, collect a record with fields:
  ;;   :checkpoint-start
  ;;   :recovery-start
  ;;   :sid
  (if (endp inputs)
      nil
    (if (recover-input-p (first inputs))
        (cons (recovery-segment-for-index full-inputs trace idx)
              (collect-recovery-segments-aux
               full-inputs trace (rest inputs) (+ 1 idx)))
      (collect-recovery-segments-aux
       full-inputs trace (rest inputs) (+ 1 idx)))))

(defun collect-recovery-segments-from-trace (inputs trace)
  ;; INPUTS and TRACE must be aligned so that:
  ;;   TRACE[x]   = pre-state of INPUTS[x]
  ;;   TRACE[x+1] = post-state of INPUTS[x]
  ;;
  ;; Extracts all recovery segments as records.
  (collect-recovery-segments-aux inputs trace inputs 0))

(defun collect-recovery-segments (st inputs)
  ;; Wrapper that first executes the implementation to get the trace,
  ;; then extracts all recovery segments as records.
  (let ((trace (run-imp-trace st inputs)))
    (collect-recovery-segments-from-trace inputs trace)))


;; ------------------------------------------------------------------
;; Subsection B: Cut metadata and checkpoint-side compression
;;
;; This block defines the metadata used while scanning from a checkpoint
;; start until the corresponding checkpoint is complete.
;;
;; The cut metadata records:
;;   - sid                     = snapshot being tracked
;;   - proc-ids                = all process ids
;;   - cut-not-taken           = processes that have not yet taken their cut
;;   - waiting-marker-from     = per-process list of senders whose marker
;;                               has not yet arrived
;;   - inputs-before-cut       = inputs that occur before the receiver
;;                               (or process) has taken its cut
;;   - inputs-after-cut        = buffered normal receives that must later
;;                               be replayed during recovery
;;
;; Intuition:
;;   - before a process takes its cut, normal behavior is preserved
;;     immediately;
;;   - after a process has taken its cut, only those receives that are
;;     still on channels waiting for a marker are buffered for replay;
;;   - once checkpointing completes, the cut metadata contains exactly
;;     the prefix and buffered replay information needed to reconstruct
;;     the recovered computation.
;; ------------------------------------------------------------------

(defmacro cm-sid (m)
  `(g :sid ,m))

(defun cm-proc-ids (m)
  (g :proc-ids m))

(defun cm-cut-not-taken (m)
  (g :cut-not-taken m))

(defun cm-waiting-marker-from (m)
  (g :waiting-marker-from m))

(defun cm-inputs-before-cut (m)
  (g :inputs-before-cut m))

(defun cm-inputs-after-cut (m)
  (g :inputs-after-cut m))

(defun cm-waiting-marker-for (m i)
  (g i (cm-waiting-marker-from m)))

(defun cm-set-waiting-marker-for (m i xs)
  (s :waiting-marker-from
     (s i xs (cm-waiting-marker-from m))
     m))

(defun cm-cut-not-taken-p (m i)
  (memberp i (cm-cut-not-taken m)))

(defun cm-remove-cut-not-taken (m i)
  (s :cut-not-taken
     (remove1-equal i (cm-cut-not-taken m))
     m))

(defun cm-add-before-cut (m input)
  (s :inputs-before-cut
     (append (cm-inputs-before-cut m) (list input))
     m))

(defun cm-after-cut-get (m i j)
  (let* ((rec-i (g i (cm-inputs-after-cut m))))
    (g j rec-i)))

(defun cm-after-cut-append (m i j input)
  (let* ((all   (cm-inputs-after-cut m))
         (rec-i (g i all))
         (old   (g j rec-i))
         (rec-i (s j (append old (list input)) rec-i))
         (all   (s i rec-i all)))
    (s :inputs-after-cut all m)))

(defun cut-done-p (m)
  (if (equal (cm-sid m) :init)
      t
    (endp (cm-cut-not-taken m))))

(defun make-inputs-after-cut-for-proc (nbrs)
  (if (endp nbrs)
      nil
    (s (first nbrs)
       nil
       (make-inputs-after-cut-for-proc (rest nbrs)))))

(defun make-inputs-after-cut (proc-ids procs)
  (if (endp proc-ids)
      nil
      (let* ((i         (first proc-ids))
	     (p (g i procs))
             (nbrs      (nbrs-from p))
             (entry-i   (make-inputs-after-cut-for-proc nbrs))
             (rest-recs (make-inputs-after-cut (rest proc-ids) procs)))
      (s i entry-i rest-recs))))

(defun make-empty-waiting-marker-from (proc-ids)
  (if (endp proc-ids)
      nil
    (s (first proc-ids)
       nil
       (make-empty-waiting-marker-from (rest proc-ids)))))

(defun make-cut-meta (sid initiator st)
  (let* ((procs    (procs st))
         (proc-ids (proc-ids st))
	 (p        (g initiator procs))
         (nbrs     (nbrs-from p))
         (m        nil)
         (m        (s :inputs-after-cut
                      (make-inputs-after-cut proc-ids procs)
                      m))
         (m        (s :inputs-before-cut nil m))
         (m        (s :waiting-marker-from
                      (s initiator
                         nbrs
                         (make-empty-waiting-marker-from proc-ids))
                      m))
         (m        (s :cut-not-taken
                      (remove1-equal initiator proc-ids)
                      m))
         (m        (s :proc-ids proc-ids m))
         (m        (s :sid sid m)))
    m))

;; ------------------------------------------------------------------
;; Cut-phase step processing
;;
;; These functions implement the checkpoint-side scan one input at a
;; time.  They inspect each implementation input together with the
;; corresponding pre-state from the trace and update the cut metadata.
;;
;; Cases:
;;   - :normal
;;       preserve it only if the process has not yet taken its cut.
;;
;;   - :receive carrying :marker
;;       update cut-taken / waiting-marker-from information if sid matches.
;;       ignore the input is sid not matches (situation while multiple
;;       checkpointing is happening concurrently)
;;
;;   - :receive carrying :normal
;;       preserve it immediately if the receiver has not taken its cut;
;;       otherwise buffer it only if that channel is still waiting for
;;       a marker.
;;
;;   - protocol-only traffic that does not contribute to the spec
;;       leaves the metadata unchanged.
;; ------------------------------------------------------------------

(defun process-cut-normal (input m)
  (let ((i (pid input)))
    (if (cm-cut-not-taken-p m i)
        (cm-add-before-cut m input)
      m)))

(defun process-cut-marker-receive (i j st m)
  (let* ((procs (procs st)))
    (if (cm-cut-not-taken-p m i)
        ;; first marker for i: i now takes its cut
        (let* ((p    (g i procs))
	       (nbrs (nbrs-from p))
               (ws   (remove1-equal j nbrs))
               (m    (cm-remove-cut-not-taken m i)))
          (cm-set-waiting-marker-for m i ws))
      ;; later marker for i: just remove sender j from waiting set
      (cm-set-waiting-marker-for
       m i
       (remove1-equal j (cm-waiting-marker-for m i))))))


(defun process-cut-normal-receive (input i j m)
  (if (cm-cut-not-taken-p m i)
      (cm-add-before-cut m input)
    (if (memberp j (cm-waiting-marker-for m i))
        (cm-after-cut-append m i j input)
      m)))


(defun current-msg-for-receive (input st)
  ;; Replace SRC with your actual sender accessor for receive inputs.
  (let* ((i        (pid input))
         (j        (sender input))
         (channels (channels st)))
    (get-msg-from-channel j i channels)))

(defun process-cut-receive (input st m)
  ;; Handle one :receive input during the cut-building phase.
  ;; if for the receive marker, sid do not match that input is dropped too
  (let* ((i   (pid input))
         (j   (sender input))   ;; replace SRC with your sender accessor
         (msg (current-msg-for-receive input st))
         (sid (cm-sid m)))
    (cond
     ((and (equal (msg-type msg) :marker)
           (equal (sid msg) sid))
      (process-cut-marker-receive i j st m))

     ((equal (msg-type msg) :normal)
      (process-cut-normal-receive input i j m))

     (t
      m))))

(defun process-cut-step (input st m)
  ;; Process one implementation input while scanning from cp-start
  ;; until checkpoint completion.
  (cond
   ((equal (ttype input) :start-checkpoint)
    ;; Usually only the initiator's start-checkpoint matters here.
    ;; Since make-cut-meta already accounts for the initiator having
    ;; taken its cut, we do nothing.
    ;; If this is checkpointing input for a new sid we drop that too
    m)

   ((equal (ttype input) :normal)
    (process-cut-normal input m))

   ((equal (ttype input) :receive)
    (process-cut-receive input st m))

   (t
    m)))


(defmacro cut-result-idx (r)
  `(g :cut-done-index ,r))

(defmacro cut-result-meta (r)
  `(g :cut-meta ,r))

(defmacro recovery-result-idx (r)
  `(g :recovery-done-index ,r))

(defmacro recovery-result-meta (r)
  `(g :recovery-meta ,r))

;; ------------------------------------------------------------------
;; Cut-phase scan
;;
;; Starting from checkpoint-start, scan the aligned input suffix and
;; trace until checkpointing for the current sid is complete.
;;
;; Return:
;;   - :cut-done-index   = first index at which checkpointing is done
;;   - :cut-meta         = final cut metadata
;;
;; For sid = :init, cut-done is immediate, since there is no actual
;; checkpoint protocol to complete.
;; ------------------------------------------------------------------

(defun scan-until-cut-done-aux (inputs trace idx m)
  ;; Scan left-to-right until checkpoint completion.
  ;; TRACE[idx] is the pre-state of INPUTS[idx].
  ;; Returns a record with fields:
  ;;   :cut-done-index
  ;;   :cut-meta
  (if (or (endp inputs)
          (cut-done-p m))
      (>_ :cut-done-index idx
          :cut-meta m)
    (let* ((input (first inputs))
           (st    (nth idx trace))
           (m     (process-cut-step input st m)))
      (scan-until-cut-done-aux (rest inputs)
                               trace
                               (+ 1 idx)
                               m))))

(defun scan-until-cut-done (inputs trace cp-start sid initiator)
  ;; Start scanning at cp-start with freshly initialized cut meta-state.
  ;; Returns a record with fields:
  ;;   :cut-done-index
  ;;   :cut-meta
  (let* ((st (nth cp-start trace))
         (m0 (make-cut-meta sid initiator st)))
    (scan-until-cut-done-aux (nthcdr cp-start inputs)
                             trace
                             cp-start
                             m0)))

;; ------------------------------------------------------------------
;; Subsection C: Recovery metadata and recovery-side compression
;;
;; This block defines the metadata used while scanning from recovery-
;; start until recovery is complete.
;;
;; The recovery metadata records:
;;   - sid                      = snapshot being recovered
;;   - proc-ids                 = all process ids
;;   - recovery-started-procs   = processes that have already started
;;                                recovery
;;   - waiting-recovery-from    = per-process list of senders whose
;;                                recovery message has not yet arrived
;;   - inputs-during-recovery   = normal/spec-relevant inputs that
;;                                survive after rollback
;;
;; Intuition:
;;   - once a process starts recovery, later normal actions for that
;;     process may contribute to the recovered computation;
;;   - a normal receive(i,j) can contribute only after process i has
;;     started recovery and is no longer waiting for j's recovery
;;     message;
;;   - recovery is complete when all processes have started recovery
;;     and all waiting-recovery sets are empty.
;; ------------------------------------------------------------------

(defmacro rm-sid (m)
  `(g :sid ,m))

(defmacro rm-proc-ids (m)
  `(g :proc-ids ,m))

(defmacro rm-recovery-started-procs (m)
  `(g :recovery-started-procs ,m))

(defmacro rm-waiting-recovery-from (m)
  `(g :waiting-recovery-from ,m))

(defmacro rm-inputs-during-recovery (m)
  `(g :inputs-during-recovery ,m))


(defun rm-recovery-started-p (m i)
  (memberp i (rm-recovery-started-procs m)))

(defun rm-add-recovery-started-proc (m i)
  (s :recovery-started-procs
     (add-to-set-equal1 i (rm-recovery-started-procs m))
     m))

(defun rm-waiting-recovery-for (m i)
  (g i (rm-waiting-recovery-from m)))

(defun rm-set-waiting-recovery-for (m i xs)
  (s :waiting-recovery-from
     (s i xs (rm-waiting-recovery-from m))
     m))

(defun rm-add-input-during-recovery (m input)
  (s :inputs-during-recovery
     (append (rm-inputs-during-recovery m) (list input))
     m))


(defun make-empty-waiting-recovery-from (proc-ids)
  (if (endp proc-ids)
      nil
    (s (first proc-ids)
       nil
       (make-empty-waiting-recovery-from (rest proc-ids)))))


(defun all-waiting-recovery-empty-p (proc-ids m)
  (if (endp proc-ids)
      t
    (and (endp (rm-waiting-recovery-for m (first proc-ids)))
         (all-waiting-recovery-empty-p (rest proc-ids) m))))

(defun recovery-done-p (m)
  (and (subsetp-equal (rm-proc-ids m)
                      (rm-recovery-started-procs m))
       (all-waiting-recovery-empty-p (rm-proc-ids m) m)))


(defun make-recovery-meta (sid initiator st)
  ;; Initialize recovery meta-state at recovery-start.
  ;; The initiator has already taken the :recover step.
  (let* ((procs                  (procs st))
         (proc-ids               (proc-ids st))
	 (p                      (g initiator procs))
         (initiator-nbrs         (nbrs-from p))
         (empty-waiting          (make-empty-waiting-recovery-from proc-ids))
         (waiting-recovery-from  (s initiator
                                    initiator-nbrs
                                    empty-waiting))
         (recovery-started-procs (list initiator))
         (m                      nil)
         (m                      (s :inputs-during-recovery nil m))
         (m                      (s :waiting-recovery-from
                                    waiting-recovery-from
                                    m))
         (m                      (s :recovery-started-procs
                                    recovery-started-procs
                                    m))
         (m                      (s :proc-ids proc-ids m))
         (m                      (s :sid sid m)))
    m))

;; ------------------------------------------------------------------
;; Recovery-phase step processing
;;
;; These functions implement the recovery-side scan one input at a
;; time.  They inspect each implementation input together with the
;; corresponding trace pre-state and update the recovery metadata.
;;
;; Cases:
;;   - :receive carrying :recovery
;;       mark the receiver as having started recovery and update its
;;       waiting-recovery-from set.
;;
;;   - :receive carrying :normal
;;       preserve it only if the receiver has already started recovery
;;       and is no longer waiting for the sender's recovery message.
;;
;;   - :normal
;;       preserve it only after the process has started recovery.
;;
;;   - other protocol inputs
;;       do not contribute directly to the spec input sequence.
;; ------------------------------------------------------------------

(defun rm-handle-first-recovery-receive (m i j st)
  ;; Process i receives its first recovery message from j.
  (let* ((procs (procs st))
	 (p     (g i procs))
         (nbrs  (nbrs-from p))
         (ws    (remove1-equal j nbrs))
         (m     (rm-add-recovery-started-proc m i))
         (m     (rm-set-waiting-recovery-for m i ws)))
    m))

(defun rm-handle-later-recovery-receive (m i j)
  ;; Process i has already started recovery and receives another
  ;; recovery message from j.
  (let* ((ws (remove1-equal j (rm-waiting-recovery-for m i)))
         (m  (rm-set-waiting-recovery-for m i ws)))
    m))

(defun process-recovery-recovery-receive (i j st m)
  ;; Handle a :receive(i,j) that consumes a :recovery message.
  (if (rm-recovery-started-p m i)
      (rm-handle-later-recovery-receive m i j)
    (rm-handle-first-recovery-receive m i j st)))

(defun process-recovery-normal-receive (input i j m)
  ;; Keep ordinary receive(i,j) only if:
  ;;   1. i has already started recovery, and
  ;;   2. i is no longer waiting for j's recovery message.
  (if (not (rm-recovery-started-p m i))
      m
    (if (memberp j (rm-waiting-recovery-for m i))
        m
      (rm-add-input-during-recovery m input))))

(defun process-recovery-receive (input st m)
  ;; Handle one :receive input during recovery scan.
  (let* ((i   (pid input))
         (j   (sender input))
         (msg (current-msg-for-receive input st)))
    (cond
     ((and (equal (msg-type msg) :recovery)
           (equal (sid msg) (rm-sid m)))
      (process-recovery-recovery-receive i j st m))

     ((equal (msg-type msg) :normal)
      (process-recovery-normal-receive input i j m))

     (t
      m))))

(defun process-recovery-normal (input m)
  ;; Keep :normal(i) only after i has started recovery.
  (let ((i (pid input)))
    (if (rm-recovery-started-p m i)
        (rm-add-input-during-recovery m input)
      m)))

(defun process-recovery-step (input st m)
  ;; No new :recover input is expected here, by legal-inputp.
  ;; Checkpointing input is not expected here, by legal-inputp
  (cond
   ((equal (ttype input) :receive)
    (process-recovery-receive input st m))

   ((equal (ttype input) :normal)
    (process-recovery-normal input m))

   (t
    m)))

;; ------------------------------------------------------------------
;; Recovery-phase scan
;;
;; Starting from recovery-start, scan the aligned input suffix and
;; trace until recovery for the current sid is complete.
;;
;; Return:
;;   - :recovery-done-index = first index at which recovery is done
;;   - :recovery-meta       = final recovery metadata
;;
;; The resulting recovery metadata contains exactly the normal inputs
;; that should remain after the rollback/replay has been accounted for.
;; ------------------------------------------------------------------

(defun scan-until-recovery-done-aux (inputs trace idx m)
  ;; Scan left-to-right from absolute index IDX until recovery is done.
  ;; TRACE[idx] is the pre-state of INPUTS[idx].
  ;; Returns a record with fields:
  ;;   :recovery-done-index
  ;;   :recovery-meta
  (if (or (endp inputs)
          (recovery-done-p m))
      (>_ :recovery-done-index idx
          :recovery-meta m)
    (let* ((input (first inputs))
           (st    (nth idx trace))
           (m     (process-recovery-step input st m)))
      (scan-until-recovery-done-aux (rest inputs)
                                    trace
                                    (+ 1 idx)
                                    m))))

(defun scan-until-recovery (inputs trace recovery-start sid initiator)
  ;; INPUTS[recovery-start] is the initiating :recover input.
  ;; Returns a record with fields:
  ;;   :recovery-done-index
  ;;   :recovery-meta
  (let* ((st (nth recovery-start trace))
         (m0 (make-recovery-meta sid initiator st)))
    (scan-until-recovery-done-aux (nthcdr recovery-start inputs)
                                  trace
                                  recovery-start
                                  m0)))


;; ------------------------------------------------------------------
;; Subsection D: Build one compressed segment input
;;
;; Once cut metadata and recovery metadata have been computed for one
;; recovery segment, the compressed input for that segment is built in
;; three pieces:
;;
;;   1. inputs-before-cut
;;        ordinary behavior that occurred before each process took its
;;        checkpoint cut;
;;
;;   2. replayed inputs-after-cut
;;        buffered receives replayed in the same order that the
;;        implementation recovery uses to replay channel snapshots;
;;
;;   3. inputs-during-recovery
;;        normal behavior that survives after rollback has started.
;;
;; The concatenation of these three pieces is the spec-level input
;; sequence corresponding to one checkpoint-recovery segment.
;; ------------------------------------------------------------------

(defun replay-inputs-for-one-proc (i nbrs-from-i cm-meta)
  ;; Collect buffered receive inputs for process i, in nbrs-from order.
  (if (endp nbrs-from-i)
      nil
    (append (cm-after-cut-get cm-meta i (first nbrs-from-i))
            (replay-inputs-for-one-proc i
                                        (rest nbrs-from-i)
                                        cm-meta))))

(defun replay-inputs-from-cut-meta-aux (proc-ids procs cm-meta)
  ;; Collect all buffered receive inputs in replay order.
  ;; Outer order: processes in PROC-IDS
  ;; Inner order: nbrs-from order for each process
  (if (endp proc-ids)
      nil
      (let* ((i            (first proc-ids))
	     (p            (g i procs))
           (nbrs-from-i  (nbrs-from p)))
      (append (replay-inputs-for-one-proc i
                                          nbrs-from-i
                                          cm-meta)
              (replay-inputs-from-cut-meta-aux (rest proc-ids)
                                               procs
                                               cm-meta)))))

(defun replay-inputs-from-cut-meta (st cm-meta)
  (let* ((proc-ids (cm-proc-ids cm-meta))
         (procs    (procs st)))
    (replay-inputs-from-cut-meta-aux proc-ids
                                     procs
                                     cm-meta)))

(defun generate-segment-inputs (st cm-meta rm-meta)
  ;; Final compressed input sequence for one checkpoint-recovery segment:
  ;;   1. inputs-before-cut
  ;;   2. replayed buffered inputs from cut-meta
  ;;   3. preserved inputs during recovery
  (append (cm-inputs-before-cut cm-meta)
          (append (replay-inputs-from-cut-meta st cm-meta)
                  (rm-inputs-during-recovery rm-meta))))


;; ------------------------------------------------------------------
;; Subsection E: Generate compressed segment records
;;
;; For each discovered recovery-segment record
;;   (:checkpoint-start, :recovery-start, :sid),
;; compute:
;;   - the cut metadata,
;;   - the recovery metadata,
;;   - the compressed segment input sequence, and
;;   - the index at which the covered recovery finishes.
;;
;; The output is a list of records with fields:
;;   :checkpoint-start-index
;;   :recovery-done-index
;;   :compressed-seg
;;
;; These records are the units used by the final stitching phase.
;; ------------------------------------------------------------------

(defmacro cis-recovery-done-index (r)
  `(g :recovery-done-index ,r))

(defmacro cis-checkpoint-start-index (r)
  `(g :checkpoint-start-index ,r))

(defmacro cis-compressed-seg (r)
  `(g :compressed-seg ,r))

(defun generate-compressed-input-segments (inputs trace cp-rc-sid-record-list)
  ;; For each recovery-segment record with fields:
  ;;   :checkpoint-start
  ;;   :recovery-start
  ;;   :sid
  ;;
  ;; compute:
  ;;   :recovery-done-index
  ;;   :compressed-seg
  ;;
  ;; Returns a list of such records.
  (if (endp cp-rc-sid-record-list)
      nil
    (let* ((cp-rc-sid-record   (first cp-rc-sid-record-list))
           (cp-start          (rs-checkpoint-start cp-rc-sid-record))
           (recovery-start    (rs-recovery-start cp-rc-sid-record))
           (sid               (rs-sid cp-rc-sid-record))
           (initiator-rc      (pid (nth recovery-start inputs)))
           ;; If sid = :init, there may be no actual checkpoint input.
           ;; In that case, use the recovery initiator as a harmless
           ;; initiator for the cut meta, and cut-done-p will make the
           ;; cut phase finish immediately.
           (initiator-cp      (if (equal sid :init)
                                  initiator-rc
                                (pid (nth cp-start inputs))))
           (cut-result        (scan-until-cut-done inputs
                                                   trace
                                                   cp-start
                                                   sid
                                                   initiator-cp))
           (cut-meta          (cut-result-meta cut-result))
           (recovery-result   (scan-until-recovery inputs
                                                   trace
                                                   recovery-start
                                                   sid
                                                   initiator-rc))
           (recovery-done     (recovery-result-idx recovery-result))
           (recovery-meta     (recovery-result-meta recovery-result))
           ;; Use the state at cp-start for replay-order information.
           (st-cp             (nth cp-start trace))
           (compressed-seg    (generate-segment-inputs st-cp
                                                       cut-meta
                                                       recovery-meta))
           (result-rec        (>_ :recovery-done-index recovery-done
                                  :compressed-seg compressed-seg
				  :checkpoint-start-index cp-start)))
      (cons result-rec
            (generate-compressed-input-segments inputs
                                                trace
                                                (rest cp-rc-sid-record-list))))))


;; ------------------------------------------------------------------
;; Subsection F: Convert untouched original inputs into spec-compatible
;; form and stitch compressed segments left to right
;;
;; The compressed segment inputs are already built to be spec-level
;; inputs.  However, untouched portions copied directly from the
;; original implementation input sequence may still contain protocol-
;; only actions.
;;
;; This block has two responsibilities:
;;
;;   1. Convert untouched original inputs into spec-compatible form:
;;        - keep :normal as-is,
;;        - keep :receive only when the consumed message is :normal,
;;        - turn implementation-only inputs into :nop.
;;
;;      In particular, receives of marker or recovery messages must
;;      not be preserved as spec receives.
;;
;;   2. Build the final transformed input sequence by stitching
;;      compressed segments from left to right.
;;
;;      Since multiple recovery segments may be associated with the
;;      same checkpoint-start index, we first keep only the last
;;      compressed segment for each checkpoint-start.  This ensures
;;      that if several recoveries roll back to the same checkpoint,
;;      only the final one is used in the stitched result.
;;
;;      After this filtering step, stitching proceeds left to right:
;;        - copy untouched inputs from the current index up to the
;;          next checkpoint-start,
;;        - insert the compressed segment,
;;        - continue from that segment's recovery-done index.
;;
;; Result:
;;   The final output is a spec-compatible input sequence in which
;;   untouched regions are converted to spec-level inputs or :nop,
;;   and each retained checkpoint/recovery region is replaced by its
;;   compressed segment input.
;; ------------------------------------------------------------------

(defun make-nop-input (input)
  (update input :ttype :nop))

(defun spec-compatible-input (input st)
  ;; Convert any implementation-only input into a spec no-op.
  ;; Keep:
  ;;   :normal
  ;;   :receive only when the consumed msg is :normal
  ;; Convert to :nop:
  ;;   :start-checkpoint, :recover, :crash
  ;;   :receive when the consumed msg is :marker or :recovery
  (cond
   ((equal (ttype input) :normal)
    input)

   ((equal (ttype input) :receive)
    (let ((msg (current-msg-for-receive input st)))
      (if (equal (msg-type msg) :normal)
          input
        (make-nop-input input))))

   (t
    (make-nop-input input))))

(defun take-input-range-aux (inputs trace idx stop)
  ;; INPUTS is assumed to be aligned with absolute index IDX.
  ;; Collect spec-compatible inputs from absolute index IDX up to STOP-1.
  (if (or (endp inputs)
          (>= idx stop))
      nil
    (let* ((input (first inputs))
           (st    (nth idx trace))
           (input (spec-compatible-input input st)))
      (cons input
            (take-input-range-aux (rest inputs)
                                  trace
                                  (+ 1 idx)
                                  stop)))))

(defun take-input-range (inputs trace start stop)
  ;; Collect spec-compatible inputs from absolute index START up to STOP-1.
  (take-input-range-aux (nthcdr start inputs)
                        trace
                        start
                        stop))

(defun cis-record-has-checkpoint-start-p (cp-start seg-records)
  ;; Check whether some compressed-segment record in SEG-RECORDS
  ;; has checkpoint-start-index = CP-START.
  (if (endp seg-records)
      nil
    (or (equal cp-start
               (cis-checkpoint-start-index (first seg-records)))
        (cis-record-has-checkpoint-start-p cp-start
                                           (rest seg-records)))))

(defun keep-last-segments-by-checkpoint-start (seg-records)
  ;; If multiple segment records share the same checkpoint-start index,
  ;; keep only the last one. Later recoveries from the same checkpoint
  ;; override earlier ones before stitching.
  (if (endp seg-records)
      nil
    (let* ((seg       (first seg-records))
           (rest-kept (keep-last-segments-by-checkpoint-start
                       (rest seg-records)))
           (cp-start  (cis-checkpoint-start-index seg)))
      (if (cis-record-has-checkpoint-start-p cp-start rest-kept)
          rest-kept
        (cons seg rest-kept)))))

(defun stitch-compressed-inputs (inputs trace compressed-seg-records idx)
  ;; Build final transformed input list starting from absolute index IDX,
  ;; moving left to right.
  ;;
  ;; Each retained segment record contributes:
  ;;   - spec-compatible untouched inputs from IDX to checkpoint-start-1,
  ;;   - then the compressed segment itself,
  ;;   - then continue from recovery-done-index.
  ;;
  ;; recovery-done-index is treated as the first index after the region
  ;; covered by that checkpoint/recovery segment.
  (if (endp compressed-seg-records)
      (take-input-range inputs trace idx (len inputs))
    (let* ((seg-record     (first compressed-seg-records))
           (cp-start       (cis-checkpoint-start-index seg-record))
           (recovery-done  (cis-recovery-done-index seg-record))
           (compressed-seg (cis-compressed-seg seg-record)))
      (append (take-input-range inputs trace idx cp-start)
              (append compressed-seg
                      (stitch-compressed-inputs inputs
                                                trace
                                                (rest compressed-seg-records)
                                                recovery-done))))))

(defun spec-input-generation (inputs)
  (let* ((st0                        (make-initial-state))
         (trace                      (run-imp-trace st0 inputs))
         (cp-rc-sid-record-list      (collect-recovery-segments-from-trace
                                      inputs trace))
         (compressed-seg-records-raw (generate-compressed-input-segments
                                      inputs trace cp-rc-sid-record-list))
         (compressed-seg-records     (keep-last-segments-by-checkpoint-start
                                      compressed-seg-records-raw)))
    (stitch-compressed-inputs inputs
                              trace
                              compressed-seg-records
                              0)))




(defun map-proc-to-spec-proc (imp-p)
  ;; Project one implementation process record into a spec process record.
  ;; Keep only the fields needed by the spec.
  (>_ :local-state (local-state imp-p)
      :nbrs-to (nbrs-to imp-p)
      :nbrs-from (nbrs-from imp-p)))

(defun map-procs-to-spec-procs (ids imp-procs)
  ;; Build the full spec process table by projecting each
  ;; implementation process into its spec-level form.
  (if (endp ids)
      nil
    (let* ((i          (first ids))
           (imp-p      (g i imp-procs))
           (spec-p     (map-proc-to-spec-proc imp-p))
           (spec-procs (map-procs-to-spec-procs (rest ids) imp-procs)))
      (s i spec-p spec-procs))))

(defun rep (imp-st)
  ;; Representation map from implementation state to spec state.
  ;; Preserve proc-ids and channels, and project each process.
  (let* ((ids       (proc-ids imp-st))
         (imp-procs (procs imp-st)))
    (>_ :proc-ids ids
        :procs (map-procs-to-spec-procs ids imp-procs)
        :channels (channels imp-st))))






;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Section 3: CP Start - Recovery Done Segment Predicate 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; This section defines a predicate for recognizing one complete
;; checkpoint/recovery segment in an implementation input sequence.
;;
;; The input segment is viewed relative to a starting implementation
;; state ST, and is intended to capture a region that:
;;
;;   - starts with a checkpoint-start input,
;;   - contains exactly one recovery associated with that checkpoint,
;;   - and ends exactly when that recovery is complete.
;;
;; The definition is expressed using the executable functions already
;; available in the model, such as:
;; ------------------------------------------------------------------

;; ------------------------------------------------------------------
;; Predicate for one checkpoint-start ... recovery-done segment
;;
;; INPUT-SEG is viewed as a suffix beginning at implementation state ST.
;;
;; The segment must:
;;   - be legal from that state,
;;   - begin with :start-checkpoint,
;;   - contain exactly one recovery,
;;   - have that recovery tied to the snapshot id created by the
;;     first checkpoint-start,
;;   - have that recovery point back to checkpoint-start index 0,
;;   - and end exactly when that recovery is done.
;;
;; We define this using the executable scan functions already present
;; in the development:
;;
;;   - run-imp-trace
;;   - collect-recovery-segments-from-trace
;;   - scan-until-recovery
;;
;; Important indexing convention:
;;   recovery-result-idx is treated as the first index after the
;;   covered checkpoint/recovery region. Therefore, to say that the
;;   whole INPUT-SEG is exactly one such segment, we require:
;;
;;      recovery-result-idx = (len input-seg)
;; ------------------------------------------------------------------

(defun cp-start-rc-done-segment-p (st input-seg)
  (let* ((trace   (run-imp-trace st input-seg))

         ;; Extract recovery-segment records from the aligned trace.
         ;; Since this predicate is for the simpler case, we require
         ;; exactly one such record.
         (records (collect-recovery-segments-from-trace input-seg trace)))
    (and 
         ;; The entire segment must be legally executable from ST.
         (legal-input-sequencep st input-seg)

         ;; The segment must be nonempty and begin with a checkpoint start.
         (consp input-seg)
         (equal (ttype (first input-seg)) :start-checkpoint)

         ;; The segment must contain exactly one recovery.
         (consp records)
         (endp (rest records))

         (let* ((rec  (first records))
                (i    (pid (first input-seg)))

                ;; SID0 is the snapshot id created by the checkpoint-start
                ;; at segment index 0. Since ST is the pre-state of the
                ;; first input, the relevant counter is read from ST.
                (sid0 (list i
                            (counter (g i (procs st)))))

                ;; Extract the unique recovery information from the record.
                (x1   (rs-recovery-start rec))
                (j    (pid (nth x1 input-seg)))

                ;; Scan from that recovery-start until recovery is done.
                (recovery-result
                 (scan-until-recovery input-seg
                                      trace
                                      x1
                                      sid0
                                      j))

                ;; x2 is the first index after the recovery-complete region.
                (x2   (recovery-result-idx recovery-result)))
           (and
            ;; The unique recovery must use the snapshot id created
            ;; by the checkpoint-start at segment index 0.
            (equal (rs-sid rec) sid0)

            ;; The unique recovery must point back to checkpoint-start
            ;; at segment-relative index 0.
            (equal (rs-checkpoint-start rec) 0)

            ;; The unique recovery must finish exactly at the end of
            ;; INPUT-SEG.
            (equal x2 (len input-seg)))))))
