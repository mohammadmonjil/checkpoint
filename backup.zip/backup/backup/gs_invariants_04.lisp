;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Book import
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(include-book "model_1")

;; TODO:
;; 1.   Add an invariant stating that any recovery message on
;;      channel j -> i must carry a sid that receiver i already knows,
;;      i.e., the sid must be a member of i's snapshot-ids.
;;
;; 2.   Add an invariant/lemma stating that if there is a  marker message at the
;;      head of channel j -> i, then the sid of the msg must be known to be some
;;      process
;; 3.   Use the marker/recovery channel-head invariants to remove
;;      the extra side conditions from step-rcv once they are proved.


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Structural predicates
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Defines the well-formedness invariant for processes, snapshots, messages,
;; channels, and the top-level implementation state.



;start definitions: status-and-snapshot-id-predicates
;; Basic recognizers for allowed process statuses, snapshot statuses, and
;; snapshot identifiers.  These are the leaf predicates used later by
;; good-proc-p and good-snapshot-ids-list-p.

(defun good-proc-status-p (x)
  (or (equal x :normal)
      (equal x :crashed)
      (equal x :recovering)))

(defun good-snapshot-status-p (x)
  (or (equal x :checkpointing)
      (equal x :done)))

(defun good-snapshot-id-p (sid ids)
  (or (equal sid :init)
      (and (consp sid)
           (consp (cdr sid))
           (endp (cddr sid))
           (memberp (car sid) ids)
           (natp (cadr sid)))))

(defun good-snapshot-ids-p (snapshot-ids ids)
  (if (endp snapshot-ids)
      t
    (and (good-snapshot-id-p (first snapshot-ids) ids)
         (good-snapshot-ids-p (rest snapshot-ids) ids))))

(defun good-snapshot-ids-list-p (snapshot-ids ids)
  (and (true-listp snapshot-ids)
       (uniquep snapshot-ids)
       (memberp :init snapshot-ids)
       (good-snapshot-ids-p snapshot-ids ids)))

;end definitions: status-and-snapshot-id-predicates

;start definitions: message-well-formedness
;; Message well-formedness is channel-aware.
;;
;; Normal messages do not carry snapshot ids.
;;
;; Marker messages carry a snapshot id that must already be known somewhere
;; in the system.  The receiver may not know the sid yet, because receiving the
;; first marker is exactly how the receiver learns and installs that snapshot.
;;
;; Recovery messages are stronger: a recovery message on channel src -> dst
;; must carry a sid that the receiver dst already knows.  This is the invariant
;; needed by handle-recovery-msg in the first-recovery case.

(defun some-proc-has-snapshot-id-p (sid ids procs)
  (if (endp ids)
      nil
    (let* ((i (first ids))
           (p (g i procs)))
      (or (memberp sid (snapshot-ids p))
          (some-proc-has-snapshot-id-p sid (rest ids) procs)))))

(defun good-msg-p (msg dst ids procs)
  (let ((tp (msg-type msg)))
    (cond
     ;; Application/compute messages are always structurally valid.
     ((equal tp :normal)
      t)

     ;; A marker sid only needs to be known somewhere.  The receiver may be
     ;; seeing this sid for the first time.
     ((equal tp :marker)
      (some-proc-has-snapshot-id-p (sid msg) ids procs))

     ;; A recovery sid must already be known by the receiver of this channel.
     ((equal tp :recovery)
      (memberp (sid msg)
               (snapshot-ids (g dst procs))))

     ;; Unknown message type is not well-formed.
     (t nil))))

(defun good-msg-list-p (msgs dst ids procs)
  (if (endp msgs)
      t
    (and (good-msg-p (first msgs) dst ids procs)
         (good-msg-list-p (rest msgs) dst ids procs))))

(defthm good-msg-p-of-create-marker-message
  (implies (some-proc-has-snapshot-id-p sid ids procs)
           (good-msg-p (create-marker-message local-state sid)
                       dst
                       ids
                       procs)))

(defthm good-msg-p-of-create-recovery-message
  (implies (memberp sid
                    (snapshot-ids (g dst procs)))
           (good-msg-p (create-recovery-message local-state sid)
                       dst
                       ids
                       procs)))

;end definitions: message-well-formedness


;start definitions: snapshot-entry-well-formedness
;; Channel snapshots contain only normal messages, and each snapshot entry keeps
;; its waiting-marker list inside the process's incoming-neighbor list.

(defun good-normal-msg-p (msg)
  (equal (msg-type msg) :normal))

(defthm good-normal-msg-p-of-create-compute-message
  (good-normal-msg-p (create-compute-message local-state nbr)))

(defun good-normal-msg-list-p (msgs)
  (if (endp msgs)
      t
    (and (good-normal-msg-p (first msgs))
         (good-normal-msg-list-p (rest msgs)))))

(defun good-channel-snapshot-record-p (nbrs-from-i cs)
  (if (endp nbrs-from-i)
      t
    (and (good-normal-msg-list-p (g (first nbrs-from-i) cs))
         (good-channel-snapshot-record-p (rest nbrs-from-i) cs))))

(defun good-snapshot-entry-p (entry nbrs-from-i)
  (and (good-snapshot-status-p (snapshot-status entry))
       (true-listp (snapshot-waiting-marker-from entry))
       (subset (snapshot-waiting-marker-from entry) nbrs-from-i)
       (good-channel-snapshot-record-p nbrs-from-i
                                       (snapshot-channel-snapshots entry))))

(defun good-snapshots-p (snapshot-ids p nbrs-from-i ids)
  (declare (irrelevant ids))
  (if (endp snapshot-ids)
      t
    (let* ((sid   (first snapshot-ids))
           (entry (snapshot-entry sid p)))
      (and
           ;(good-snapshot-id-p sid ids)
           (good-snapshot-entry-p entry nbrs-from-i)
           (good-snapshots-p (rest snapshot-ids)
                             p
                             nbrs-from-i
                             ids)))))

;end definitions: snapshot-entry-well-formedness


;start definitions: process-channel-state-well-formedness
;; Lift the local predicates to processes, process tables, channel rows,
;; full channel tables, and finally the top-level implementation state.

(defun good-proc-p ( p ids)
  (let* ((nbrs-in  (nbrs-from p))
         (nbrs-out (nbrs-to p)))
    (and (true-listp nbrs-in)
         (true-listp nbrs-out)
         (subset nbrs-in ids)
         (subset nbrs-out ids)
         (good-proc-status-p (proc-status p))
         (natp (counter p))
         (true-listp (waiting-recovery-from p))
         (subset (waiting-recovery-from p) nbrs-in)
	 (good-snapshot-ids-list-p (snapshot-ids p) ids)
         (good-snapshots-p (snapshot-ids p) p nbrs-in ids))))

(defun good-procs-p (ids procs all-ids)
  (if (endp ids)
      t
    (let* ((i (first ids))
           (p (g i procs)))
      (and (good-proc-p  p  all-ids)
           (good-procs-p (rest ids) procs all-ids)))))

(defun good-channel-p (src dst channels ids procs)
  (let ((p (g src procs)))
    (if (memberp dst (nbrs-to p))
        (good-msg-list-p (channel-state src dst channels)
                         dst
                         ids
                         procs)
	(equal (channel-state src dst channels) nil))))


(defun good-channel-row-p (src dsts channels ids procs)
  (if (endp dsts)
      t
    (and (good-channel-p src (first dsts) channels ids procs)
         (good-channel-row-p src (rest dsts) channels ids procs))))

(defun good-channels-p (srcs dsts channels ids procs)
  (if (endp srcs)
      t
    (and (good-channel-row-p (first srcs) dsts channels ids procs)
         (good-channels-p (rest srcs) dsts channels ids procs))))

(defun good-state-p (st)
  (let* ((ids      (proc-ids st))
         (procs    (procs st))
         (channels (channels st)))
    (and (true-listp ids)
         (uniquep ids)
         (good-procs-p ids procs ids)
         (good-channels-p ids ids channels ids procs))))


;end definitions: process-channel-state-well-formedness


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Small reusable helpers
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; General process-table/list lemmas used by several preservation proofs.


;start support: generic-process-and-list-helpers
;; Small rewrite/helper facts used across many preservation proofs.  These keep
;; membership/subset obligations from being reproved in every major case.

(defthm good-proc-p-of-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (g i procs)
                        all-ids)))

(defthm not-memberp-when-subset-and-not-memberp
  (implies (and (subset xs ys)
                (not (memberp a ys)))
           (not (memberp a xs))))

(defthm memberp-of-cons-right
  (implies (memberp e xs)
           (memberp e (cons a xs))))

(defthm subset-of-cons
  (implies (subset xs ys)
           (subset xs (cons a ys))))

(defthm subset-reflexive
    (subset x x))


;end support: generic-process-and-list-helpers


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Initial-state preservation support
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Shows that the initial process table and channel table satisfy good-state-p.


;start support: initial-empty-message-and-snapshot-records
;; Empty channels and empty channel-snapshot records are well-formed.  The
;; initial snapshot entry is also structurally good for any incoming-neighbor list.

(defthm good-normal-msg-list-p-of-nil
  (good-normal-msg-list-p nil))

(defthm good-msg-list-p-of-nil
  (good-msg-list-p nil ids procs))

(defthm good-channel-snapshot-record-p-of-nil
  (good-channel-snapshot-record-p nbrs-from-i nil))

(defthm good-snapshot-entry-p-of-make-init-snapshot-entry
  (good-snapshot-entry-p (make-init-snapshot-entry init-local-state)
                         nbrs-from-i))

(defthm good-proc-p-of-install-initial-snapshot-on-make-one-proc
  (good-proc-p
   (install-initial-snapshot (make-one-proc i all-ids))
   all-ids))

;end support: initial-empty-message-and-snapshot-records


;start support: initial-process-table-construction
;; Show that make-procs-aux installs the expected process at every valid id, and
;; that installing the initial snapshot produces a good process table.

(defthm g-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i (make-procs-aux ids all-ids))
                  (make-one-proc i all-ids))))

(defthm g-of-s-diff
  (implies (not (equal k1 k2))
           (equal (g k1 (s k2 v r))
                  (g k1 r))))

(defthm g-of-install-initial-snapshots-when-not-member
  (implies (not (memberp k ids))
           (equal (g k (install-initial-snapshots ids procs))
                  (g k procs))))

(defthm g-of-install-initial-snapshots
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i (install-initial-snapshots ids procs))
                  (install-initial-snapshot (g i procs)))))

(defthm g-of-install-initial-snapshots-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (equal (g i
                     (install-initial-snapshots ids
                                                (make-procs-aux ids all-ids)))
                  (install-initial-snapshot
                   (make-one-proc i all-ids)))))

(defthm good-proc-p-of-g-of-install-initial-snapshots-of-make-procs-aux
  (implies (and (memberp i ids)
                (uniquep ids))
           (good-proc-p
            (g i
               (install-initial-snapshots ids
                                          (make-procs-aux ids all-ids)))
            all-ids)))

(defthm good-procs-p-of-install-initial-snapshots-of-make-procs-aux
  (implies (uniquep ids)
           (good-procs-p ids
                         (install-initial-snapshots ids
                                                    (make-procs-aux ids all-ids))
                         all-ids)))

;end support: initial-process-table-construction


;start support: initial-channel-table-construction
;; Build the initial channel table one destination column at a time.  Freshness
;; and uniqueness keep old rows from being disturbed by the new destination.

(defthm good-channel-row-p-preserved-by-adding-fresh-dst
  (implies (and (good-channel-row-p src dsts channels ids procs)
                (not (memberp new-dst dsts)))
           (good-channel-row-p src dsts
                               (s new-dst row channels)
                               ids procs)))

(defthm good-channels-p-of-cons-new-dst
  (implies (and (good-channels-p srcs dsts channels ids procs)
                (not (memberp dst dsts))
		(uniquep dsts)
		(uniquep srcs))
           (good-channels-p srcs
                            (cons dst dsts)
                            (s dst (make-channel-row srcs) channels)
                            ids
                            procs)))

(defthm good-channels-p-of-make-channels-aux
    (implies (and (uniquep dsts)
		  (uniquep srcs))
           (good-channels-p srcs
                            dsts
                            (make-channels-aux srcs dsts)
                            ids
                            procs)))

(defthm good-channels-p-of-make-channels
    (implies (uniquep ids)
	     (good-channels-p ids ids (make-channels ids) ids procs)))

;end support: initial-channel-table-construction


;start target: initial-state-is-good-state
;; Main target for initialization: the state produced by make-initial-state
;; satisfies the global structural invariant good-state-p.

(defthm initial-state-is-good-state
    (good-state-p (make-initial-state)))


;end target: initial-state-is-good-state


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; NOP preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A nop input leaves the state structurally unchanged.


;start target: good-state-p-preserved-by-nop
;; Main target for :nop inputs.  Since system-step does not change the state in
;; the nop case, good-state-p is preserved directly.

(defthm good-state-p-preserved-by-nop
  (implies (and (good-state-p st)
                (equal (ttype input) :nop))
           (good-state-p (system-step st input))))


;end target: good-state-p-preserved-by-nop


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Crash preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A crash only changes :proc-status to an allowed value.  Channels are
;; unchanged because message well-formedness does not depend on proc-status.


;start support: crash-process-update-preservation
;; A crash changes only :proc-status.  Since :crashed is an allowed status and
;; snapshot data is untouched, the updated process remains good.

(defthm good-snapshots-p-of-set-proc-status-crashed
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :proc-status :crashed p)
                             nbrs-from
                             ids)))

(defthm good-proc-p-of-set-proc-status-crashed
  (implies (good-proc-p p ids)
           (good-proc-p (s :proc-status :crashed p)
                        ids)))

(defthm good-proc-p-of-crashed-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (s :proc-status
                           :crashed
                           (g i procs))
                        all-ids)))

(defthm g-of-crash-updated-procs
  (equal (g k
            (s i
               (s :proc-status :crashed (g i procs))
               procs))
         (if (equal k i)
             (s :proc-status :crashed (g i procs))
           (g k procs))))

(defthm good-procs-p-of-crash-update
  (implies (and (true-listp ids)
                (uniquep ids)
                (true-listp all-ids)
                (uniquep all-ids)
                (good-procs-p ids procs all-ids))
           (good-procs-p ids
                         (s i
                            (s :proc-status
                               :crashed
                               (g i procs))
                            procs)
                         all-ids)))

;end support: crash-process-update-preservation


;start support: crash-channel-preservation
;; Channels are unchanged by a crash, and message goodness is independent of the
;; crashed process's status.  Lift this fact from message lists to all channels.

(defthm good-msg-list-p-of-crash-update
  (implies (good-msg-list-p msgs ids procs)
           (good-msg-list-p msgs ids
                            (s i
                               (s :proc-status :crashed (g i procs))
                               procs))))

(defthm good-channel-p-of-crash-update
  (implies (good-channel-p src dst channels ids procs)
           (good-channel-p src dst channels ids
                           (s i
                              (s :proc-status :crashed (g i procs))
                              procs))))

(defthm good-channel-row-p-of-crash-update
  (implies (good-channel-row-p src dsts channels ids procs)
           (good-channel-row-p src dsts channels ids
                               (s i
                                  (s :proc-status :crashed (g i procs))
                                  procs))))

(defthm good-channels-p-of-crash-update
  (implies (good-channels-p srcs dsts channels ids procs)
           (good-channels-p srcs dsts channels ids
                            (s i
                               (s :proc-status :crashed (g i procs))
                               procs))))

;end support: crash-channel-preservation


;start target: good-state-p-of-system-step-crash
;; Main target for :crash inputs: combine the process-table update proof with
;; the channel-table preservation proof.

(defthm good-state-p-of-system-step-crash
  (implies (and (good-state-p st)
                (equal (ttype input) :crash))
           (good-state-p (system-step st input))))


;end target: good-state-p-of-system-step-crash


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Normal-step process update preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Local-state updates preserve process and channel well-formedness.


;start support: normal-process-local-state-update
;; A normal computation step may update only :local-state.  This does not change
;; status, neighbor lists, snapshot ids, counters, or snapshot entries.

(defthm good-snapshots-p-of-set-proc-update-normal
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :local-state val p)
                             nbrs-from
                             ids)))

(defthm good-proc-p-of-set-proc-update-normal
  (implies (good-proc-p p ids)
           (good-proc-p (s :local-state val p)
                        ids)))

(defthm good-proc-p-of-update-normal-g-when-good-procs-p
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (s :local-state val
                           (g i procs))
                        all-ids)))

(defthm good-proc-p-of-g-when-good-procs-p-update-normal
  (implies (and (good-procs-p ids procs all-ids)
                (memberp i ids))
           (good-proc-p (g i procs)
                        all-ids)))

(defthm g-of-update-normal-updated-procs
  (equal (g k
            (s i
               (s :local-state val (g i procs))
               procs))
         (if (equal k i)
             (s :local-state val (g i procs))
           (g k procs))))

(defthm good-procs-p-of-normal-update
  (implies (and (true-listp ids)
                (uniquep ids)
                (true-listp all-ids)
                (uniquep all-ids)
                (good-procs-p ids procs all-ids))
           (good-procs-p ids
                         (s i
                            (s :local-state
                               val
                               (g i procs))
                            procs)
                         all-ids)))

;end support: normal-process-local-state-update


;start support: normal-channel-preservation-under-proc-update
;; The channel contents do not change when only a process local state changes.
;; Lift preservation from message lists to rows and then to the whole channel table.

(defthm good-msg-list-p-of-normal-update
  (implies (good-msg-list-p msgs ids procs)
           (good-msg-list-p msgs ids
                            (s i
                               (s :local-state val (g i procs))
                               procs))))

(defthm good-channel-p-of-normal-update
  (implies (good-channel-p src dst channels ids procs)
           (good-channel-p src dst channels ids
                           (s i
                              (s :local-state val (g i procs))
                              procs))))

(defthm good-channel-row-p-of-normal-update
  (implies (good-channel-row-p src dsts channels ids procs)
           (good-channel-row-p src dsts channels ids
                               (s i
                                  (s  :local-state val (g i procs))
                                  procs))))

(defthm good-channels-p-of-normal-update
  (implies (good-channels-p srcs dsts channels ids procs)
           (good-channels-p srcs dsts channels ids
                            (s i
                               (s :local-state val (g i procs))
                               procs))))


;end support: normal-channel-preservation-under-proc-update


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Compute-message channel preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Compute sends append normal messages to outgoing channels.  The lemmas first
;; handle one channel update, then lift to rows and the whole channel table.


;start support: compute-message-goodness
;; Compute messages are normal messages, so appending a freshly created compute
;; message preserves good-msg-list-p.

(defthm good-msg-p-of-create-compute-message
  (good-msg-p (create-compute-message local-state nbr)
              ids
              procs))

(defthm good-msg-list-p-of-snoc-create-compute-message
  (implies (good-msg-list-p msgs ids procs)
           (good-msg-list-p
            (snoc msgs (create-compute-message local-state nbr))
            ids
            procs)))

;end support: compute-message-goodness


;start support: one-compute-channel-update
;; These lemmas reason about a single channel-table update.  They separate the
;; same-channel case from different-source/different-destination cases.

(defthm channel-lookup-after-send-compute-message-when-dst-not-in-nbrs
  (implies (not (memberp dst nbrs))
           (equal (g src
                     (g dst
                        (send-compute-message local-state i nbrs channels)))
                  (g src
                     (g dst channels)))))

(defthm good-msg-list-p-preserved-by-setting-different-dst
    (implies (and (memberp dst dsts)
		  (not (memberp dst2 dsts))
                (good-msg-list-p (g src (g dst channels))
                                 ids procs))
           (good-msg-list-p
            (g src
               (g dst
                  (s dst2 row channels)))
            ids procs)))

(defthm good-msg-list-p-preserved-by-setting-different-src
  (implies (and (not (equal src src2))
                (good-msg-list-p (g src (g dst channels))
                                 ids procs))
           (good-msg-list-p
            (g src
               (g dst
                  (s dst
                     (s src2 val (g dst channels))
                     channels)))
            ids procs)))

(defthm good-msg-list-p-of-setting-channel-src-entry-val
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (good-msg-list-p val ids procs))
   (good-msg-list-p
    (g src
       (s i
          val
          (g dst channels)))
    ids procs))
  :hints (("Goal"
           :cases ((equal i src)))))

(defthm good-msg-list-p-of-setting-channel-dst-entry-val
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)

        (good-msg-list-p val ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels)))
    ids procs))
  :hints (("Goal"
           :cases ((equal dst j)))))

(defthm g-of-s-different-src
  (implies (not (equal src i))
           (equal (g src (s i val row))
                  (g src row))))

(defthm g-g-of-s-different-dst
  (implies (not (equal dst j))
           (equal (g src
                     (g dst
                        (s j row channels)))
                  (g src
                     (g dst channels)))))

(defthm channel-lookup-of-setting-different-channel
  (implies (or (not (equal dst j))
               (not (equal src i)))
           (equal
            (g src
               (g dst
                  (s j
                     (s i val (g j channels))
                     channels)))
            (g src
               (g dst channels))))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :cases ((equal dst j)))))

(defthm good-msg-list-p-of-setting-different-channel
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (or (not (equal dst j))
            (not (equal src i))))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels)))
    ids procs)))

(defthm good-msg-list-p-of-setting-channel-combined
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (or (not (equal dst j))
            (not (equal src i))
            (good-msg-list-p val ids procs)))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i val (g j channels))
             channels)))
    ids procs))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :cases ((equal dst j)
                   (equal src i)))))

(defthm good-msg-list-p-of-snoc-create-compute-message-same-channel
  (implies
   (and (equal src i)
        (equal dst j)
        (good-msg-list-p (g src (g dst channels))
                         ids procs))
   (good-msg-list-p
    (snoc (g i (g j channels))
          (create-compute-message local-state j))
    ids procs)))

(defthm one-compute-send-update-disjunct
  (implies
   (good-msg-list-p (g src (g dst channels))
                    ids procs)
   (or (not (equal dst j))
       (not (equal src i))
       (good-msg-list-p
        (snoc (g i (g j channels))
              (create-compute-message local-state j))
        ids procs))))

(defthm good-msg-list-p-of-one-compute-send-update
  (implies
   (good-msg-list-p (g src (g dst channels))
                    ids procs)
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i
                (snoc (g i (g j channels))
                      (create-compute-message local-state j))
                (g j channels))
             channels)))
    ids procs))
  :hints (("Goal"
           :do-not '(generalize fertilize)
           :use ((:instance good-msg-list-p-of-setting-channel-combined
                            (src src)
                            (dst dst)
                            (i i)
                            (j j)
                            (channels channels)
                            (ids ids)
                            (procs procs)
                            (val (snoc (g i (g j channels))
                                       (create-compute-message local-state j))))
                 (:instance one-compute-send-update-disjunct
                            (src src)
                            (dst dst)
                            (i i)
                            (j j)
                            (channels channels)
                            (ids ids)
                            (procs procs)
                            (local-state local-state))))))

;end support: one-compute-channel-update


;start support: send-compute-message-channel-lookup
;; After send-compute-message, either the target channel receives a good normal
;; message or unrelated/nil channels stay unchanged.

(defthm good-msg-list-p-of-channel-after-send-compute-message
  (implies
   (good-msg-list-p (g src (g dst channels)) ids procs)
   (good-msg-list-p
    (g src
       (g dst
          (send-compute-message local-state i nbrs channels)))
    ids procs)))

(defthm channel-nil-after-send-compute-message-when-dst-not-in-nbrs-2
    (implies (and (not (memberp dst  nbrs-to))
		  (subset nbrs nbrs-to )
                (not (g src (g dst channels))))
           (not (g src
                   (g dst
                      (send-compute-message local-state i nbrs channels))))))

(defthm channel-lookup-after-send-compute-message-when-src-not-i
  (implies (not (equal src i))
           (equal (g src
                     (g dst
                        (send-compute-message local-state i nbrs channels)))
                  (g src
                     (g dst channels)))))

(defthm channel-nil-after-send-compute-message-when-src-not-i
  (implies (and (not (equal src i))
                (not (g src (g dst channels))))
           (not
            (g src
               (g dst
                  (send-compute-message local-state i nbrs channels))))))

;end support: send-compute-message-channel-lookup


;start support: lift-send-compute-message-to-channel-table
;; Lift the compute-send preservation theorem from one channel to one row and
;; then to the full channel table.

(defthm good-channel-p-of-send-compute-message
  (implies (and (good-channel-p src dst channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channel-p
            src
            dst
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
  :hints (("Goal'"
           :cases ((equal src i)))))

(defthm good-channel-row-p-of-send-compute-message
  (implies (and (good-channel-row-p src dsts channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channel-row-p
            src
            dsts
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
    :hints (("Goal"
           :induct (good-channel-row-p src dsts channels ids procs))))

(defthm good-channels-p-of-send-compute-message
  (implies (and (good-channels-p srcs dsts channels ids procs)
                (subset nbrs (nbrs-to (g i procs))))
           (good-channels-p
            srcs
            dsts
            (send-compute-message local-state i nbrs channels)
            ids
            procs))
      :hints (("Goal"
           :induct (good-channels-p srcs dsts channels ids procs))))


;end support: lift-send-compute-message-to-channel-table


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Normal system-step preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Combines the local-state update and compute-send preservation lemmas.


;start target: good-state-p-of-system-step-normal
;; Main target for :normal inputs: combine the local-state process update with
;; the preservation of outgoing compute-message sends.

(defthm good-state-p-of-system-step-normal
  (implies (and (good-state-p st)
                (equal (ttype input) :normal))
           (good-state-p (system-step st input))))


;end target: good-state-p-of-system-step-normal


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Checkpoint-entry/process-table support
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Snapshot-entry construction and process-table update lemmas used when starting
;; a checkpoint.


;start support: checkpoint-snapshot-entry-construction
;; Starting a checkpoint creates a new snapshot entry.  These lemmas show that
;; the new entry and the modified snapshot table preserve good-snapshots-p.

(defthm g-of-s-nil-nil
  (equal (g k (s j nil nil))
         nil)
  :hints (("Goal"
           :cases ((equal k j)))))

(defthm good-normal-msg-list-p-of-g-of-s-nil-nil
  (good-normal-msg-list-p (g k (s j nil nil))))

(defthm good-snapshot-entry-p-of-make-snapshot-entry
  (implies (and (true-listp waiting-marker-from)
                (subset waiting-marker-from nbrs-from-i))
           (good-snapshot-entry-p
            (make-snapshot-entry local-snap-shot
                                 waiting-marker-from
                                 j)
            nbrs-from-i)))

(defthm good-snapshots-p-of-set-snapshot-entry-general
  (implies
   (and (good-snapshots-p snapshot-ids
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    snapshot-ids
    (s :snapshots
       (s sid entry (snapshots p))
       p)
    nbrs-from-i
    ids))
  :hints (("Goal"

           :in-theory (disable good-snapshot-entry-p))

          ("Subgoal *1/4''"
           :cases ((equal sid (car snapshot-ids))))))

(defthm good-snapshots-p-of-set-snapshot-ids-field
  (implies
   (good-snapshots-p snapshot-ids
                     p
                     nbrs-from-i
                     ids)
   (good-snapshots-p snapshot-ids
                     (s :snapshot-ids new-snapshot-ids p)
                     nbrs-from-i
                     ids)))

(defthm good-snapshots-p-of-set-snapshot-entry-after-set-snapshot-ids
  (implies
   (and (good-snapshots-p snapshot-ids
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    snapshot-ids
    (s :snapshots
       (s sid entry (g :snapshots p))
       (s :snapshot-ids new-snapshot-ids p))
    nbrs-from-i
    ids))
  :hints
  (("Goal"
    :use ((:instance good-snapshots-p-of-set-snapshot-ids-field
                     (snapshot-ids snapshot-ids)
                     (p p)
                     (new-snapshot-ids new-snapshot-ids)
                     (nbrs-from-i nbrs-from-i)
                     (ids ids))

          (:instance good-snapshots-p-of-set-snapshot-entry-general
                     (snapshot-ids snapshot-ids)
                     (p (s :snapshot-ids new-snapshot-ids p))
                     (sid sid)
                     (entry entry)
                     (nbrs-from-i nbrs-from-i)
                     (ids ids)))
    :in-theory (disable good-snapshot-entry-p))))

(defthm good-snapshots-p-of-install-snapshot-entry
  (implies
   (and (good-snapshots-p (snapshot-ids p)
                          p
                          nbrs-from-i
                          ids)
        (good-snapshot-entry-p entry nbrs-from-i))
   (good-snapshots-p
    (snapshot-ids (install-snapshot-entry sid entry p))
    (install-snapshot-entry sid entry p)
    nbrs-from-i
    ids))
  :hints (("Goal"
	   :in-theory (disable good-snapshot-entry-p))))

;end support: checkpoint-snapshot-entry-construction


;start support: checkpoint-updated-process-goodness
;; start-checkpoint-helper increments the counter and installs a snapshot entry.
;; These lemmas show the selected process remains good after that update.

(defthm good-snapshots-p-of-set-counter
  (implies (good-snapshots-p snapshot-ids
                             p
                             nbrs-from-i
                             ids)
           (good-snapshots-p snapshot-ids
                             (s :counter val p)
                             nbrs-from-i
                             ids)))

(defthm good-proc-p-of-increment-counter
  (implies (good-proc-p p ids)
           (good-proc-p
            (s :counter
               (+ 1 (counter p))
               p)
            ids)))

(defthm good-proc-p-of-start-checkpoint-helper-updated-proc
  (implies
   (and (good-proc-p (g i procs) ids)
	(memberp i ids))
   (good-proc-p
    (g i (start-checkpoint-helper procs i))
    ids)))

;end support: checkpoint-updated-process-goodness


;start support: checkpoint-process-table-lift
;; Lift the updated-process proof to the whole process table.  The key split is
;; whether the current id in the induction is the process that started checkpointing.

(defthm good-procs-p-of-set-good-proc
  (implies (and (good-procs-p ids procs all-ids)
                (good-proc-p new-p all-ids))
           (good-procs-p ids
                         (s i new-p procs)
                         all-ids))
  :hints (("Goal"
           :induct (good-procs-p ids procs all-ids))
          ("Subgoal *1/2"
           :cases ((equal i (car ids))))))

(defthm g-of-start-checkpoint-helper-diff
  (implies
   (not (equal k i))
   (equal (g k (start-checkpoint-helper procs i))
          (g k procs))))

(defthm good-procs-p-of-start-checkpoint-helper-when-not-member
  (implies
   (not (memberp i ids))
   (equal (good-procs-p ids
                        (start-checkpoint-helper procs i)
                        all-ids)
          (good-procs-p ids procs all-ids))))

(defthm good-procs-p-of-start-checkpoint-helper
  (implies
   (and (good-procs-p ids procs all-ids)
        (memberp i ids)
	(subset ids all-ids)
        (true-listp ids)
        (uniquep ids))
   (good-procs-p
    ids
    (start-checkpoint-helper procs i)
    all-ids))
  :hints
  (("Goal"
    :in-theory (disable start-checkpoint-helper good-proc-p)
    :induct (good-procs-p ids procs all-ids))
      ("Subgoal *1/2"
    :cases ((equal i (car ids))))))


;end support: checkpoint-process-table-lift


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Generic outgoing-message send preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Generalizes compute-send preservation to any good message.  The two-procs
;; version supports proofs where process metadata is updated before sending.


;start definitions: process-table-compatibility-predicates
;; Compatibility predicates for comparing an old process table with an updated
;; one.  They are used when channels are preserved across process-table changes.

(defun snapshot-ids-subset-procs-p (ids procs1 procs2)
  (if (endp ids)
      t
    (and (subset (snapshot-ids (g (car ids) procs1))
                 (snapshot-ids (g (car ids) procs2)))
         (snapshot-ids-subset-procs-p (cdr ids) procs1 procs2))))

(defun same-nbrs-to-p (srcs procs1 procs2)
  (if (endp srcs)
      t
    (and (equal (nbrs-to (g (car srcs) procs1))
                (nbrs-to (g (car srcs) procs2)))
         (same-nbrs-to-p (cdr srcs) procs1 procs2))))

;end definitions: process-table-compatibility-predicates


;start support: change-procs-preserves-message-and-channel-goodness
;; If the updated process table keeps enough snapshot ids and the same outgoing
;; neighbors, then existing good messages/channels remain good under the new table.

(defthm some-proc-has-snapshot-id-p-monotone
  (implies
   (and (snapshot-ids-subset-procs-p ids procs1 procs2)
        (some-proc-has-snapshot-id-p sid ids procs1))
   (some-proc-has-snapshot-id-p sid ids procs2)))

(defthm good-msg-p-change-procs
  (implies
   (and (good-msg-p msg ids procs1)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-msg-p msg ids procs2)))

(defthm good-msg-list-p-change-procs
  (implies
   (and (good-msg-list-p msgs ids procs1)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-msg-list-p msgs ids procs2)))

(defthm good-channel-p-change-procs
  (implies
   (and (good-channel-p src dst channels ids procs1)
        (equal (nbrs-to (g src procs1))
               (nbrs-to (g src procs2)))
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channel-p src dst channels ids procs2)))

(defthm good-channel-row-p-change-procs
  (implies
   (and (good-channel-row-p src dsts channels ids procs1)
        (equal (nbrs-to (g src procs1))
               (nbrs-to (g src procs2)))
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channel-row-p src dsts channels ids procs2)))

(defthm good-channels-p-change-procs
  (implies
   (and (good-channels-p srcs dsts channels ids procs1)
        (same-nbrs-to-p srcs procs1 procs2)
        (snapshot-ids-subset-procs-p ids procs1 procs2))
   (good-channels-p srcs dsts channels ids procs2)))

;end support: change-procs-preserves-message-and-channel-goodness


;start support: one-generic-channel-send
;; General one-channel send lemma for any already-good message.  This reuses the
;; same combined channel-update reasoning developed for compute messages.

(defthm good-msg-list-p-of-snoc-good-msg
  (implies (and (good-msg-list-p msgs ids procs)
                (good-msg-p msg ids procs))
           (good-msg-list-p (snoc msgs msg)
                            ids
                            procs))
  :hints (("Goal"
           :induct (snoc msgs msg))))

(defthm one-generic-send-update-disjunct
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (good-msg-p msg ids procs))
   (or (not (equal dst j))
       (not (equal src i))
       (good-msg-list-p
        (snoc (g i (g j channels)) msg)
        ids procs))))

(defthm good-msg-list-p-of-one-generic-send-update
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (good-msg-p msg ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (s j
             (s i
                (snoc (g i (g j channels)) msg)
                (g j channels))
             channels)))
    ids procs))
  :hints
  (("Goal"
    :do-not '(generalize fertilize)
    :use ((:instance good-msg-list-p-of-setting-channel-combined
                     (src src)
                     (dst dst)
                     (i i)
                     (j j)
                     (channels channels)
                     (ids ids)
                     (procs procs)
                     (val (snoc (g i (g j channels)) msg)))

          (:instance one-generic-send-update-disjunct
                     (src src)
                     (dst dst)
                     (i i)
                     (j j)
                     (channels channels)
                     (ids ids)
                     (procs procs)
                     (msg msg))))))

;end support: one-generic-channel-send


;start support: lift-generic-send-to-channel-table
;; Lift send-msg-all-outgoing-channels from message lists to channel rows and
;; the full channel table.  The two-procs version supports send-after-update cases.

(defthm good-msg-list-p-of-channel-after-send-msg-all-outgoing-channels
  (implies
   (and (good-msg-list-p (g src (g dst channels))
                         ids procs)
        (good-msg-p msg ids procs))
   (good-msg-list-p
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    ids procs))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-lookup-after-send-msg-all-outgoing-channels-when-src-not-i
  (implies
   (not (equal src i))
   (equal
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    (g src
       (g dst channels))))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-lookup-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs
  (implies
   (not (memberp dst nbrs))
   (equal
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))
    (g src
       (g dst channels))))
  :hints (("Goal"
           :induct (send-msg-all-outgoing-channels msg i nbrs channels))))

(defthm channel-nil-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs-to
  (implies
   (and (not (memberp dst nbrs-to))
        (subset nbrs nbrs-to)
        (not (g src (g dst channels))))
   (not
    (g src
       (g dst
          (send-msg-all-outgoing-channels msg i nbrs channels)))))
  :hints
  (("Goal"
    :use ((:instance not-memberp-when-subset-and-not-memberp
                     (xs nbrs)
                     (ys nbrs-to)
                     (a dst))

          (:instance channel-lookup-after-send-msg-all-outgoing-channels-when-dst-not-in-nbrs
                     (src src)
                     (dst dst)
                     (msg msg)
                     (i i)
                     (nbrs nbrs)
                     (channels channels))))))

(defthm good-channel-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channel-p src dst channels ids procs)
        (good-msg-p msg ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channel-p
    src
    dst
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :cases ((equal src i)))))

(defthm good-channel-row-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channel-row-p src dsts channels ids procs)
        (good-msg-p msg ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channel-row-p
    src
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :induct (good-channel-row-p src dsts channels ids procs))))

(defthm good-channels-p-of-send-msg-all-outgoing-channels
  (implies
   (and (good-channels-p srcs dsts channels ids procs)
        (good-msg-p msg ids procs)
        (subset nbrs (nbrs-to (g i procs))))
   (good-channels-p
    srcs
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs))
  :hints (("Goal"
           :induct (good-channels-p srcs dsts channels ids procs))))

(defthm good-channels-p-of-send-msg-all-outgoing-channels-two-procs
  (implies
   (and (good-channels-p srcs dsts channels ids procs1)

        ;; the new message must be good under the final procs
        (good-msg-p msg ids procs2)

        ;; procs2 keeps same outgoing-neighbor structure
        (same-nbrs-to-p srcs procs1 procs2)

        ;; procs2 contains at least all snapshot ids from procs1
        (snapshot-ids-subset-procs-p ids procs1 procs2)

        ;; sends only go to legal outgoing neighbors under procs2
        (subset nbrs (nbrs-to (g i procs2))))

   (good-channels-p
    srcs
    dsts
    (send-msg-all-outgoing-channels msg i nbrs channels)
    ids
    procs2)))


;end support: lift-generic-send-to-channel-table


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Start-checkpoint preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; start-checkpoint-helper preserves neighbor structure, monotonically adds the
;; new snapshot id, and sends a good marker message.


;start support: marker-message-goodness-after-start-checkpoint
;; After start-checkpoint-helper installs the new sid at process i, the marker
;; message carrying that sid is good under the updated process table.

(defthm good-msg-p-of-create-marker-message-after-start-checkpoint-helper
  (implies (memberp i ids)
           (good-msg-p
            (create-marker-message
             local-state
             (list i (counter (g i procs))))
            ids
            (start-checkpoint-helper procs i))))

;end support: marker-message-goodness-after-start-checkpoint


;start support: start-checkpoint-neighbor-preservation
;; Installing snapshot data and incrementing the counter do not change outgoing
;; neighbors.  This discharges the same-nbrs-to-p requirement for channel sends.

(defthm nbrs-to-of-install-snapshot-entry
  (equal (nbrs-to (install-snapshot-entry sid entry p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-counter
  (equal (nbrs-to (s :counter val p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-snapshots
  (equal (nbrs-to (s :snapshots val p))
         (nbrs-to p)))

(defthm nbrs-to-of-set-snapshot-ids
  (equal (nbrs-to (s :snapshot-ids val p))
         (nbrs-to p)))

(defthm nbrs-to-of-g-of-start-checkpoint-helper
  (equal (nbrs-to (g src (start-checkpoint-helper procs i)))
         (nbrs-to (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm same-nbrs-to-p-of-start-checkpoint-helper
  (same-nbrs-to-p srcs procs
        (start-checkpoint-helper procs i))
  :hints
  (("Goal"
    :induct (same-nbrs-to-p srcs procs
                            (start-checkpoint-helper procs i))
    :in-theory (disable start-checkpoint-helper))))

;end support: start-checkpoint-neighbor-preservation


;start support: start-checkpoint-snapshot-id-monotonicity
;; start-checkpoint-helper only adds the new snapshot id; it does not remove old
;; ids.  This provides the snapshot-id monotonicity needed by the two-procs lemma.

(defthm subset-snapshot-ids-of-g-of-start-checkpoint-helper
  (subset (snapshot-ids (g k procs))
          (snapshot-ids (g k (start-checkpoint-helper procs i))))
  :hints
  (("Goal"
    :cases ((equal k i)))))

(defthm snapshot-ids-subset-procs-p-of-start-checkpoint-helper
  (snapshot-ids-subset-procs-p
   ids
   procs
   (start-checkpoint-helper procs i))
  :hints
  (("Goal"
    :induct (snapshot-ids-subset-procs-p
             ids
             procs
             (start-checkpoint-helper procs i))
    :in-theory (disable start-checkpoint-helper))))

;end support: start-checkpoint-snapshot-id-monotonicity


;start target: good-state-p-of-system-step-start-checkpoint
;; Main target for :start-checkpoint inputs: update the initiating process, prove
;; the marker message is good, and preserve the outgoing marker sends.

(defthm good-state-p-of-system-step-start-checkpoint
  (implies (and (good-state-p st)
                (equal (ttype input) :start-checkpoint)
		(memberp (pid input) (proc-ids st)))
           (good-state-p (system-step st input)))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p
			start-checkpoint-helper
                        make-snapshot-entry
                        install-snapshot-entry
			create-marker-message))))


;end target: good-state-p-of-system-step-start-checkpoint


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Start-recovery preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; start-recovery-helper changes only recovery-related fields, preserves neighbor
;; and snapshot-id structure, and sends a good recovery message.


;start support: start-recovery-field-preservation
;; start-recovery-helper changes only recovery-control fields.  Snapshot tables,
;; neighbor lists, snapshot ids, and counters remain unchanged.

(defthm snapshots-of-g-of-start-recovery-helper
  (equal
   (snapshots (g src (start-recovery-helper procs i)))
   (snapshots (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm good-snapshots-p-of-g-of-start-recovery-helper-general
  (implies
   (good-snapshots-p snapshot-ids
                     (g src procs)
                     nbrs-from
                     ids)
   (good-snapshots-p snapshot-ids
                     (g src (start-recovery-helper procs i))
                     nbrs-from
                     ids))
  :hints
  (("Goal"
    :in-theory (disable start-recovery-helper)
    :cases ((equal src i)))))

(defthm nbrs-from-of-g-of-start-recovery-helper
  (equal
   (nbrs-from (g src (start-recovery-helper procs i)))
   (nbrs-from (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i))
    :in-theory (enable start-recovery-helper))))

(defthm nbrs-to-of-g-of-start-recovery-helper
  (equal
   (nbrs-to (g src (start-recovery-helper procs i)))
   (nbrs-to (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i))
    :in-theory (enable start-recovery-helper))))

(defthm snapshot-ids-of-g-of-start-recovery-helper
  (equal
   (snapshot-ids (g src (start-recovery-helper procs i)))
   (snapshot-ids (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm subset-waiting-recovery-from-of-g-i-of-start-recovery-helper
  (subset
   (waiting-recovery-from
    (g i (start-recovery-helper procs i)))
   (nbrs-from (g i procs))))

(defthm counter-of-g-of-start-recovery-helper
  (equal
   (counter (g src (start-recovery-helper procs i)))
   (counter (g src procs)))
  :hints
  (("Goal"
    :cases ((equal src i)))))

(defthm proc-status-of-g-i-of-start-recovery-helper
  (equal
   (proc-status
    (g i (start-recovery-helper procs i)))
   :recovering))

(defthm waiting-recovery-from-of-g-i-of-start-recovery-helper
  (equal
   (waiting-recovery-from
    (g i (start-recovery-helper procs i)))
   (nbrs-from (g i procs))))

;end support: start-recovery-field-preservation


;start support: start-recovery-process-table-lift
;; The recovering process remains good, and all other processes are unchanged.
;; Lift this to good-procs-p for the whole process table.

(defthm good-proc-p-of-start-recover-helper-updated-proc
  (implies
   (and (good-proc-p (g i procs) ids)
	(memberp i ids))
   (good-proc-p
    (g i (start-recovery-helper procs i))
    ids))
    :hints
  (("Goal"
    :in-theory (disable start-recovery-helper))))

(defthm g-of-start-recovery-helper-when-not-equal
  (implies
   (not (equal k i))
   (equal
    (g k (start-recovery-helper procs i))
    (g k procs))))

(defthm good-procs-p-of-start-recovery-helper
  (implies
   (and (good-procs-p ids procs all-ids)
        (true-listp ids)
	(subset ids all-ids)
        (uniquep ids)
        (memberp i ids))
   (good-procs-p
    ids
    (start-recovery-helper procs i)
    all-ids))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p start-recovery-helper)
    :induct (good-procs-p ids procs all-ids))
   ("Subgoal *1/2"
    :cases ((equal i (car ids))))))

;end support: start-recovery-process-table-lift


;start support: start-recovery-neighbor-and-snapshot-compatibility
;; Prove the compatibility facts required when recovery messages are sent under
;; the updated process table: same outgoing neighbors and preserved snapshot ids.

(defthm same-nbrs-to-p-of-start-recovery-helper
  (same-nbrs-to-p srcs procs
        (start-recovery-helper procs i))
  :hints
  (("Goal"
    :induct (same-nbrs-to-p srcs procs
                            (start-recovery-helper procs i))
    :in-theory (disable start-recovery-helper))))

(defthm subset-snapshot-ids-of-g-of-start-recovery-helper
  (subset (snapshot-ids (g k procs))
          (snapshot-ids (g k (start-recovery-helper procs i))))
  :hints
  (("Goal"
    :cases ((equal k i)))))

(defthm snapshot-ids-subset-procs-p-of-start-recovery-helper
  (snapshot-ids-subset-procs-p
   ids
   procs
   (start-recovery-helper procs i))
  :hints
  (("Goal"
    :induct (snapshot-ids-subset-procs-p
             ids
             procs
             (start-recovery-helper procs i))
    :in-theory (disable start-recovery-helper))))

;end support: start-recovery-neighbor-and-snapshot-compatibility


;start support: recovery-message-goodness-after-start-recovery
;; A recovery message uses an existing snapshot id from the recovering process.
;; These lemmas establish that the sid exists before and after the helper update.

(defthm memberp-snapshot-ids-of-start-recovery-helper
  (equal
   (memberp sid
            (snapshot-ids
             (g src (start-recovery-helper procs i))))
   (memberp sid
            (snapshot-ids
             (g src procs)))))

(defthm some-proc-has-snapshot-id-p-of-start-recovery-helper
  (implies
   (and (memberp i ids)
        (some-proc-has-snapshot-id-p sid ids procs))
   (some-proc-has-snapshot-id-p
    sid
    ids
    (start-recovery-helper procs i)))
  :hints
  (("Goal"
    :in-theory (disable start-recovery-helper))))

(defthm some-proc-has-car-snapshot-id-before-recovery
  (implies
   (and (memberp i ids)
        (consp (snapshot-ids (g i procs))))
   (some-proc-has-snapshot-id-p
    (car (snapshot-ids (g i procs)))
    ids
    procs))
  :hints
  (("Goal"
    :induct (some-proc-has-snapshot-id-p
             (car (snapshot-ids (g i procs)))
             ids
             procs))
   ("Subgoal *1/2"
    :cases ((equal i (car ids))))))

(defthm some-proc-has-car-snapshot-id-after-recovery
  (implies
   (and (memberp i ids)
        (consp (snapshot-ids (g i procs))))
   (some-proc-has-snapshot-id-p
    (car (snapshot-ids (g i procs)))
    ids
     (start-recovery-helper procs i))))

(defthm good-msg-p-of-create-recovery-message-after-start-recovery-helper
  (implies
   (and (memberp i ids)
        (consp (snapshot-ids (g i procs))))
   (good-msg-p
    (create-recovery-message
     local-state
     (car (snapshot-ids (g i procs))))
    ids
    (start-recovery-helper procs i)))
    :hints
  (("Goal"
    :in-theory (disable start-recovery-helper
			create-recovery-message))))

;end support: recovery-message-goodness-after-start-recovery


;start support: nonempty-snapshot-ids-for-recovery
;; good-proc-p requires :init to be present in the snapshot-id list, so any good
;; process has a nonempty snapshot-id list for choosing a recovery sid.

(defthm consp-snapshot-ids-of-g-when-good-procs-p
  (implies
   (and (good-procs-p ids procs all-ids)
        (memberp i ids))
   (consp (snapshot-ids (g i procs)))))

;end support: nonempty-snapshot-ids-for-recovery


;start target: good-state-p-of-system-step-recover
;; Main target for :recover inputs: update the initiating process to recovering,
;; create a good recovery message, and preserve all outgoing recovery sends.

(defthm good-state-p-of-system-step-recover
  (implies (and (good-state-p st)
                (equal (ttype input) :recover)
		(memberp (pid input) (proc-ids st)))
           (good-state-p (system-step st input)))
  :hints
  (("Goal"
    :in-theory (disable good-proc-p
			start-recovery-helper
			create-recovery-message))))

;end target: good-state-p-of-system-step-recover


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; First-recovery-message preservation support
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Target theorem in this block:
;; ;;   good-state-p-of-handle-first-recovery-msg
;; ;;
;; ;; Proof idea:
;; ;;   1. The receiver process update preserves good-proc-p.
;; ;;   2. Removing the consumed recovery message preserves good-channels-p.
;; ;;   3. The forwarded recovery message is good under the updated procs.
;; ;;   4. The updated procs preserve outgoing-neighbor structure and snapshot ids.
;; ;;   5. Therefore handle-first-recovery-msg preserves good-state-p.


;; ;start support: first-recovery-process-field-preservation
;; ;; These lemmas say that update-proc-for-first-recovery-msg only changes
;; ;; recovery-related fields.  Neighbor fields, snapshot ids, counter, and
;; ;; existing snapshot entries remain structurally usable.

;; (defthm nbrs-from-of-update-proc-for-first-recovery-msg
;;   (equal (g :nbrs-from
;;             (update-proc-for-first-recovery-msg p sid j))
;;          (g :nbrs-from p)))

;; (defthm waiting-recovery-from-of-update-proc-for-first-recovery-msg
;;   (equal (g :waiting-recovery-from
;;             (update-proc-for-first-recovery-msg p sid j))
;;          (remove-from-list (g :nbrs-from p) j)))

;; (defthm subset-of-remove-from-list
;;   (subset (remove-from-list xs a)
;;           xs))

;; (defthm nbrs-to-of-update-proc-for-first-recovery-msg
;;   (equal (g :nbrs-to
;;             (update-proc-for-first-recovery-msg p sid j))
;;          (g :nbrs-to p)))

;; (defthm snapshot-ids-of-update-proc-for-first-recovery-msg
;;   (equal (g :snapshot-ids
;;             (update-proc-for-first-recovery-msg p sid j))
;;          (g :snapshot-ids p)))

;; (defthm counter-of-update-proc-for-first-recovery-msg
;;   (equal (g :counter
;;             (update-proc-for-first-recovery-msg p sid j))
;;          (g :counter p)))

;; (defthm proc-status-of-update-proc-for-first-recovery-msg
;;   (equal (g :proc-status
;;             (update-proc-for-first-recovery-msg p sid j))
;;          :recovering))
;; ;end support: first-recovery-process-field-preservation


;; ;start support: first-recovery-process-goodness
;; ;; Once the basic fields are controlled, prove that the updated receiver process
;; ;; still satisfies good-proc-p.  The sid must already exist at the receiver, and
;; ;; j must be a legal incoming neighbor because the first recovery message came
;; ;; from channel j -> i.

;; (defthm good-snapshots-p-of-update-proc-for-first-recovery-msg
;;   (implies
;;    (good-snapshots-p snapshot-ids p nbrs-from ids)
;;    (good-snapshots-p
;;     snapshot-ids
;;     (update-proc-for-first-recovery-msg p sid j)
;;     nbrs-from
;;     ids)))

;; (defthm good-proc-p-of-update-proc-for-first-recovery-msg
;;   (implies
;;    (and (good-proc-p p ids)

;;         ;; sid must refer to an existing snapshot entry of p.
;;         (memberp sid (snapshot-ids p))

;;         ;; j is the sender of the recovery message.
;;         (memberp j (nbrs-from p)))
;;    (good-proc-p
;;     (update-proc-for-first-recovery-msg p sid j)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable update-proc-for-first-recovery-msg))))
;; ;end support: first-recovery-process-goodness


;; ;start support: remove-consumed-recovery-message
;; ;; Handling a recovery message first removes the head message from channel
;; ;; j -> i.  These lemmas show that this removal preserves message-list,
;; ;; channel-row, and full channel-table well-formedness.

;; (defthm channel-state-of-remove-message-from-channel
;;   (equal (g src
;;             (g dst
;;                (remove-message-from-channel j i channels)))
;;          (if (and (equal src j)
;;                   (equal dst i))
;;              (cdr (g src (g dst channels)))
;;            (g src (g dst channels)))))

;; (defthm good-msg-list-p-of-cdr
;;   (implies
;;    (good-msg-list-p msgs ids procs)
;;    (good-msg-list-p (cdr msgs) ids procs)))

;; (defthm good-channel-row-p-of-remove-message-from-channel
;;   (implies
;;    (good-channel-row-p src dsts channels ids procs)
;;    (good-channel-row-p
;;     src
;;     dsts
;;     (remove-message-from-channel j i channels)
;;     ids
;;     procs))
;;   :hints
;;   (("Goal"
;;     :induct (good-channel-row-p src dsts channels ids procs)
;;     :in-theory (disable remove-message-from-channel))))

;; (defthm good-channels-p-of-remove-message-from-channel
;;   (implies
;;    (good-channels-p srcs dsts channels ids procs)
;;    (good-channels-p
;;     srcs
;;     dsts
;;     (remove-message-from-channel j i channels)
;;     ids
;;     procs))
;;   :hints
;;   (("Goal"
;;     :induct (good-channels-p srcs dsts channels ids procs)
;;     :in-theory (disable remove-message-from-channel))))
;; ;end support: remove-consumed-recovery-message


;; ;start support: recovery-message-goodness
;; ;; A recovery message is good when its sid is present in some process.  In this
;; ;; first-recovery case, the sid is known to be in the receiver's snapshot list.
;; ;; Since the receiver update preserves snapshot ids, the same message is also
;; ;; good under the updated process table.

;; (defthm good-msg-p-of-get-msg-from-channel-when-recovery
;;   (implies
;;    (and (equal (msg-type (get-msg-from-channel j i channels))
;;                :recovery)
;;         (memberp (sid (get-msg-from-channel j i channels))
;;                  (snapshot-ids (g i procs)))
;;         (memberp i ids))
;;    (good-msg-p
;;     (get-msg-from-channel j i channels)
;;     ids
;;     procs)))

;; (defthm good-msg-p-of-get-msg-from-channel-when-recovery-after-first-recovery-update
;;   (implies
;;    (and (equal (msg-type (get-msg-from-channel j i channels))
;;                :recovery)
;;         (memberp (sid (get-msg-from-channel j i channels))
;;                  (snapshot-ids (g i procs)))
;;         (memberp i ids))
;;    (good-msg-p
;;     (get-msg-from-channel j i channels)
;;     ids
;;     (s i
;;        (update-proc-for-first-recovery-msg
;;         (g i procs)
;;         (sid (get-msg-from-channel j i channels))
;;         j)
;;        procs))))
;; ;end support: recovery-message-goodness


;; ;start support: updated-procs-compatible-with-channel-preservation
;; ;; The generic two-process channel-send lemma needs two compatibility facts:
;; ;;   - outgoing-neighbor structure is unchanged;
;; ;;   - snapshot-id sets are preserved/subset-related.
;; ;; These lemmas discharge those hypotheses for the one-process update used by
;; ;; handle-first-recovery-msg.

;; (defthm nbrs-to-of-g-of-s-update-proc-for-first-recovery-msg
;;   (equal
;;    (g :nbrs-to
;;       (g x
;;          (s k
;;             (update-proc-for-first-recovery-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (g :nbrs-to
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm same-nbrs-to-p-of-update-proc-for-first-recovery-msg
;;   (same-nbrs-to-p
;;    srcs
;;    procs
;;    (s k
;;       (update-proc-for-first-recovery-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable update-proc-for-first-recovery-msg))))

;; (defthm same-nbrs-to-p-commutative
;;   (implies
;;    (same-nbrs-to-p ids procs1 procs2)
;;    (same-nbrs-to-p ids procs2 procs1))
;;   :hints
;;   (("Goal"
;;     :induct (same-nbrs-to-p ids procs1 procs2))))

;; (defthm snapshot-ids-of-g-of-s-update-proc-for-first-recovery-msg
;;   (equal
;;    (g :snapshot-ids
;;       (g x
;;          (s k
;;             (update-proc-for-first-recovery-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (g :snapshot-ids
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm snapshot-ids-subset-procs-p-of-update-proc-for-first-recovery-msg
;;   (snapshot-ids-subset-procs-p
;;    ids
;;    procs
;;    (s k
;;       (update-proc-for-first-recovery-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-recovery-msg))))

;; (defthm snapshot-ids-subset-procs-p-of-update-proc-for-first-recovery-msg-reverse
;;   (snapshot-ids-subset-procs-p
;;    ids
;;    (s k
;;       (update-proc-for-first-recovery-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs)
;;    procs)
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-recovery-msg))))
;; ;end support: updated-procs-compatible-with-channel-preservation


;; ;start target: good-state-p-of-handle-first-recovery-msg
;; ;; Main target theorem for the first recovery-message case.
;; ;;
;; ;; handle-first-recovery-msg does three important things:
;; ;;   1. removes the consumed recovery message from channel j -> i;
;; ;;   2. updates receiver i from :normal to :recovering;
;; ;;   3. forwards the recovery message to i's outgoing neighbors.
;; ;;
;; ;; The supporting lemmas above prove each of those operations preserves the
;; ;; pieces needed by good-state-p.

;; (defthm good-state-p-of-handle-first-recovery-msg
;;   (implies
;;    (and (good-state-p st)

;;         ;; Valid receiver and sender.
;;         (memberp i (proc-ids st))
;;         (memberp j (proc-ids st))
;;         (memberp j (nbrs-from (g i (procs st))))

;;         ;; msg is the first message on channel j -> i.
;;         (equal msg
;;                (get-msg-from-channel j i (channels st)))

;;         ;; This is really a recovery message.
;;         (equal (msg-type msg) :recovery)

;;         ;; First recovery-message case: receiver has not started recovery yet.
;;         (equal (proc-status (g i (procs st))) :normal)

;;         ;; The process has the snapshot being recovered.
;;         (memberp (sid msg)
;;                  (snapshot-ids (g i (procs st)))))
;;    (good-state-p
;;     (handle-first-recovery-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable good-proc-p
;;                         remove-message-from-channel
;;                         get-msg-from-channel
;;                         update-proc-for-first-recovery-msg))))
;; ;end target: good-state-p-of-handle-first-recovery-msg


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Non-first recovery-message preservation
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; This section handles the case where process i receives a recovery message
;; ;; while it is already in recovery mode.  The handler only removes sender j
;; ;; from i's waiting-recovery-from list.  If that list becomes empty, i returns
;; ;; to :normal; otherwise, i stays :recovering.

;; ;start support: non-first-recovery-process-field-preservation
;; ;; Field-level facts about update-proc-for-non-first-recovery-msg.
;; ;; These lemmas say exactly which fields are unchanged and which field is
;; ;; changed.  They keep ACL2 from opening the updater repeatedly in later proofs.

;; (defthm nbrs-from-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :nbrs-from
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (g :nbrs-from p)))

;; (defthm nbrs-to-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :nbrs-to
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (g :nbrs-to p)))

;; (defthm waiting-recovery-from-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :waiting-recovery-from
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (remove-from-list (g :waiting-recovery-from p) j)))

;; (defthm snapshot-ids-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :snapshot-ids
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (g :snapshot-ids p)))

;; (defthm counter-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :counter
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (g :counter p)))

;; (defthm local-state-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :local-state
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (g :local-state p)))

;; ;; The only status change is controlled by the remaining wait list.
;; ;; If all expected recovery messages have arrived, the process becomes normal;
;; ;; otherwise it remains recovering.
;; (defthm proc-status-of-update-proc-for-non-first-recovery-msg
;;   (equal (g :proc-status
;;             (update-proc-for-non-first-recovery-msg p j))
;;          (if (endp (remove-from-list (g :waiting-recovery-from p) j))
;;              :normal
;;              :recovering)))

;; ;; Removing an element from a list cannot introduce a new element outside ys.
;; ;; This is used to preserve:
;; ;;   waiting-recovery-from subset nbrs-from.
;; (defthm subset-of-remove-from-list-when-subset
;;   (implies
;;    (subset xs ys)
;;    (subset (remove-from-list xs a)
;;            ys)))

;; ;end support: non-first-recovery-process-field-preservation


;; ;start support: non-first-recovery-process-wellformedness
;; ;; Lift the field-level facts to the full process invariant.
;; ;; Since snapshot ids, snapshots, local state, counter, and neighbors are
;; ;; unchanged, the main thing to preserve is that the shortened wait list is
;; ;; still a subset of nbrs-from.

;; (defthm good-snapshots-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (good-snapshots-p snapshot-ids p nbrs-from ids)
;;    (good-snapshots-p
;;     snapshot-ids
;;     (update-proc-for-non-first-recovery-msg p j)
;;     nbrs-from
;;     ids)))

;; (defthm good-proc-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (good-proc-p p ids)
;;    (good-proc-p
;;     (update-proc-for-non-first-recovery-msg p j)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable update-proc-for-non-first-recovery-msg))))

;; ;end support: non-first-recovery-process-wellformedness


;; ;start support: non-first-recovery-updated-procs-field-compatibility
;; ;; Facts about reading fields from the process table after updating one process.
;; ;; These are needed because channel well-formedness depends on process metadata,
;; ;; especially outgoing neighbors and known snapshot ids.

;; (defthm nbrs-to-of-g-of-s-update-proc-for-non-first-recovery-msg
;;   (equal
;;    (g :nbrs-to
;;       (g x
;;          (s k
;;             (update-proc-for-non-first-recovery-msg
;;              (g k procs)
;;              j)
;;             procs)))
;;    (g :nbrs-to
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm snapshot-ids-of-g-of-s-update-proc-for-non-first-recovery-msg
;;   (equal
;;    (g :snapshot-ids
;;       (g x
;;          (s k
;;             (update-proc-for-non-first-recovery-msg
;;              (g k procs)
;;              j)
;;             procs)))
;;    (g :snapshot-ids
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; ;end support: non-first-recovery-updated-procs-field-compatibility


;; ;start support: non-first-recovery-message-goodness-preservation
;; ;; Updating a process for a non-first recovery message does not change any
;; ;; process's snapshot-id list.  Therefore, any message that was good before the
;; ;; update is still good after the update.

;; (defthm some-proc-has-snapshot-id-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (some-proc-has-snapshot-id-p sid ids procs)
;;    (some-proc-has-snapshot-id-p
;;     sid
;;     ids
;;     (s k
;;        (update-proc-for-non-first-recovery-msg
;;         (g k procs)
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable update-proc-for-non-first-recovery-msg))))

;; (defthm good-msg-list-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (good-msg-list-p msgs ids procs)
;;    (good-msg-list-p
;;     msgs
;;     ids
;;     (s k
;;        (update-proc-for-non-first-recovery-msg
;;         (g k procs)
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable update-proc-for-non-first-recovery-msg))))

;; ;end support: non-first-recovery-message-goodness-preservation


;; ;start support: non-first-recovery-channel-table-preservation
;; ;; Lift message-goodness preservation to channel rows and then to the whole
;; ;; channel table.  The channel contents are not changed by these lemmas; only
;; ;; the process table used to interpret channel/message well-formedness changes.

;; (defthm good-channel-row-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (good-channel-row-p src dsts channels ids procs)
;;    (good-channel-row-p
;;     src
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-non-first-recovery-msg
;;         (g k procs)
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channel-row-p src dsts channels ids procs)
;;     :in-theory
;;     (disable update-proc-for-non-first-recovery-msg))))

;; (defthm good-channels-p-of-update-proc-for-non-first-recovery-msg
;;   (implies
;;    (good-channels-p srcs dsts channels ids procs)
;;    (good-channels-p
;;     srcs
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-non-first-recovery-msg
;;         (g k procs)
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channels-p srcs dsts channels ids procs)
;;     :in-theory (disable update-proc-for-non-first-recovery-msg))))

;; ;end support: non-first-recovery-channel-table-preservation


;; ;start target: good-state-p-of-handle-non-first-recovery-msg
;; ;; Target theorem for the non-first recovery-message handler.
;; ;; Assumptions identify a valid channel j -> i, say that msg is the head of
;; ;; that channel, and require that i is not :normal.  Therefore this handler uses
;; ;; the non-first recovery case rather than the first recovery case.
;; ;;
;; ;; Proof idea:
;; ;; 1. remove-message-from-channel preserves good-channels-p;
;; ;; 2. update-proc-for-non-first-recovery-msg preserves good-proc-p for i;
;; ;; 3. the same update does not invalidate channel/message well-formedness.

;; (defthm good-state-p-of-handle-non-first-recovery-msg
;;   (implies
;;    (and (good-state-p st)

;;         ;; Valid receiver and sender.
;;         (memberp i (proc-ids st))
;;         (memberp j (proc-ids st))
;;         (memberp j (nbrs-from (g i (procs st))))

;;         ;; msg is the first message on channel j -> i.
;;         (equal msg
;;                (get-msg-from-channel j i (channels st)))

;;         ;; This is really a recovery message.
;;         (equal (msg-type msg) :recovery)

;;         ;; Non-first recovery-message case:
;;         ;; receiver is already recovering or crashed, but not normal.
;;         (not (equal (proc-status (g i (procs st))) :normal)))
;;    (good-state-p
;;     (handle-non-first-recovery-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory (disable good-proc-p
;;                         remove-message-from-channel
;;                         get-msg-from-channel
;;                         update-proc-for-non-first-recovery-msg))))

;; ;end target: good-state-p-of-handle-non-first-recovery-msg


;; ;start target: good-state-p-of-handle-recovery-msg
;; ;; Dispatcher theorem for handle-recovery-msg.
;; ;; The handler splits into two cases based on receiver i's current status:
;; ;;
;; ;;   1. If i is :normal, this is the first recovery message for i.
;; ;;      Then the sid carried by msg must already be in i's snapshot-ids.
;; ;;
;; ;;   2. If i is not :normal, this is the non-first recovery case.
;; ;;      The theorem above handles that branch.
;; ;;
;; ;; The extra implication in the hypotheses is exactly the invariant needed for
;; ;; the first branch:
;; ;;   Any recovery message on channel j -> i must carry a sid that receiver i
;; ;;   already knows when i is still normal.

;; (defthm good-state-p-of-handle-recovery-msg
;;   (implies
;;    (and (good-state-p st)

;;         ;; Valid receiver and sender.
;;         (memberp i (proc-ids st))
;;         (memberp j (proc-ids st))
;;         (memberp j (nbrs-from (g i (procs st))))

;;         ;; msg is the first message on channel j -> i.
;;         (equal msg
;;                (get-msg-from-channel j i (channels st)))

;;         ;; This is really a recovery message.
;;         (equal (msg-type msg) :recovery)

;;         ;; First-recovery side condition:
;;         ;; if i is still normal, then the recovery sid must already be known
;;         ;; by i.  Non-first recovery does not need this extra assumption.
;;         (implies
;;          (equal (proc-status (g i (procs st))) :normal)
;;          (memberp (sid msg)
;;                   (snapshot-ids (g i (procs st))))))
;;    (good-state-p
;;     (handle-recovery-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-state-p
;;              good-proc-p
;;              handle-first-recovery-msg
;;              handle-non-first-recovery-msg
;;              remove-message-from-channel
;;              get-msg-from-channel
;;              update-proc-for-first-recovery-msg
;;              update-proc-for-non-first-recovery-msg))))

;; ;end target: good-state-p-of-handle-recovery-msg


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Marker-message preservation
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Marker handling is the checkpoint-side analogue of recovery handling.
;; A marker message either starts a new snapshot entry at receiver i, or it
;; updates an already-existing snapshot entry by removing sender j from the
;; waiting-marker list.


;; ;start support: first-marker-process-field-preservation
;; ;; Field-level facts for the first-marker update.
;; ;; In the first-marker case, receiver i has not seen sid before.  The update
;; ;; installs a new snapshot entry for sid, but it should not change i's neighbor
;; ;; lists, recovery-wait list, counter, or process status.  These rewrite lemmas
;; ;; keep later good-proc-p proofs from opening the updater repeatedly.

;; (defthm nbrs-to-of-update-proc-for-first-marker-msg
;;   (equal (g :nbrs-to
;;             (update-proc-for-first-marker-msg p sid j))
;;          (g :nbrs-to p)))

;; (defthm nbrs-from-of-update-proc-for-first-marker-msg
;;   (equal (g :nbrs-from
;;             (update-proc-for-first-marker-msg p sid j))
;;          (g :nbrs-from p)))

;; (defthm good-snapshot-ids-p-of-update-proc-for-first-marker-msg
;;   (implies
;;    (and
;;     (good-snapshot-ids-p (g :snapshot-ids p) ids)
;;     (good-snapshot-id-p sid ids))
;;    (good-snapshot-ids-p
;;     (g :snapshot-ids
;;        (update-proc-for-first-marker-msg p sid j))
;;     ids)))

;; (defthm waiting-recovery-from-of-update-proc-for-first-marker-msg
;;   (equal (g :waiting-recovery-from
;;             (update-proc-for-first-marker-msg p sid j))
;;          (g :waiting-recovery-from p)))

;; (defthm counter-of-update-proc-for-first-marker-msg
;;   (equal (g :counter
;;             (update-proc-for-first-marker-msg p sid j))
;;          (g :counter p)))

;; ;end support: first-marker-process-field-preservation


;; ;start support: first-marker-snapshot-entry-preservation
;; ;; The first marker creates a new snapshot entry.  The following lemmas show
;; ;; that the snapshot table remains well formed and that the snapshot-id list
;; ;; remains a true list, unique, and still contains :init after sid is added.

;; (defthm good-snapshots-p-of-update-proc-for-first-marker-msg
;;   (implies
;;    (and
;;     (good-snapshots-p (snapshot-ids p)
;;                       p
;;                       (nbrs-from p)
;;                       ids)
;;     (true-listp (nbrs-from p)))
;;    (good-snapshots-p
;;     (snapshot-ids
;;      (update-proc-for-first-marker-msg p sid j))
;;     (update-proc-for-first-marker-msg p sid j)
;;     (nbrs-from p)
;;     ids))
;;     :hints
;;   (("Goal"
;;     :in-theory
;;     (disable 
;;              install-snapshot-entry
;;              make-snapshot-entry
;;              good-snapshot-entry-p))))

;; (defthm true-listp-snapshot-ids-of-update-proc-for-first-marker-msg
;;   (implies
;;    (true-listp (snapshot-ids p))
;;    (true-listp
;;     (snapshot-ids
;;      (update-proc-for-first-marker-msg p sid j)))))

;; (defthm uniquep-snapshot-ids-of-update-proc-for-first-marker-msg
;;   (implies
;;    (and (uniquep (snapshot-ids p))
;;         (not (memberp sid (snapshot-ids p))))
;;    (uniquep
;;     (snapshot-ids
;;      (update-proc-for-first-marker-msg p sid j)))))

;; (defthm memberp-init-snapshot-ids-of-update-proc-for-first-marker-msg
;;   (implies
;;    (memberp :init (snapshot-ids p))
;;    (memberp
;;     :init
;;     (snapshot-ids
;;      (update-proc-for-first-marker-msg p sid j)))))

;; ;end support: first-marker-snapshot-entry-preservation


;; ;start support: first-marker-status-preservation
;; ;; Receiving a marker does not change the process status.  It only affects the
;; ;; snapshot bookkeeping for the marker's sid.

;; (defthm proc-status-of-update-proc-for-first-marker-msg
;;   (equal (proc-status
;;           (update-proc-for-first-marker-msg p sid j))
;;          (proc-status p)))

;; ;end support: first-marker-status-preservation


;; ;start support: first-marker-process-wellformedness
;; ;; Lift the field and snapshot-entry facts to good-proc-p and then to
;; ;; good-procs-p for the whole process table.  The first-marker branch requires
;; ;; that sid is new at receiver i and structurally valid.

;; (defthm good-proc-p-of-update-proc-for-first-marker-msg
;;   (implies
;;    (and
;;     (good-proc-p p ids)
;;     ;; First-marker case: this process does not already know sid.
;;     (not (memberp sid (snapshot-ids p)))
;;     ;; The sid carried by the marker is structurally valid.
;;     (good-snapshot-id-p sid ids))
;;    (good-proc-p
;;     (update-proc-for-first-marker-msg p sid j)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-marker-msg
;;              make-snapshot-entry
;;              install-snapshot-entry
;;              good-snapshot-entry-p
;; 	     good-snapshot-id-p
;;              good-snapshots-p))))

;; (defthm good-procs-p-of-update-proc-for-first-marker-msg-from-some-proc-has-sid
;;   (implies
;;    (and
;;     (good-procs-p ids procs ids)
;;     (memberp i ids)
;;     (not (memberp sid
;;                   (snapshot-ids (g i procs))))
;;     (good-snapshot-id-p sid ids))
;;    (good-procs-p
;;     ids
;;     (s i
;;        (update-proc-for-first-marker-msg
;;         (g i procs)
;;         sid
;;         j)
;;        procs)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-proc-p
;;              update-proc-for-first-marker-msg))))


;; ;end support: first-marker-process-wellformedness


;; ;start support: marker-sid-validity-from-system-knowledge
;; ;; handle-first-marker-msg knows that the marker sid exists somewhere in the
;; ;; system.  To install a new snapshot entry at receiver i, we also need the sid
;; ;; to satisfy good-snapshot-id-p.  These lemmas choose a witness process that
;; ;; already has sid and transfer good-snapshot-id-p from that process's
;; ;; snapshot-id invariant.

;; (defthm good-snapshot-id-p-when-memberp-good-snapshot-ids-p
;;   (implies
;;    (and (memberp sid snapshot-ids)
;;         (good-snapshot-ids-p snapshot-ids ids))
;;    (good-snapshot-id-p sid ids)))

;; (defthm good-snapshot-ids-p-of-snapshot-ids-when-good-proc-p
;;   (implies
;;    (good-proc-p p ids)
;;    (good-snapshot-ids-p (snapshot-ids p) ids)))

;; ;; NOTE: This theorem appears a second time in the original file.  If ACL2 does
;; ;; not treat it as a redundant event, delete one copy.
;; (defthm good-snapshot-ids-p-of-snapshot-ids-when-good-proc-p
;;   (implies
;;    (good-proc-p p ids)
;;    (good-snapshot-ids-p (snapshot-ids p) ids)))

;; (defthm good-snapshot-id-p-when-memberp-snapshot-ids-of-good-proc
;;   (implies
;;    (and (good-proc-p p ids)
;;         (memberp sid (snapshot-ids p)))
;;    (good-snapshot-id-p sid ids))
;;   :hints (("Goal"
;; 	   :in-theory (disable good-snapshot-id-p))))

;; (defun first-proc-with-snapshot-id (sid ids procs)
;;   (if (endp ids)
;;       nil
;;     (let* ((i (first ids))
;;            (p (g i procs)))
;;       (if (memberp sid (snapshot-ids p))
;;           i
;;         (first-proc-with-snapshot-id sid
;;                                      (rest ids)
;;                                      procs)))))


;; (defthm memberp-of-first-proc-with-snapshot-id
;;   (implies
;;    (some-proc-has-snapshot-id-p sid ids procs)
;;    (memberp
;;     (first-proc-with-snapshot-id sid ids procs)
;;     ids)))

;; (defthm good-first-proc-with-snapshot-id-when-some-proc-has-snapshot-id-p
;;   (implies
;;    (and (some-proc-has-snapshot-id-p sid ids procs)
;;          (good-procs-p ids procs ids))
;;    (good-proc-p (g (first-proc-with-snapshot-id sid ids procs) procs) ids)))

;; (defthm first-proc-with-snapshot-id-has-sid
;;   (implies
;;    (some-proc-has-snapshot-id-p sid ids procs)
;;    (memberp
;;     sid
;;     (snapshot-ids
;;      (g (first-proc-with-snapshot-id sid ids procs)
;;         procs)))))


;; (defthm good-snapshot-id-p-when-some-proc-has-snapshot-id-p
;;   (implies
;;    (and
;;     (some-proc-has-snapshot-id-p sid ids procs)
;;     (good-procs-p ids procs ids))
;;    (good-snapshot-id-p sid ids))
;;   :hints
;;   (("Goal"
;;     :use
;;     ((:instance good-snapshot-id-p-when-memberp-snapshot-ids-of-good-proc
;;                 (p (g (first-proc-with-snapshot-id sid ids procs)
;;                       procs))
;;                 (sid sid)
;;                 (ids ids))

;;      (:instance good-first-proc-with-snapshot-id-when-some-proc-has-snapshot-id-p
;;                 (sid sid)
;;                 (ids ids)
;;                 (procs procs))

;;      (:instance first-proc-with-snapshot-id-has-sid
;;                 (sid sid)
;;                 (ids ids)
;;                 (procs procs))))))



;; ;end support: marker-sid-validity-from-system-knowledge


;; ;start support: first-marker-message-goodness-after-update
;; ;; Updating receiver i for the first marker only adds sid to i's snapshot-id
;; ;; list.  Therefore, any marker sid that was known somewhere before the update
;; ;; is still known somewhere afterward, so the marker message remains good under
;; ;; the updated process table.

;; (defthm memberp-snapshot-ids-of-g-after-update-proc-for-first-marker-msg
;;   (implies
;;    (memberp sid0
;;             (snapshot-ids (g k procs)))
;;    (memberp sid0
;;             (snapshot-ids
;;              (g k
;;                 (s i
;;                    (update-proc-for-first-marker-msg
;;                     (g i procs)
;;                     sid
;;                     j)
;;                    procs)))))
;;   :hints
;;   (("Goal"
;;     :cases ((equal k i)))))

;; (defthm good-msg-p-of-get-msg-from-channel-when-marker-after-first-marker-update
;;   (implies
;;    (and (equal (msg-type (get-msg-from-channel j i channels))
;;                :marker)
;;         (some-proc-has-snapshot-id-p
;;          (sid (get-msg-from-channel j i channels))
;;          ids
;;          procs))
;;    (good-msg-p
;;     (get-msg-from-channel j i channels)
;;     ids
;;     (s i
;;        (update-proc-for-first-marker-msg
;;         (g i procs)
;;         (sid (get-msg-from-channel j i channels))
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable get-msg-from-channel update-proc-for-first-marker-msg))))


;; ;end support: first-marker-message-goodness-after-update


;; ;start support: first-marker-updated-procs-compatible-with-channel-preservation
;; ;; The generic two-process channel-send theorem needs compatibility between the
;; ;; old procs and the updated procs.  For first-marker handling, outgoing
;; ;; neighbors are unchanged and snapshot ids are monotone: the receiver may gain
;; ;; sid, but no process loses any old snapshot id.

;; (defthm memberp-snapshot-ids-of-g-of-s-update-proc-for-first-marker-msg
;;   (implies
;;    (memberp sid0
;;             (g :snapshot-ids
;;                (g x procs)))
;;    (memberp sid0
;;             (g :snapshot-ids
;;                (g x
;;                   (s k
;;                      (update-proc-for-first-marker-msg
;;                       (g k procs)
;;                       sid
;;                       j)
;;                      procs)))))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm some-proc-has-snapshot-id-p-of-update-proc-for-first-marker-msg
;;   (implies
;;    (some-proc-has-snapshot-id-p sid0 ids procs)
;;    (some-proc-has-snapshot-id-p
;;     sid0
;;     ids
;;     (s k
;;        (update-proc-for-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (some-proc-has-snapshot-id-p sid0 ids procs)
;;     :in-theory
;;     (disable update-proc-for-first-marker-msg))))

;; (defthm nbrs-to-of-g-of-s-update-proc-for-first-marker-msg
;;   (equal
;;    (g :nbrs-to
;;       (g x
;;          (s k
;;             (update-proc-for-first-marker-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (g :nbrs-to
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm same-nbrs-to-p-of-update-proc-for-first-marker-msg
;;   (same-nbrs-to-p
;;    srcs
;;    procs
;;    (s k
;;       (update-proc-for-first-marker-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-marker-msg))))

;; (defthm snapshot-ids-of-g-of-s-update-proc-for-first-marker-msg
;;   (equal
;;    (g :snapshot-ids
;;       (g x
;;          (s k
;;             (update-proc-for-first-marker-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (if (equal x k)
;;        (add-snapshot-id sid
;;                         (g :snapshot-ids
;;                            (g k procs)))
;;      (g :snapshot-ids
;;         (g x procs))))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm subset-snapshot-ids-of-g-of-s-update-proc-for-first-marker-msg
;;   (subset
;;    (g :snapshot-ids
;;       (g x procs))
;;    (g :snapshot-ids
;;       (g x
;;          (s k
;;             (update-proc-for-first-marker-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs))))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm snapshot-ids-subset-procs-p-of-update-proc-for-first-marker-msg
;;   (snapshot-ids-subset-procs-p
;;    ids
;;    procs
;;    (s k
;;       (update-proc-for-first-marker-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-marker-msg))))

;; ;; NOTE: Duplicate of the previous theorem in the original file.  Keep only one
;; ;; copy if ACL2 does not accept the second as redundant.
;; (defthm snapshot-ids-subset-procs-p-of-update-proc-for-first-marker-msg
;;   (snapshot-ids-subset-procs-p
;;    ids
;;    procs
;;    (s k
;;       (update-proc-for-first-marker-msg
;;        (g k procs)
;;        sid
;;        j)
;;       procs))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-first-marker-msg))))


;; ;end support: first-marker-updated-procs-compatible-with-channel-preservation


;; ;start target: good-state-p-of-handle-first-marker-msg
;; ;; Main target theorem for the first marker-message case.
;; ;;
;; ;; handle-first-marker-msg does four important things:
;; ;;   1. removes the consumed marker from channel j -> i;
;; ;;   2. creates a new snapshot entry at receiver i for sid;
;; ;;   3. records i's local state and waits for markers from the other incoming
;; ;;      neighbors;
;; ;;   4. forwards the marker to i's outgoing neighbors.
;; ;;
;; ;; The proof combines receiver-process preservation, removal of the consumed
;; ;; marker, marker-message goodness under the updated procs, and the generic
;; ;; outgoing-send preservation theorem.

;; (defthm good-state-p-of-handle-first-marker-msg
;;   (implies
;;    (and
;;     (good-state-p st)

;;     ;; valid receiver and sender
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))

;;     ;; msg is the head of channel j -> i
;;     (equal msg
;;            (get-msg-from-channel j i (channels st)))

;;     ;; marker-message case
;;     (equal (msg-type msg) :marker)

;;     ;; first-marker case: receiver i does not yet know this sid
;;     (not (memberp (sid msg)
;;                   (snapshot-ids (g i (procs st)))))

;;     ;; the marker sid is already known somewhere in the system
;;     (some-proc-has-snapshot-id-p
;;      (sid msg)
;;      (proc-ids st)
;;      (procs st)))
;;    (good-state-p
;;     (handle-first-marker-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-proc-p
;;              update-proc-for-first-marker-msg
;;              get-msg-from-channel
;;              remove-message-from-channel
;;              send-msg-all-outgoing-channels
;;              install-snapshot-entry
;;              make-snapshot-entry))))

;; ;end target: good-state-p-of-handle-first-marker-msg


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Non-first marker-message preservation
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; This section handles the case where receiver i already has a snapshot entry
;; ;; for the marker sid.  The handler removes j from that snapshot entry's
;; ;; waiting-marker list.  If no markers remain, the snapshot entry is marked
;; ;; :done; otherwise the snapshot entry stays open.

;; ;start support: non-first-marker-process-field-preservation
;; ;; Field-level facts for update-proc-for-non-first-marker-msg.  The non-first
;; ;; marker update changes only the snapshot entry for sid; it does not change
;; ;; neighbors, recovery waiting state, counter, status, or snapshot-id list.

;; (defthm nbrs-from-of-update-proc-for-non-first-marker-msg
;;   (equal (g :nbrs-from
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :nbrs-from p)))

;; (defthm waiting-recovery-from-of-update-proc-for-non-first-marker-msg
;;   (equal (g :waiting-recovery-from
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :waiting-recovery-from p)))

;; (defthm nbrs-to-of-update-proc-for-non-first-marker-msg
;;   (equal (g :nbrs-to
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :nbrs-to p)))

;; (defthm counter-of-update-proc-for-non-first-marker-msg
;;   (equal (g :counter
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :counter p)))

;; (defthm snapshot-ids-of-update-proc-for-non-first-marker-msg
;;   (equal (g :snapshot-ids
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :snapshot-ids p)))

;; (defthm good-snapshot-ids-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (good-snapshot-ids-p (g :snapshot-ids p) ids)
;;    (good-snapshot-ids-p
;;     (g :snapshot-ids
;;        (update-proc-for-non-first-marker-msg p sid j))
;;     ids)))


;; ;end support: non-first-marker-process-field-preservation


;; ;start support: non-first-marker-snapshot-entry-preservation
;; ;; Updating an existing marker snapshot either closes the entry by setting
;; ;; status to :done and waiting-marker-from to nil, or removes sender j from the
;; ;; still-waiting marker list.  Both cases preserve good-snapshots-p.

;; (defthm good-snapshots-p-of-set-sid-done-waiting-nil
;;   (implies
;;    (and
;;     (good-snapshots-p snapshot-ids p nbrs-from ids)
;;     (memberp sid snapshot-ids))
;;    (good-snapshots-p
;;     snapshot-ids
;;     (s :snapshots
;;        (s sid
;;           (s :status
;;              :done
;;              (s :waiting-marker-from
;;                 nil
;;                 (g sid (g :snapshots p))))
;;           (g :snapshots p))
;;        p)
;;     nbrs-from
;;     ids))
;;   :hints
;;   (("Goal"
;;     :induct (good-snapshots-p snapshot-ids p nbrs-from ids))
;;    ("Subgoal *1/2"
;;     :cases ((equal sid (car snapshot-ids))))))

;; (defthm good-snapshots-p-of-set-sid-waiting-marker-from-remove
;;   (implies
;;    (and
;;     (good-snapshots-p snapshot-ids p nbrs-from ids)
;;     (memberp sid snapshot-ids))
;;    (good-snapshots-p
;;     snapshot-ids
;;     (s :snapshots
;;        (s sid
;;           (s :status
;;              (g :status (g sid (g :snapshots p)))
;;              (s :waiting-marker-from
;;                 (remove-from-list
;;                  (g :waiting-marker-from
;;                     (g sid (g :snapshots p)))
;;                  j)
;;                 (g sid (g :snapshots p))))
;;           (g :snapshots p))
;;        p)
;;     nbrs-from
;;     ids))
;;   :hints
;;   (("Goal"
;;     :induct (good-snapshots-p snapshot-ids p nbrs-from ids))
;;    ("Subgoal *1/2"
;;     :cases ((equal sid (car snapshot-ids))))))

;; (defthm good-snapshots-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (and
;;     (good-snapshots-p snapshot-ids
;;                       p
;;                       nbrs-from
;;                       ids)
;;     (memberp sid snapshot-ids))
;;    (good-snapshots-p
;;     snapshot-ids
;;     (update-proc-for-non-first-marker-msg p sid j)
;;     nbrs-from
;;     ids)))


;; ;end support: non-first-marker-snapshot-entry-preservation


;; ;start support: non-first-marker-process-wellformedness
;; ;; Lift the non-first marker update to good-proc-p and good-procs-p.  The only
;; ;; extra condition is that receiver i already has sid in its snapshot-id list.

;; (defthm proc-status-of-update-proc-for-non-first-marker-msg
;;   (equal (g :proc-status
;;             (update-proc-for-non-first-marker-msg p sid j))
;;          (g :proc-status p)))

;; (defthm good-proc-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (and
;;     (good-proc-p p ids)

;;     ;; Non-first marker case:
;;     ;; this process already has an entry for sid.
;;     (memberp sid (snapshot-ids p)))
;;    (good-proc-p
;;     (update-proc-for-non-first-marker-msg p sid j)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg
;;              set-snapshot-entry
;;              good-snapshot-entry-p
;;              good-snapshots-p))))


;; (defthm good-procs-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (and
;;     (good-procs-p ids procs all-ids)
;;     (memberp i ids)

;;     ;; sid already exists at process i
;;     (memberp sid
;;              (snapshot-ids (g i procs))))
;;    (good-procs-p
;;     ids
;;     (s i
;;        (update-proc-for-non-first-marker-msg
;;         (g i procs)
;;         sid
;;         j)
;;        procs)
;;     all-ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable
;;              good-procs-p
;;              update-proc-for-non-first-marker-msg
;;             ))))


;; ;end support: non-first-marker-process-wellformedness


;; ;start support: non-first-marker-updated-procs-field-compatibility
;; ;; Facts about reading fields from the process table after updating one process.
;; ;; These are needed because channel well-formedness depends on process metadata,
;; ;; especially outgoing neighbors and known snapshot ids.

;; (defthm nbrs-to-of-g-of-s-update-proc-for-non-first-marker-msg
;;   (equal
;;    (g :nbrs-to
;;       (g x
;;          (s k
;;             (update-proc-for-non-first-marker-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (g :nbrs-to
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm snapshot-ids-of-g-of-s-update-proc-for-non-first-marker-msg
;;   (equal
;;    (g :snapshot-ids
;;       (g x
;;          (s k
;;             (update-proc-for-non-first-marker-msg
;;              (g k procs)
;;              sid
;;              j)
;;             procs)))
;;    (g :snapshot-ids
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k))
;;    )))

;; ;end support: non-first-marker-updated-procs-field-compatibility


;; ;start support: non-first-marker-message-goodness-preservation
;; ;; Updating a process for a non-first marker message does not change any
;; ;; process's snapshot-id list.  Therefore, any message that was good before the
;; ;; update is still good after the update.

;; (defthm some-proc-has-snapshot-id-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (some-proc-has-snapshot-id-p sid0 ids procs)
;;    (some-proc-has-snapshot-id-p
;;     sid0
;;     ids
;;     (s k
;;        (update-proc-for-non-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg))))

;; (defthm good-msg-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (good-msg-p msg ids procs)
;;    (good-msg-p
;;     msg
;;     ids
;;     (s k
;;        (update-proc-for-non-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg))))

;; (defthm good-msg-list-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (good-msg-list-p msgs ids procs)
;;    (good-msg-list-p
;;     msgs
;;     ids
;;     (s k
;;        (update-proc-for-non-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg))))

;; ;end support: non-first-marker-message-goodness-preservation


;; ;start support: non-first-marker-channel-table-preservation
;; ;; Lift message-goodness preservation to channel rows and then to the whole
;; ;; channel table.  The channel contents are not changed by these lemmas; only
;; ;; the process table used to interpret channel/message well-formedness changes.

;; (defthm good-channel-row-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (good-channel-row-p src dsts channels ids procs)
;;    (good-channel-row-p
;;     src
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-non-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channel-row-p src dsts channels ids procs)
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg))))

;; (defthm good-channels-p-of-update-proc-for-non-first-marker-msg
;;   (implies
;;    (good-channels-p srcs dsts channels ids procs)
;;    (good-channels-p
;;     srcs
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-non-first-marker-msg
;;         (g k procs)
;;         sid
;;         j)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channels-p srcs dsts channels ids procs)
;;     :in-theory
;;     (disable update-proc-for-non-first-marker-msg))))

;; ;end support: non-first-marker-channel-table-preservation


;; ;start target: good-state-p-of-handle-non-first-marker-msg
;; ;; Target theorem for the non-first marker-message handler.
;; ;;
;; ;; Proof idea:
;; ;; 1. remove the consumed marker from channel j -> i;
;; ;; 2. update only the existing snapshot entry for sid at receiver i;
;; ;; 3. show the process table is still good;
;; ;; 4. show existing channel/message well-formedness is not invalidated because
;; ;;    neighbors and snapshot-id lists are unchanged.

;; (defthm good-state-p-of-handle-non-first-marker-msg
;;   (implies
;;    (and
;;     (good-state-p st)

;;     ;; Valid receiver and sender.
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))

;;     ;; msg is the first message on channel j -> i.
;;     (equal msg
;;            (get-msg-from-channel j i (channels st)))

;;     ;; This is really a marker message.
;;     (equal (msg-type msg) :marker)

;;     ;; Non-first marker case:
;;     ;; receiver i already knows this snapshot id.
;;     (memberp (sid msg)
;;              (snapshot-ids (g i (procs st)))))
;;    (good-state-p
;;     (handle-non-first-marker-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-proc-p
;;              get-msg-from-channel
;;              remove-message-from-channel
;;              update-proc-for-non-first-marker-msg
;;              set-snapshot-entry))))

;; ;end target: good-state-p-of-handle-non-first-marker-msg


;; ;start target: good-state-p-of-handle-marker-msg
;; ;; Dispatcher theorem for marker messages.
;; ;;
;; ;; The handler splits on whether receiver i already knows sid:
;; ;;   1. If not, this is the first-marker case, so the marker sid must be known
;; ;;      somewhere in the system and structurally valid.
;; ;;   2. If yes, this is the non-first marker case, so only the existing
;; ;;      snapshot entry is updated.

;; (defthm good-state-p-of-handle-marker-msg
;;   (implies
;;    (and
;;     (good-state-p st)

;;     ;; Valid receiver and sender.
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))
;;     ;; msg is the head of channel j -> i.
;;     (equal msg
;;            (get-msg-from-channel j i (channels st)))
;;     ;; This is really a marker message.
;;     (equal (msg-type msg) :marker)
;;      (some-proc-has-snapshot-id-p
;;       (sid msg)
;;       (proc-ids st)
;;       (procs st)))
;;    (good-state-p
;;     (handle-marker-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :cases ((memberp (sid msg)
;;                      (snapshot-ids (g i (procs st)))))
;;     :in-theory
;;     (disable good-state-p
;;              handle-first-marker-msg
;;              handle-non-first-marker-msg))))

;; ;end target: good-state-p-of-handle-marker-msg


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Normal-message preservation
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Normal-message handling either ignores the message during recovery waiting,
;; ;; or consumes it and records it into any open channel snapshots.

;; ;start target: good-state-p-of-ignore-normal-msg
;; ;; If receiver i is recovering and still waiting for j, then a normal message
;; ;; from j is ignored by removing it from the channel.  Since no process fields
;; ;; are changed and removing a channel head preserves good-channels-p, the global
;; ;; invariant is preserved.

;; (defthm good-state-p-of-ignore-normal-msg
;;   (implies
;;    (good-state-p st)
;;    (good-state-p
;;     (ignore-normal-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable remove-message-from-channel
;;              good-proc-p))))

;; ;end target: good-state-p-of-ignore-normal-msg


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Normal-message-core preservation
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; The core normal-message handler consumes a normal/application message, updates
;; ;; receiver i's local state, and records the message in each open snapshot whose
;; ;; waiting-marker-from still contains sender j.

;; ;start support: normal-msg-core-field-preservation
;; ;; update-proc-for-normal-msg-core does not change neighbors, status, recovery
;; ;; waiting state, counter, or snapshot-id list.  Only local state and the
;; ;; snapshot table may change.

;; (defthm nbrs-from-of-update-proc-for-normal-msg-core
;;   (equal (g :nbrs-from
;;             (update-proc-for-normal-msg-core p j msg))
;;          (g :nbrs-from p)))

;; (defthm nbrs-to-of-update-proc-for-normal-msg-core
;;   (equal (g :nbrs-to
;;             (update-proc-for-normal-msg-core p j msg))
;;          (g :nbrs-to p)))

;; (defthm proc-status-of-update-proc-for-normal-msg-core
;;   (equal (g :proc-status
;;             (update-proc-for-normal-msg-core p j msg))
;;          (g :proc-status p)))

;; (defthm waiting-recovery-from-of-update-proc-for-normal-msg-core
;;   (equal (g :waiting-recovery-from
;;             (update-proc-for-normal-msg-core p j msg))
;;          (g :waiting-recovery-from p)))

;; (defthm counter-of-update-proc-for-normal-msg-core
;;   (equal (g :counter
;;             (update-proc-for-normal-msg-core p j msg))
;; (g :counter p)))

;; (defthm snapshot-ids-of-update-proc-for-normal-msg-core
;;   (equal (g :snapshot-ids
;;             (update-proc-for-normal-msg-core p j msg))
;;          (g :snapshot-ids p)))

;; ;end support: normal-msg-core-field-preservation


;; ;start support: recording-normal-msg-in-open-snapshots
;; ;; Channel snapshots are allowed to store only normal messages.  These lemmas
;; ;; show that appending a normal message to one channel snapshot, and recursively
;; ;; recording it into all open snapshot entries, preserves snapshot well-formedness.

;; (defthm good-normal-msg-list-p-of-append-normal-msg
;;   (implies
;;    (and (good-normal-msg-list-p xs)
;;         (good-normal-msg-p msg))
;;    (good-normal-msg-list-p
;;     (append xs (list msg)))))



;; (defthm g-of-record-msg-in-snapshots-when-not-member
;;   (implies
;;    (not (memberp sid snapshot-ids))
;;    (equal
;;     (g sid
;;        (record-msg-in-snapshots snapshots
;;                                 snapshot-ids
;;                                 j
;;                                 msg))
;;     (g sid snapshots))))

;; (defthm good-snapshot-entry-p-of-g-record-msg-in-snapshots-when-not-member
;;   (implies
;;    (and
;;     (not (memberp sid snapshot-ids))
;;     (good-snapshot-entry-p (g sid snapshots)
;;                            nbrs-from))
;;    (good-snapshot-entry-p
;;     (g sid
;;        (record-msg-in-snapshots snapshots
;;                                 snapshot-ids
;;                                 j
;;                                 msg))
;;     nbrs-from)))

;; (defthm memberp-when-subset
;;   (implies
;;    (and (subset xs ys)
;;         (memberp a xs))
;;    (memberp a ys)))

;; (defthm good-channel-snapshot-record-p-of-s-append-normal-msg
;;   (implies
;;    (and
;;     (good-channel-snapshot-record-p nbrs-from cs)
;;     (memberp j nbrs-from)
;;     (equal (msg-type msg) :normal))
;;    (good-channel-snapshot-record-p
;;     nbrs-from
;;     (s j
;;        (append (g j cs)
;;                (list msg))
;;        cs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channel-snapshot-record-p nbrs-from cs))
;;    ("Subgoal *1/2"
;;     :cases ((equal j (car nbrs-from))))))


;; (defthm good-snapshot-entry-p-of-s-channel-snapshots-append-normal-msg
;;   (implies
;;    (and
;;     (good-snapshot-entry-p entry nbrs-from)
;;     (memberp j (snapshot-waiting-marker-from entry))
;;     (equal (msg-type msg) :normal))
;;    (good-snapshot-entry-p
;;     (s :channel-snapshots
;;        (s j
;;           (append (g j (snapshot-channel-snapshots entry))
;;                   (list msg))
;;           (snapshot-channel-snapshots entry))
;;        entry)
;;     nbrs-from)))


;; (defthm good-snapshots-p-of-record-msg-in-snapshots
;;   (implies
;;    (and
;;     (good-snapshots-p snapshot-ids p nbrs-from ids)
;;     (uniquep snapshot-ids)
;;     (equal (msg-type msg) :normal))
;;    (good-snapshots-p
;;     snapshot-ids
;;     (s :snapshots
;;        (record-msg-in-snapshots
;;         (snapshots p)
;;         snapshot-ids
;;         j
;;         msg)
;;        p)
;;     nbrs-from
;;     ids))
;;   :hints
;;   (("Goal"
;;     :induct (record-msg-in-snapshots
;;              (snapshots p)
;;              snapshot-ids
;;              j
;;              msg)
;;     :in-theory
;;     (disable good-snapshot-entry-p))))


;; (defthm good-snapshots-p-of-set-snapshots-after-set-local-state
;;   (implies
;;    (good-snapshots-p snapshot-ids
;;                      (s :snapshots snaps p)
;;                      nbrs-from
;;                      ids)
;;    (good-snapshots-p snapshot-ids
;;                      (s :snapshots snaps
;;                         (s :local-state val p))
;;                      nbrs-from
;;                      ids))
;;   :hints
;;   (("Goal"
;;     :induct (good-snapshots-p snapshot-ids p nbrs-from ids))))


;; (defthm good-snapshots-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (and
;;     (good-snapshots-p (snapshot-ids p)
;;                       p
;;                       (nbrs-from p)
;;                       ids)
;;     (equal (msg-type msg) :normal)
;;     (uniquep (snapshot-ids p)))
;;    (good-snapshots-p
;;     (snapshot-ids p)
;;     (update-proc-for-normal-msg-core p j msg)
;;     (nbrs-from p)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable record-msg-in-snapshots))))
;; ;end support: recording-normal-msg-in-open-snapshots


;; ;start target: good-proc-p-of-update-proc-for-normal-msg-core


;; (defthm good-proc-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (and
;;     (good-proc-p p ids)
;;     ;; handle-normal-msg-core only records normal/application messages
;;     ;; into open channel snapshots.
;;     (equal (msg-type msg) :normal))
;;    (good-proc-p
;;     (update-proc-for-normal-msg-core p j msg)
;;     ids))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core
;;              record-msg-in-snapshots
;;              good-snapshots-p
;;              good-snapshot-entry-p))))

;; ;end target: good-proc-p-of-update-proc-for-normal-msg-core

;; ;start support: normal-msg-core-process-table-lift
;; ;; Lift the receiver-process preservation theorem to the whole process table.

;; (defthm good-procs-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (and
;;     (good-procs-p ids procs all-ids)
;;     (memberp i ids)
;;     (equal (msg-type msg) :normal))
;;    (good-procs-p
;;     ids
;;     (s i
;;        (update-proc-for-normal-msg-core
;;         (g i procs)
;;         j
;;         msg)
;;        procs)
;;     all-ids))
;;    :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-proc-p
;;              update-proc-for-normal-msg-core
;;              record-msg-in-snapshots))))



;; ;end support: normal-msg-core-process-table-lift


;; ;start support: normal-msg-core-channel-compatibility
;; ;; The normal-message core update does not change outgoing neighbors or
;; ;; snapshot-id membership.  Therefore, messages/channels that were good under
;; ;; the old process table remain good under the updated process table.

;; (defthm nbrs-to-of-g-of-s-update-proc-for-normal-msg-core
;;   (equal
;;    (g :nbrs-to
;;       (g x
;;          (s k
;;             (update-proc-for-normal-msg-core
;;              (g k procs)
;;              j
;;              msg)
;;             procs)))
;;    (g :nbrs-to
;;       (g x procs)))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))


;; (defthm memberp-snapshot-ids-of-update-proc-for-normal-msg-core
;;   (equal
;;    (memberp sid0
;;             (g :snapshot-ids
;;                (update-proc-for-normal-msg-core p j msg)))
;;    (memberp sid0
;;             (g :snapshot-ids p))))

;; (defthm memberp-snapshot-ids-of-g-of-s-update-proc-for-normal-msg-core
;;   (equal
;;    (memberp sid0
;;             (g :snapshot-ids
;;                (g x
;;                   (s k
;;                      (update-proc-for-normal-msg-core
;;                       (g k procs)
;;                       j
;;                       msg)
;;                      procs))))
;;    (memberp sid0
;;             (g :snapshot-ids
;;                (g x procs))))
;;   :hints
;;   (("Goal"
;;     :cases ((equal x k)))))

;; (defthm some-proc-has-snapshot-id-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (some-proc-has-snapshot-id-p sid0 ids procs)
;;    (some-proc-has-snapshot-id-p
;;     sid0
;;     ids
;;     (s k
;;        (update-proc-for-normal-msg-core
;;         (g k procs)
;;         j
;;         msg)
;;        procs)))
;;     :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core))))

;; (defthm good-msg-list-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (good-msg-list-p msgs ids procs)
;;    (good-msg-list-p
;;     msgs
;;     ids
;;     (s k
;;        (update-proc-for-normal-msg-core
;;         (g k procs)
;;         j
;;         rcv-msg)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-msg-list-p msgs ids procs)
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core))))

;; ;end support: normal-msg-core-channel-compatibility


;; ;start support: normal-msg-core-channel-table-preservation
;; ;; Lift preservation from one channel to channel rows and then to the whole
;; ;; channel table.  Channel contents are not changed here; only the process table
;; ;; used to interpret channel/message well-formedness changes.

;; (defthm good-channel-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (good-channel-p src dst channels ids procs)
;;    (good-channel-p
;;     src
;;     dst
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-normal-msg-core
;;         (g k procs)
;;         j
;;         msg)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core))))


;; (defthm good-channel-row-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (good-channel-row-p src dsts channels ids procs)
;;    (good-channel-row-p
;;     src
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-normal-msg-core
;;         (g k procs)
;;         j
;;         msg)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channel-row-p src dsts channels ids procs)
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core))))

;; (defthm good-channels-p-of-update-proc-for-normal-msg-core
;;   (implies
;;    (good-channels-p srcs dsts channels ids procs)
;;    (good-channels-p
;;     srcs
;;     dsts
;;     channels
;;     ids
;;     (s k
;;        (update-proc-for-normal-msg-core
;;         (g k procs)
;;         j
;;         msg)
;;        procs)))
;;   :hints
;;   (("Goal"
;;     :induct (good-channels-p srcs dsts channels ids procs)
;;     :in-theory
;;     (disable update-proc-for-normal-msg-core))))

;; ;end support: normal-msg-core-channel-table-preservation


;; ;start target: good-state-p-of-handle-normal-msg-core
;; ;; Main target theorem for the core normal-message case.
;; ;;
;; ;; The handler consumes the channel head, updates receiver i's local state, and
;; ;; records the normal message in relevant open snapshot channel logs.  The proof
;; ;; combines channel-head removal with the process-table and channel-table
;; ;; preservation lemmas above.

;; (defthm good-state-p-of-handle-normal-msg-core
;;   (implies
;;    (and
;;     (good-state-p st)

;;     ;; Valid receiver and sender.
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))

;;     ;; msg is the first message on channel j -> i.
;;     (equal msg
;;            (get-msg-from-channel j i (channels st)))

;;     ;; This is really a normal/application message.
;;     (equal (msg-type msg) :normal))
;;    (good-state-p
;;     (handle-normal-msg-core st i j msg)))
;;   :hints
;;   (("Goal"
;;     :in-theory
;;     (disable good-proc-p
;;              get-msg-from-channel
;;              remove-message-from-channel
;;              update-proc-for-normal-msg-core
;;              record-msg-in-snapshots))))

;; ;end target: good-state-p-of-handle-normal-msg-core


;; ;start target: good-state-p-of-handle-normal-msg
;; ;; Dispatcher theorem for normal messages.
;; ;;
;; ;; If i is recovering and still waiting for j, the message is ignored.
;; ;; Otherwise, handle-normal-msg-core consumes and records the normal message.

;; (defthm good-state-p-of-handle-normal-msg
;;   (implies
;;    (and
;;     (good-state-p st)
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))
;;     (equal msg
;;            (get-msg-from-channel j i (channels st)))
;;     (equal (msg-type msg) :normal))
;;    (good-state-p
;;     (handle-normal-msg st i j msg)))
;;   :hints
;;   (("Goal"
;;     :cases ((and (equal (proc-status (g i (procs st))) :recovering)
;;                  (memberp j
;;                           (waiting-recovery-from
;;                            (g i (procs st))))))
;;     :in-theory
;;     (disable good-state-p
;;              good-proc-p
;;              get-msg-from-channel
;;              handle-normal-msg-core
;;              ignore-normal-msg
;;              update-proc-for-normal-msg-core
;;              remove-message-from-channel
;;              record-msg-in-snapshots))))

;; ;end target: good-state-p-of-handle-normal-msg


;; ;start archive: unused-message-goodness-helper
;; ;; This helper is currently commented out because the active marker/recovery
;; ;; dispatcher proofs use more targeted side conditions.  It may be useful later
;; ;; when strengthening channel-head invariants.

;; ;; (defthm some-proc-has-snapshot-id-p-when-memberp-sid-of-proc
;; ;;   (implies
;; ;;    (and
;; ;;     (memberp i ids)
;; ;;     (memberp sid
;; ;;              (snapshot-ids (g i procs))))
;; ;;    (some-proc-has-snapshot-id-p sid ids procs))
;; ;;   :hints
;; ;;   (("Goal"
;; ;;     :induct (some-proc-has-snapshot-id-p sid ids procs))
;; ;;    ("Subgoal *1/2"
;; ;;     :cases ((equal i (car ids))))))

;; ;end archive: unused-message-goodness-helper


;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; Receive-step preservation
;; ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; ;; step-rcv dispatches on the type of the head message on channel j -> i.
;; ;; The three dispatcher theorems above handle :normal, :marker, and :recovery.

;; ;start target: good-state-p-of-step-rcv
;; ;; Main receive-step theorem.
;; ;;
;; ;; The two implication hypotheses are the still-needed channel-head invariants:
;; ;;   - a marker at the head of j -> i carries a sid known somewhere;
;; ;;   - a recovery at the head of j -> i carries a sid known by receiver i.
;; ;; Once those invariants are proved from good-state-p or a strengthened state
;; ;; predicate, these side conditions can be removed from this theorem.

;; (defthm good-state-p-of-step-rcv
;;   (implies
;;    (and
;;     (good-state-p st)
;;     (memberp i (proc-ids st))
;;     (memberp j (proc-ids st))
;;     (memberp j (nbrs-from (g i (procs st))))
;;     ;; The channel head is one of the handled message types.
;;     (or (equal (msg-type (get-msg-from-channel j i (channels st))) :normal)
;;         (equal (msg-type (get-msg-from-channel j i (channels st))) :marker)
;;         (equal (msg-type (get-msg-from-channel j i (channels st))) :recovery))
;;     ;; Marker-side condition needed by handle-marker-msg:
;;     ;; if this is a marker at receiver i, then the sid is known
;;     ;; somewhere in the system.
;;     (implies
;;      (equal (msg-type (get-msg-from-channel j i (channels st))) :marker)
;;      (some-proc-has-snapshot-id-p
;;       (sid (get-msg-from-channel j i (channels st)))
;;       (proc-ids st)
;;       (procs st)))
;;     ;; Recovery-side condition needed by handle-recovery-msg:
;;     ;; then the recovery sid must already be known by receiver i.
;;     (implies
;;      (equal (msg-type (get-msg-from-channel j i (channels st))) :recovery)
;;      (memberp
;;       (sid (get-msg-from-channel j i (channels st)))
;;       (snapshot-ids (g i (procs st))))))
;;    (good-state-p
;;     (step-rcv st i j)))
;;   :hints
;;   (("Goal"
;;     :cases
;;     ((equal (msg-type (get-msg-from-channel j i (channels st))) :normal)
;;      (equal (msg-type (get-msg-from-channel j i (channels st))) :marker)
;;      (equal (msg-type (get-msg-from-channel j i (channels st))) :recovery))
;;     :in-theory
;;     (disable good-state-p
;;              good-proc-p
;;              get-msg-from-channel
;; 	     some-proc-has-snapshot-id-p
;;              handle-normal-msg
;;              handle-marker-msg
;;              handle-recovery-msg))))

;; ;end target: good-state-p-of-step-rcv
