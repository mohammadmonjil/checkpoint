(in-package "ACL2")
(include "model")
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; A complete, isolated checkpoint segment
;;
;; Assumes model(2).lisp and cl_checkpoint_scan_model2.lisp are already
;; included.
;;
;; The segment:
;;   1. is nonempty;
;;   2. starts with exactly one :start-checkpoint input;
;;   3. contains only :nop, :normal, and :receive inputs afterward;
;;   4. is legal from the supplied start state;
;;   5. does not consume any recovery message through a :receive input;
;;   6. first reaches checkpoint completion after its last input.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; Inputs allowed after the initial :start-checkpoint.
;; This rules out another checkpoint start, an explicit recovery start,
;; a crash, and any unknown input type.
(defun cl-checkpoint-body-input-p (input)
  (let ((tp (ttype input)))
    (or (equal tp :nop)
        (equal tp :normal)
        (equal tp :receive))))

(defun cl-checkpoint-body-inputs-p (inputs)
  (if (endp inputs)
      t
    (and (cl-checkpoint-body-input-p (first inputs))
         (cl-checkpoint-body-inputs-p (rest inputs)))))

;; A :receive input is generic in this model: its actual behavior depends on
;; the message currently at the channel head.  This predicate recognizes a
;; receive that would consume a recovery message in the current state.
(defun cl-recovery-receive-input-p (input st)
  (and (equal (ttype input) :receive)
       (let ((msg (cl-current-receive-msg input st)))
         (and msg
              (equal (msg-type msg) :recovery)))))

;; State-dependent scan ensuring that no receive in the segment consumes a
;; recovery message.  This is stronger than merely excluding :recover inputs.
(defun cl-no-recovery-receive-sequencep (st inputs)
  (if (endp inputs)
      t
    (let ((input (first inputs)))
      (and (not (cl-recovery-receive-input-p input st))
           (cl-no-recovery-receive-sequencep
            (system-step st input)
            (rest inputs))))))

;; Convenience wrappers around the checkpoint scan.
(defun cl-checkpoint-segment-result (st input-seg)
  (scan-checkpoint-segment st input-seg))

(defun cl-checkpoint-segment-meta (st input-seg)
  (cl-scan-result-meta
   (cl-checkpoint-segment-result st input-seg)))

(defun cl-checkpoint-segment-end-state (st input-seg)
  (cl-scan-result-state
   (cl-checkpoint-segment-result st input-seg)))

(defun cl-checkpoint-segment-sid (st input-seg)
  (clm-sid
   (cl-checkpoint-segment-meta st input-seg)))

(defun cl-checkpoint-segment-before-cut-inputs (st input-seg)
  (clm-before-cut-inputs
   (cl-checkpoint-segment-meta st input-seg)))

(defun cl-checkpoint-segment-after-cut-inputs (st input-seg)
  (clm-after-cut-inputs
   (cl-checkpoint-segment-meta st input-seg)))

(defun cl-checkpoint-segment-after-cut-msgs (st input-seg)
  (clm-after-cut-msgs
   (cl-checkpoint-segment-meta st input-seg)))

;; Main segment predicate.
;;
;; The scan's completion index is end-exclusive.  Therefore, requiring the
;; index to equal (len input-seg) means that checkpoint completion is first
;; observed only after the final input has been processed.  If completion
;; occurred earlier, the scan would stop with a smaller index.
(defun cl-checkpoint-complete-segment-p (st input-seg)
  (and
   ;; The segment has a first input.
   (consp input-seg)

   ;; The segment begins outside any older checkpoint/recovery phase.
   ;; This makes the target checkpoint isolated.
   (not (any-snapshot-checkpointing-p st))
   (not (any-process-recovering-p st))

   ;; The first input initiates the target checkpoint.
   (equal (ttype (first input-seg)) :start-checkpoint)

   ;; No later checkpoint start, explicit recovery start, or crash.
   (cl-checkpoint-body-inputs-p (rest input-seg))

   ;; Every input is legal in the state in which it is executed.
   (legal-input-sequencep st input-seg)

   ;; No generic receive consumes a recovery message.
   (cl-no-recovery-receive-sequencep st input-seg)

   ;; The target checkpoint really completes in this segment.
   (cl-scan-result-completep
    (cl-checkpoint-segment-result st input-seg))

   ;; The final input is the one that completes checkpoint collection.
   (equal
    (cl-scan-result-index
     (cl-checkpoint-segment-result st input-seg))
    (len input-seg))))
