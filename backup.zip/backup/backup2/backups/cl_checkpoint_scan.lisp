(in-package "ACL2")
(include-book "model")

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Chandy-Lamport scan from checkpoint start through checkpoint completion
;;
;; This file is written for model(2).lisp, where neighbor lists are stored
;; inside each process record:
;;
;;   (nbrs-from (g i (procs st)))
;;
;; The scan collects:
;;   :before-cut-inputs  -- ordinary inputs executed before their process cut
;;   :after-cut-inputs   -- ordinary inputs executed after their process cut
;;   :after-cut-msgs     -- actual normal messages received on j -> i after
;;                          i's cut and before i receives j's marker
;;
;; Marker receives and :start-checkpoint are protocol inputs.  They update the
;; scan metadata, but they are not inserted into either ordinary-input list.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;; ------------------------------------------------------------------
;; Metadata accessors
;; ------------------------------------------------------------------

(defmacro clm-sid (m)
  `(g :sid ,m))

(defmacro clm-proc-ids (m)
  `(g :proc-ids ,m))

(defmacro clm-cut-not-taken (m)
  `(g :cut-not-taken ,m))

(defmacro clm-waiting-marker-from (m)
  `(g :waiting-marker-from ,m))

(defmacro clm-before-cut-inputs (m)
  `(g :before-cut-inputs ,m))

(defmacro clm-after-cut-inputs (m)
  `(g :after-cut-inputs ,m))

(defmacro clm-after-cut-msgs (m)
  `(g :after-cut-msgs ,m))

(defun clm-cut-not-taken-p (i m)
  (memberp i (clm-cut-not-taken m)))

(defun clm-waiting-marker-for (i m)
  (g i (clm-waiting-marker-from m)))

(defun clm-set-waiting-marker-for (i waiting m)
  (s :waiting-marker-from
     (s i waiting (clm-waiting-marker-from m))
     m))

(defun clm-remove-cut-not-taken (i m)
  (s :cut-not-taken
     (remove-from-list (clm-cut-not-taken m) i)
     m))

(defun clm-add-before-cut-input (input m)
  (s :before-cut-inputs
     (snoc (clm-before-cut-inputs m) input)
     m))

(defun clm-add-after-cut-input (input m)
  (s :after-cut-inputs
     (snoc (clm-after-cut-inputs m) input)
     m))

(defun clm-after-cut-msg-get (i j m)
  (g j (g i (clm-after-cut-msgs m))))

(defun clm-after-cut-msg-append (i j msg m)
  (let* ((all-msgs (clm-after-cut-msgs m))
         (msgs-i   (g i all-msgs))
         (old      (g j msgs-i))
         (msgs-i   (s j (snoc old msg) msgs-i))
         (all-msgs (s i msgs-i all-msgs)))
    (s :after-cut-msgs all-msgs m)))

;; ------------------------------------------------------------------
;; Metadata initialization
;; ------------------------------------------------------------------

(defun make-clm-after-cut-msg-row (incoming-nbrs)
  (if (endp incoming-nbrs)
      nil
    (s (first incoming-nbrs)
       nil
       (make-clm-after-cut-msg-row (rest incoming-nbrs)))))

(defun make-clm-after-cut-msgs (ids procs)
  (if (endp ids)
      nil
    (let* ((i       (first ids))
           (p       (g i procs))
           (nbrs    (nbrs-from p))
           (row     (make-clm-after-cut-msg-row nbrs))
           (all     (make-clm-after-cut-msgs (rest ids) procs)))
      (s i row all))))

(defun make-clm-empty-waiting-marker-from (ids)
  (if (endp ids)
      nil
    (s (first ids)
       nil
       (make-clm-empty-waiting-marker-from (rest ids)))))

(defun make-cl-checkpoint-meta (sid st)
  ;; Initially no process has taken its cut.  The first input of the
  ;; segment is the matching :start-checkpoint input; processing that
  ;; input takes the initiator's cut.
  (let* ((ids   (proc-ids st))
         (procs (procs st)))
    (>_ :sid sid
        :proc-ids ids
        :cut-not-taken ids
        :waiting-marker-from
        (make-clm-empty-waiting-marker-from ids)
        :before-cut-inputs nil
        :after-cut-inputs nil
        :after-cut-msgs
        (make-clm-after-cut-msgs ids procs))))

;; ------------------------------------------------------------------
;; Completion predicate
;; ------------------------------------------------------------------

(defun clm-all-waiting-marker-empty-p (ids m)
  (if (endp ids)
      t
    (and (endp (clm-waiting-marker-for (first ids) m))
         (clm-all-waiting-marker-empty-p (rest ids) m))))

(defun cl-checkpoint-complete-p (m)
  (and (endp (clm-cut-not-taken m))
       (clm-all-waiting-marker-empty-p
        (clm-proc-ids m)
        m)))

;; ------------------------------------------------------------------
;; Snapshot-id and current-message helpers
;; ------------------------------------------------------------------

(defun cl-checkpoint-start-sid (input st)
  ;; SID created by this :start-checkpoint input in model(2).lisp.
  (let* ((i (pid input))
         (p (g i (procs st))))
    (list i (counter p))))

(defun cl-checkpoint-start-for-sid-p (input st sid0)
  (and (equal (ttype input) :start-checkpoint)
       (equal sid0 (cl-checkpoint-start-sid input st))))

(defun cl-current-receive-msg (input st)
  ;; In model(2).lisp, get-msg-from-channel takes sender first,
  ;; receiver second.
  (let ((i (pid input))
        (j (sender input)))
    (get-msg-from-channel j i (channels st))))

;; ------------------------------------------------------------------
;; One-step metadata update
;; ------------------------------------------------------------------

(defun clm-process-start-checkpoint (input st m)
  ;; The initiator records its local state at this input.  Its incoming
  ;; channels remain open until their markers arrive.
  (let* ((i     (pid input))
         (p     (g i (procs st)))
         (nbrs  (nbrs-from p))
         (m     (clm-remove-cut-not-taken i m)))
    (clm-set-waiting-marker-for i nbrs m)))

(defun clm-process-marker-receive (i j st m)
  (if (clm-cut-not-taken-p i m)
      ;; First marker for i.  Process i takes its cut here.  Channel j -> i
      ;; is already closed by this marker; all other incoming channels open.
      (let* ((p     (g i (procs st)))
             (nbrs  (nbrs-from p))
             (wait  (remove-from-list nbrs j))
             (m     (clm-remove-cut-not-taken i m)))
        (clm-set-waiting-marker-for i wait m))
    ;; A later marker closes just channel j -> i.
    (clm-set-waiting-marker-for
     i
     (remove-from-list (clm-waiting-marker-for i m) j)
     m)))

(defun clm-process-normal-input (input m)
  (let ((i (pid input)))
    (if (clm-cut-not-taken-p i m)
        (clm-add-before-cut-input input m)
      (clm-add-after-cut-input input m))))

(defun clm-process-normal-receive (input i j msg m)
  ;; The receive input is placed in the global before/after list.  If it
  ;; occurs after i's cut while channel j -> i is still open, the actual
  ;; consumed normal message is also stored in the channel-wise table.
  (if (clm-cut-not-taken-p i m)
      (clm-add-before-cut-input input m)
    (let ((m (clm-add-after-cut-input input m)))
      (if (memberp j (clm-waiting-marker-for i m))
          (clm-after-cut-msg-append i j msg m)
        m))))

(defun clm-process-receive (input st m)
  (let* ((i   (pid input))
         (j   (sender input))
         (msg (cl-current-receive-msg input st)))
    (cond
     ;; A marker for this checkpoint changes cut/channel-open metadata.
     ;; It is not an ordinary application input.
     ((and msg
           (equal (msg-type msg) :marker)
           (equal (sid msg) (clm-sid m)))
      (clm-process-marker-receive i j st m))

     ;; Only receives of actual normal messages are put in pre/post lists.
     ((and msg
           (equal (msg-type msg) :normal))
      (clm-process-normal-receive input i j msg m))

     ;; Empty receives, recovery messages, and markers for another SID do
     ;; not contribute to this checkpoint's ordinary trace.
     (t m))))

(defun cl-process-checkpoint-step (input st m)
  ;; ST is the implementation pre-state for INPUT.
  (cond
   ((cl-checkpoint-start-for-sid-p input st (clm-sid m))
    (clm-process-start-checkpoint input st m))

   ((equal (ttype input) :normal)
    (clm-process-normal-input input m))

   ((equal (ttype input) :receive)
    (clm-process-receive input st m))

   ;; :nop, crash/recovery inputs, or another checkpoint-start are ignored
   ;; by this metadata scan.  The intended segment predicate should exclude
   ;; crash and recovery during the target checkpoint segment.
   (t m)))

;; ------------------------------------------------------------------
;; Scan result
;; ------------------------------------------------------------------

(defmacro cl-scan-result-index (r)
  `(g :checkpoint-complete-index ,r))

(defmacro cl-scan-result-meta (r)
  `(g :checkpoint-meta ,r))

(defmacro cl-scan-result-state (r)
  `(g :checkpoint-complete-state ,r))

(defmacro cl-scan-result-completep (r)
  `(g :checkpoint-complete-p ,r))

;; ------------------------------------------------------------------
;; Scan through checkpoint completion
;; ------------------------------------------------------------------

(defun scan-until-checkpoint-complete-aux (inputs trace idx m)
  ;; TRACE is aligned with INPUTS: (first trace) is the implementation
  ;; pre-state of (first inputs).  A run-imp-trace has one extra final state.
  ;;
  ;; The returned index is end-exclusive.  If input k completes collection,
  ;; the result index is k+1 relative to the beginning of this segment.
  (if (or (endp inputs)
          (endp trace)
          (cl-checkpoint-complete-p m))
      (>_ :checkpoint-complete-index idx
          :checkpoint-meta m
          :checkpoint-complete-state (if (endp trace) nil (first trace))
          :checkpoint-complete-p (cl-checkpoint-complete-p m))
    (let* ((input (first inputs))
           (st    (first trace))
           (m1    (cl-process-checkpoint-step input st m)))
      (scan-until-checkpoint-complete-aux
       (rest inputs)
       (rest trace)
       (+ 1 idx)
       m1))))

(defun scan-until-checkpoint-complete (input-seg trace)
  ;; INPUT-SEG must start with the target :start-checkpoint input.
  ;; TRACE should be (run-imp-trace start-st input-seg), or an equivalent
  ;; trace aligned with INPUT-SEG.
  (if (or (endp input-seg)
          (endp trace))
      (>_ :checkpoint-complete-index 0
          :checkpoint-meta nil
          :checkpoint-complete-state (if (endp trace) nil (first trace))
          :checkpoint-complete-p nil)
    (let* ((first-input (first input-seg))
           (start-st    (first trace))
           (sid0        (cl-checkpoint-start-sid first-input start-st))
           (m0          (make-cl-checkpoint-meta sid0 start-st)))
      (scan-until-checkpoint-complete-aux
       input-seg
       trace
       0
       m0))))

;; Convenience wrapper when only the initial state and segment are available.
(defun scan-checkpoint-segment (st input-seg)
  (scan-until-checkpoint-complete
   input-seg
   (run-imp-trace st input-seg)))
